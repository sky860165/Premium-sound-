package com.yourcompany.premiumsounds.audio

import com.yourcompany.premiumsounds.audio.PremiumDSPEngine.SoundMode

/**
 * GenreDetector — Auto Preset Switcher
 * Detects genre from track title/artist metadata
 * and auto-applies the best DSP preset
 *
 * Uses keyword matching on track name + artist
 * (No ML needed — keyword matching works 80%+ of the time)
 */
object GenreDetector {

    data class DetectionResult(
        val mode: SoundMode,
        val confidence: Int,    // 0-100
        val reason: String
    )

    // Genre keyword map — order matters (more specific first)
    private val rules = listOf(
        // Classical / Orchestra
        Rule(SoundMode.CLASSICAL, listOf(
            "classical", "symphony", "orchestra", "sonata", "concerto",
            "beethoven", "mozart", "chopin", "bach", "brahms", "vivaldi",
            "opera", "choir", "string quartet", "piano concerto"
        ), "Classical/Orchestra detected"),

        // Jazz
        Rule(SoundMode.JAZZ, listOf(
            "jazz", "blues", "saxophone", "trumpet", "bebop", "swing",
            "coltrane", "miles davis", "monk", "improvisation", "soul jazz"
        ), "Jazz/Blues detected"),

        // Podcast / Talk
        Rule(SoundMode.PODCAST, listOf(
            "podcast", "talk", "interview", "news", "radio", "lecture",
            "audiobook", "story", "episode", "chapter", "comedy"
        ), "Speech/Podcast detected"),

        // Hip Hop / Rap
        Rule(SoundMode.HIP_HOP, listOf(
            "rap", "hip hop", "hiphop", "trap", "drill", "freestyle",
            "beat", "rhyme", "lil ", "young ", "dj ", "mc ", "cipher",
            "kendrick", "drake", "eminem", "j. cole"
        ), "Hip-Hop/Rap detected"),

        // EDM / Electronic
        Rule(SoundMode.EDM, listOf(
            "edm", "electronic", "techno", "house", "trance", "dubstep",
            "rave", "dj", "remix", "club", "bass drop", "electro",
            "avicii", "martin garrix", "marshmello", "alan walker"
        ), "EDM/Electronic detected"),

        // Rock / Metal
        Rule(SoundMode.ROCK, listOf(
            "rock", "metal", "punk", "grunge", "alternative", "hard rock",
            "heavy", "guitar", "band", "nirvana", "metallica", "acdc",
            "led zeppelin", "foo fighters", "linkin park"
        ), "Rock/Metal detected"),

        // Lo-Fi / Chill
        Rule(SoundMode.LOFI, listOf(
            "lo-fi", "lofi", "lo fi", "chill", "study", "relax", "ambient",
            "sleep", "calm", "meditation", "focus", "coffee"
        ), "Lo-Fi/Chill detected"),

        // Bollywood / Hindi
        Rule(SoundMode.MUSIC_HD, listOf(
            "bollywood", "hindi", "filmi", "desi", "bhajan", "ghazal",
            "arijit", "shreya", "atif", "sonu nigam", "udit narayan",
            "kumar sanu", "lata mangeshkar", "kishore kumar"
        ), "Bollywood/Hindi detected"),

        // Bass-heavy / Party
        Rule(SoundMode.BASS_MONSTER, listOf(
            "bass", "party", "dance", "boom", "banger", "anthem",
            "floor", "drop", "banging", "subwoofer"
        ), "Bass/Party detected"),

        // Vocal
        Rule(SoundMode.VOCAL_BOOST, listOf(
            "vocal", "acapella", "a cappella", "cover", "acoustic",
            "unplugged", "singer", "voice", "live session", "raw"
        ), "Vocal/Acoustic detected"),
    )

    private data class Rule(
        val mode: SoundMode,
        val keywords: List<String>,
        val reason: String
    )

    /**
     * Detect genre from track title + artist name
     * Returns null if no match found (keep current mode)
     */
    fun detect(title: String, artist: String): DetectionResult? {
        val combined = "${title.lowercase()} ${artist.lowercase()}"

        var bestMatch: Pair<Rule, Int>? = null

        for (rule in rules) {
            val matchCount = rule.keywords.count { kw -> combined.contains(kw) }
            if (matchCount > 0) {
                if (bestMatch == null || matchCount > bestMatch.second) {
                    bestMatch = Pair(rule, matchCount)
                }
            }
        }

        val match = bestMatch ?: return null
        val confidence = (match.second * 30).coerceIn(30, 95)

        return DetectionResult(
            mode = match.first.mode,
            confidence = confidence,
            reason = match.first.reason
        )
    }

    /**
     * Detect from filename (fallback)
     */
    fun detectFromFilename(filename: String): DetectionResult? {
        return detect(filename, "")
    }
}
