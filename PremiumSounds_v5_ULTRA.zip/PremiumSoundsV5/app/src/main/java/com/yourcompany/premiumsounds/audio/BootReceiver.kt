package com.yourcompany.premiumsounds.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * BootReceiver — auto-starts GlobalAudioEffectService after phone reboot.
 * So DSP stays active even after reboot without opening the app.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            GlobalAudioEffectService.start(context)
        }
    }
}
