package com.yourcompany.premiumsounds

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.yourcompany.premiumsounds.audio.GlobalAudioEffectService
import com.yourcompany.premiumsounds.audio.PremiumAudioService
import com.yourcompany.premiumsounds.ui.theme.PremiumSoundsTheme
import kotlinx.coroutines.delay

@UnstableApi
class VideoPlayerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_URI = "video_uri"
        const val EXTRA_TITLE = "video_title"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full immersive mode
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()

        val videoUri = intent.getStringExtra(EXTRA_URI)?.let { Uri.parse(it) }
        val videoTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Video"

        setContent {
            PremiumSoundsTheme {
                if (videoUri != null) {
                    VideoPlayerScreen(
                        uri = videoUri,
                        title = videoTitle,
                        onBack = { finish() }
                    )
                }
            }
        }
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}

@SuppressLint("ClickableViewAccessibility")
@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerScreen(uri: Uri, title: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    // Player state
    var isPlaying by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var showControls by remember { mutableStateOf(true) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var showSpeedMenu by remember { mutableStateOf(false) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var brightness by remember { mutableFloatStateOf(0.5f) }
    var volume by remember { mutableFloatStateOf(
        audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
        audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    ) }
    var showBrightnessOverlay by remember { mutableStateOf(false) }
    var showVolumeOverlay by remember { mutableStateOf(false) }
    var brightnessOverlayTimer by remember { mutableIntStateOf(0) }
    var volumeOverlayTimer by remember { mutableIntStateOf(0) }
    var isMuted by remember { mutableStateOf(false) }
    var isLocked by remember { mutableStateOf(false) }

    // ExoPlayer for video (separate from audio service)
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }

    // Auto-hide controls
    LaunchedEffect(showControls) {
        if (showControls) {
            delay(4000)
            showControls = false
        }
    }

    // Position polling
    LaunchedEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        }
        player.addListener(listener)
        while (true) {
            position = player.currentPosition
            duration = player.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    // Overlay auto-hide
    LaunchedEffect(brightnessOverlayTimer) {
        if (brightnessOverlayTimer > 0) {
            delay(1500); showBrightnessOverlay = false; brightnessOverlayTimer = 0
        }
    }
    LaunchedEffect(volumeOverlayTimer) {
        if (volumeOverlayTimer > 0) {
            delay(1500); showVolumeOverlay = false; volumeOverlayTimer = 0
        }
    }

    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    val speeds = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isLocked) {
                detectTapGestures(
                    onTap = { if (!isLocked) showControls = !showControls },
                    onDoubleTap = { offset ->
                        if (!isLocked) {
                            // Double tap left = -10s, right = +10s
                            if (offset.x < size.width / 2)
                                player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
                            else
                                player.seekTo((player.currentPosition + 10_000).coerceAtMost(player.duration))
                        }
                    }
                )
            }
    ) {
        // ── Video Surface ──
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    this.useController = false
                    this.resizeMode = resizeMode
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { pv -> pv.resizeMode = resizeMode },
            modifier = Modifier.fillMaxSize()
        )

        // ── Brightness/Volume Side Overlays ──
        AnimatedVisibility(visible = showBrightnessOverlay,
            enter = fadeIn(), exit = fadeOut(),
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 24.dp)) {
            SideIndicator("☀️", brightness, Color(0xFFFFC94D))
        }
        AnimatedVisibility(visible = showVolumeOverlay,
            enter = fadeIn(), exit = fadeOut(),
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 24.dp)) {
            SideIndicator("🔊", volume, Color(0xFF00D4FF))
        }

        // ── Lock overlay indicator ──
        if (isLocked) {
            Box(Modifier.fillMaxSize().background(Color.Transparent)
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = { isLocked = false; showControls = true })
                },
                contentAlignment = Alignment.Center) {
                Surface(shape = RoundedCornerShape(12.dp),
                    color = Color(0x88000000)) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Double tap to unlock", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // ── Controls overlay ──
        AnimatedVisibility(visible = showControls && !isLocked,
            enter = fadeIn(animationSpec = androidx.compose.animation.core.tween(200)),
            exit = fadeOut(animationSpec = androidx.compose.animation.core.tween(300)),
            modifier = Modifier.fillMaxSize()) {

            Box(Modifier.fillMaxSize()
                .background(Brush.verticalGradient(
                    listOf(Color(0xCC000000), Color.Transparent, Color.Transparent, Color(0xCC000000))
                ))
            ) {
                // ── TOP BAR ──
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
                    .align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(title, color = Color.White, fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)

                    // Lock button
                    IconButton(onClick = { isLocked = true; showControls = false }) {
                        Icon(Icons.Default.LockOpen, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    // Aspect ratio toggle
                    IconButton(onClick = {
                        resizeMode = when (resizeMode) {
                            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                            AspectRatioFrameLayout.RESIZE_MODE_FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        }
                    }) {
                        Icon(Icons.Default.AspectRatio, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    // Speed
                    Box {
                        TextButton(onClick = { showSpeedMenu = true }) {
                            Text("${playbackSpeed}x", color = Color(0xFF00D4FF),
                                fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        DropdownMenu(expanded = showSpeedMenu,
                            onDismissRequest = { showSpeedMenu = false },
                            modifier = Modifier.background(Color(0xFF1A1A2E))) {
                            speeds.forEach { spd ->
                                DropdownMenuItem(
                                    text = {
                                        Text("${spd}x",
                                            color = if (spd == playbackSpeed) Color(0xFF00D4FF) else Color.White,
                                            fontWeight = if (spd == playbackSpeed) FontWeight.Bold else FontWeight.Normal)
                                    },
                                    onClick = {
                                        playbackSpeed = spd
                                        player.setPlaybackSpeed(spd)
                                        showSpeedMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                // ── CENTER CONTROLS ──
                Row(Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(32.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    // -10s
                    IconButton(onClick = {
                        player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
                        showControls = true
                    }, modifier = Modifier.size(52.dp)) {
                        Icon(Icons.Default.Replay10, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    }

                    // Play/Pause
                    Box(Modifier.size(68.dp).clip(CircleShape)
                        .background(Color(0x99000000)),
                        contentAlignment = Alignment.Center) {
                        IconButton(onClick = {
                            if (isPlaying) player.pause() else player.play()
                            showControls = true
                        }) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                null, tint = Color.White, modifier = Modifier.size(40.dp)
                            )
                        }
                    }

                    // +10s
                    IconButton(onClick = {
                        player.seekTo((player.currentPosition + 10_000).coerceAtMost(player.duration))
                        showControls = true
                    }, modifier = Modifier.size(52.dp)) {
                        Icon(Icons.Default.Forward10, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    }
                }

                // ── BOTTOM BAR ──
                Column(Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp, vertical = 8.dp)) {

                    // Time
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(formatVideoTime(position), color = Color.White, fontSize = 12.sp)
                        Text(formatVideoTime(duration), color = Color(0xFFAAAAAA), fontSize = 12.sp)
                    }

                    // Seek bar
                    Slider(
                        value = if (duration > 0) position.toFloat() / duration else 0f,
                        onValueChange = { player.seekTo((it * duration).toLong()); showControls = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00D4FF),
                            activeTrackColor = Color(0xFF00D4FF),
                            inactiveTrackColor = Color(0x55FFFFFF)
                        )
                    )

                    // Bottom controls row
                    Row(Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {

                        // Volume
                        Row(verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)) {
                            IconButton(onClick = {
                                isMuted = !isMuted
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,
                                    if (isMuted) 0 else (volume * audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).toInt(), 0)
                            }) {
                                Icon(
                                    if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    null, tint = Color.White, modifier = Modifier.size(20.dp)
                                )
                            }
                            Slider(
                                value = if (isMuted) 0f else volume,
                                onValueChange = { v ->
                                    volume = v; isMuted = false
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,
                                        (v * audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).toInt(), 0)
                                },
                                modifier = Modifier.weight(1f).height(28.dp),
                                colors = SliderDefaults.colors(
                                    thumbColor = Color(0xFF00D4FF),
                                    activeTrackColor = Color(0xFF00D4FF),
                                    inactiveTrackColor = Color(0x55FFFFFF)
                                )
                            )
                        }

                        // DSP badge
                        val dspActive = PremiumAudioService.instance?.dspEngine != null
                        Surface(shape = RoundedCornerShape(6.dp),
                            color = if (dspActive) Color(0xFF7C4DFF).copy(0.3f) else Color(0x33FFFFFF)) {
                            Text(if (dspActive) "DSP ON" else "DSP OFF",
                                Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = if (dspActive) Color(0xFFBB86FC) else Color(0x99FFFFFF),
                                fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SideIndicator(emoji: String, value: Float, color: Color) {
    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xBB000000)) {
        Column(Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 20.sp)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.width(6.dp).height(80.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0xFF333344))) {
                Box(Modifier.fillMaxWidth()
                    .fillMaxHeight(value)
                    .align(Alignment.BottomCenter)
                    .clip(RoundedCornerShape(3.dp))
                    .background(color))
            }
            Spacer(Modifier.height(4.dp))
            Text("${(value * 100).toInt()}%", color = color,
                fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private fun formatVideoTime(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, sec)
    else String.format("%d:%02d", m, sec)
}
