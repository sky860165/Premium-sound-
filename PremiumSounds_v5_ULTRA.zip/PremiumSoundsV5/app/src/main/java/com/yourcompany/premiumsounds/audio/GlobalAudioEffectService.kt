package com.yourcompany.premiumsounds.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.audiofx.*
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.yourcompany.premiumsounds.MainActivity
import com.yourcompany.premiumsounds.R

/**
 * GlobalAudioEffectService v2
 *
 * Persistent ForegroundService that:
 * 1. Attaches AudioEffects to session 0 (global mix) — ALL apps affected
 * 2. Stays alive via START_STICKY — restarts if killed
 * 3. Syncs with PremiumDSPEngine for unified control
 * 4. Shows persistent notification with toggle
 *
 * Why session 0 works:
 * Android AudioFlinger mixes all app audio into a master mix.
 * Attaching Equalizer/BassBoost to session 0 processes this master mix.
 * This is exactly how Sound Beautifier and similar apps work.
 */
class GlobalAudioEffectService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): GlobalAudioEffectService = this@GlobalAudioEffectService
    }
    private val binder = LocalBinder()

    // All effects on global session 0
    private var globalEQ: Equalizer? = null
    private var globalBass: BassBoost? = null
    private var globalVirtualizer: Virtualizer? = null
    private var globalLoudness: LoudnessEnhancer? = null
    private var globalReverb: PresetReverb? = null

    var isEnabled = true
        private set

    companion object {
        const val CHANNEL_ID = "premium_global_eq"
        const val NOTIF_ID = 9001
        const val ACTION_TOGGLE = "com.yourcompany.premiumsounds.TOGGLE"
        var instance: GlobalAudioEffectService? = null
            private set

        fun start(context: Context) {
            val intent = Intent(context, GlobalAudioEffectService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(intent)
            else
                context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Initializing..."))
        initGlobalEffects()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TOGGLE) {
            setEnabled(!isEnabled)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        instance = null
        releaseAll()
        super.onDestroy()
    }

    // ── Init global effects ───────────────────────────────────────────────────

    private fun initGlobalEffects() {
        releaseAll()
        try {
            // Priority -1 = highest, session 0 = global mix
            globalEQ = Equalizer(-1, 0).apply { enabled = true }
            globalBass = BassBoost(-1, 0).apply { enabled = true }
            globalVirtualizer = Virtualizer(-1, 0).apply { enabled = true }
            globalLoudness = LoudnessEnhancer(0).apply { setTargetGain(0); enabled = false }
            globalReverb = try { PresetReverb(-1, 0).apply { enabled = false } } catch (_: Exception) { null }

            // Apply current DSP engine state immediately
            syncFromDSPEngine()
            updateNotification("Active — All Apps")
        } catch (e: Exception) {
            e.printStackTrace()
            updateNotification("Limited mode")
        }
    }

    // ── Sync from PremiumDSPEngine ────────────────────────────────────────────

    fun syncFromDSPEngine() {
        val engine = PremiumAudioService.instance?.dspEngine ?: return
        val state = engine.dspState.value
        val virtualGains = engine.nativeEQ.getVirtualGains()

        // Apply EQ bands
        applyVirtualGains(virtualGains)

        // Apply effects
        try { globalBass?.setStrength(state.bassStrength.toShort()); globalBass?.enabled = state.bassStrength > 0 } catch (_: Exception) {}
        val virtCalc = ((state.stereoWidth / 100f) * state.virtualizerStrength).toInt().coerceIn(0, 1000)
        try { globalVirtualizer?.setStrength(virtCalc.toShort()); globalVirtualizer?.enabled = virtCalc > 0 } catch (_: Exception) {}
        try { globalLoudness?.setTargetGain(state.loudnessBoostMb); globalLoudness?.enabled = state.loudnessBoostMb > 0 } catch (_: Exception) {}
        try { globalReverb?.preset = state.reverbPreset.toShort(); globalReverb?.enabled = state.reverbPreset != 0 } catch (_: Exception) {}

        val modeName = state.currentMode.label
        updateNotification("$modeName — All Apps")
    }

    private fun applyVirtualGains(virtualGains: IntArray) {
        val eq = globalEQ ?: return
        val bandCount = try { eq.numberOfBands.toInt() } catch (_: Exception) { return }
        val virtualBandFreqs = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 6000, 8000, 12000, 16000)

        for (hwBand in 0 until bandCount) {
            val hwFreq = try { eq.getCenterFreq(hwBand.toShort()) / 1000 } catch (_: Exception) { continue }
            val gain = interpolate(hwFreq, virtualBandFreqs, virtualGains)
            try { eq.setBandLevel(hwBand.toShort(), gain.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
        }
    }

    private fun interpolate(hwFreq: Int, freqs: IntArray, gains: IntArray): Int {
        var lo = 0; var hi = freqs.size - 1
        for (i in 0 until freqs.size - 1) {
            if (freqs[i] <= hwFreq && freqs[i+1] >= hwFreq) { lo = i; hi = i+1; break }
        }
        if (lo == hi) return gains[lo]
        val t = (Math.log10(hwFreq.toDouble()) - Math.log10(freqs[lo].toDouble())) /
                (Math.log10(freqs[hi].toDouble()) - Math.log10(freqs[lo].toDouble()))
        return (gains[lo] * (1-t) + gains[hi] * t).toInt()
    }

    // ── Public controls ───────────────────────────────────────────────────────

    fun setEnabled(enabled: Boolean) {
        isEnabled = enabled
        globalEQ?.enabled = enabled
        globalBass?.enabled = enabled
        globalVirtualizer?.enabled = enabled
        globalLoudness?.enabled = enabled
        globalReverb?.enabled = enabled
        updateNotification(if (enabled) "Active" else "Paused")
    }

    private fun releaseAll() {
        listOf(globalEQ, globalBass, globalVirtualizer, globalLoudness, globalReverb).forEach {
            try { it?.release() } catch (_: Exception) {}
        }
        globalEQ = null; globalBass = null; globalVirtualizer = null
        globalLoudness = null; globalReverb = null
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel(CHANNEL_ID, "PremiumSounds Global EQ",
                NotificationManager.IMPORTANCE_LOW).apply {
                description = "System-wide sound enhancement"
                setShowBadge(false)
                getSystemService(NotificationManager::class.java).createNotificationChannel(this)
            }
        }
    }

    private fun buildNotification(status: String): Notification {
        val openApp = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val toggle = PendingIntent.getService(this, 1,
            Intent(this, GlobalAudioEffectService::class.java).apply { action = ACTION_TOGGLE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("🎵 PremiumSounds DSP")
            .setContentText(status)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_media_pause,
                if (isEnabled) "Pause EQ" else "Resume EQ", toggle)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(status: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(status))
    }
}

// Keep PRESETS for backward compat
val PRESETS = mapOf(
    "Flat" to listOf(0,0,0,0,0),
    "Bass Boost" to listOf(800,400,0,0,0),
    "Vocal" to listOf(-200,0,600,400,0),
    "Rock" to listOf(500,300,-100,300,500),
    "Custom" to listOf(0,0,0,0,0)
)
