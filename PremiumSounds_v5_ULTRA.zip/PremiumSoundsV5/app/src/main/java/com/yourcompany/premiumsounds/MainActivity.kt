package com.yourcompany.premiumsounds

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.yourcompany.premiumsounds.audio.AudioCapabilityDetector
import com.yourcompany.premiumsounds.audio.DeviceMusicScanner
import com.yourcompany.premiumsounds.audio.PremiumAudioService
import com.yourcompany.premiumsounds.audio.PremiumDSPEngine
import com.yourcompany.premiumsounds.audio.Track
import com.yourcompany.premiumsounds.ui.theme.PremiumSoundsTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.*

@UnstableApi
class MainActivity : ComponentActivity() {

    private var mediaController: MediaController? = null

    private val notifPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    private val recordPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) recordPermission.launch(Manifest.permission.RECORD_AUDIO)

        setContent {
            PremiumSoundsTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen(mediaController)
                }
            }
        }

        val sessionToken = SessionToken(this, ComponentName(this, PremiumAudioService::class.java))
        val future = MediaController.Builder(this, sessionToken).buildAsync()
        future.addListener({
            try {
                mediaController = future.get()
                setContent {
                    PremiumSoundsTheme {
                        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                            MainScreen(mediaController)
                        }
                    }
                }
            } catch (_: Exception) {}
        }, MoreExecutors.directExecutor())
    }

    override fun onDestroy() {
        mediaController?.release()
        super.onDestroy()
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN SCREEN
// ─────────────────────────────────────────────────────────────────────────────
@UnstableApi
@Composable
fun MainScreen(mediaController: MediaController?) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Player", "Equalizer", "Playlist")
    val icons = listOf(Icons.Default.Headphones, Icons.Default.GraphicEq, Icons.Default.QueueMusic)

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D0D14), tonalElevation = 0.dp) {
                tabs.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = selectedTab == i,
                        onClick = { selectedTab = i },
                        icon = { Icon(icons[i], contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00D4FF), selectedTextColor = Color(0xFF00D4FF),
                            unselectedIconColor = Color(0xFF555566), unselectedTextColor = Color(0xFF555566),
                            indicatorColor = Color(0xFF00D4FF).copy(alpha = 0.12f)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF060608)
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            AnimatedContent(targetState = selectedTab, label = "tab_anim",
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(200)) }
            ) { tab ->
                when (tab) {
                    0 -> PlayerTab(mediaController)
                    1 -> EqualizerTab()
                    2 -> PlaylistTab(mediaController)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PLAYER TAB
// ─────────────────────────────────────────────────────────────────────────────
@UnstableApi
@Composable
fun PlayerTab(mediaController: MediaController?) {
    val context = LocalContext.current
    val capabilityDetector = remember { AudioCapabilityDetector(context) }
    val dolbyStatus = remember { capabilityDetector.getDolbySupportStatus() }

    var isPlaying by remember { mutableStateOf(false) }
    var isAtmosActive by remember { mutableStateOf(false) }
    var currentMime by remember { mutableStateOf("audio/raw") }
    var channelCount by remember { mutableIntStateOf(2) }
    var sampleRate by remember { mutableIntStateOf(0) }
    var isHiRes by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(1f) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var currentTrackTitle by remember { mutableStateOf("No Track") }
    var currentTrackArtist by remember { mutableStateOf("Select from Playlist") }

    val service = PremiumAudioService.instance
    val waveform by (service?.visualizerController?.waveform ?: MutableStateFlow(ByteArray(128))).collectAsState()
    val vizActive by (service?.visualizerController?.isActive ?: MutableStateFlow(false)).collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(900, easing = EaseInOut), RepeatMode.Reverse),
        label = "glow_alpha"
    )
    val accentColor by animateColorAsState(
        if (isAtmosActive) Color(0xFF00D4FF) else Color(0xFF7C4DFF), tween(600), label = "accent"
    )

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                intent?.let {
                    isAtmosActive = it.getBooleanExtra("is_atmos", false)
                    currentMime = it.getStringExtra("mime_type") ?: "audio/raw"
                    channelCount = it.getIntExtra("channel_count", 2)
                    sampleRate = it.getIntExtra("sample_rate", 0)
                    isHiRes = it.getBooleanExtra("is_hires", false)
                }
            }
        }
        val filter = IntentFilter(PremiumAudioService.ACTION_AUDIO_QUALITY)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else context.registerReceiver(receiver, filter)
        onDispose { context.unregisterReceiver(receiver) }
    }

    // Player.Listener — instant title/artist update on track change
    DisposableEffect(mediaController) {
        val listener = object : Player.Listener {
            override fun onMediaMetadataChanged(metadata: androidx.media3.common.MediaMetadata) {
                currentTrackTitle = metadata.title?.toString()?.takeIf { it.isNotBlank() } ?: "No Track"
                currentTrackArtist = metadata.artist?.toString() ?: ""
            }
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        }
        mediaController?.addListener(listener)
        // Populate immediately if track already loaded
        mediaController?.mediaMetadata?.let {
            val t = it.title?.toString()?.takeIf { s -> s.isNotBlank() }
            if (t != null) { currentTrackTitle = t; currentTrackArtist = it.artist?.toString() ?: "" }
        }
        onDispose { mediaController?.removeListener(listener) }
    }

    LaunchedEffect(mediaController) {
        while (true) {
            mediaController?.let {
                isPlaying = it.isPlaying
                position = it.currentPosition
                duration = it.duration.takeIf { d -> d > 0 } ?: 0L
                // Always sync title from controller (handles metadata arriving late)
                val title = it.mediaMetadata.title?.toString()?.takeIf { t -> t.isNotBlank() }
                val artist = it.mediaMetadata.artist?.toString()
                if (title != null) {
                    currentTrackTitle = title
                    currentTrackArtist = artist ?: ""
                }
            }
            delay(300)
        }
    }

    LaunchedEffect(volume) { mediaController?.volume = volume }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060608))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("PREMIUM SOUND", style = TextStyle(
                brush = Brush.linearGradient(listOf(Color(0xFF00D4FF), Color(0xFF7C4DFF), Color(0xFFFFC94D))),
                fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp
            ))
            Spacer(Modifier.width(8.dp))
            Surface(shape = RoundedCornerShape(6.dp),
                color = Color(0xFFFFC94D).copy(0.15f),
                border = BorderStroke(1.dp, Color(0xFFFFC94D).copy(0.6f))
            ) {
                Text("PRO", Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    color = Color(0xFFFFC94D), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Text("Immersive Audio Engine", fontSize = 11.sp, color = Color(0xFF555566), letterSpacing = 1.sp)

        Spacer(Modifier.height(24.dp))

        // Visualizer orb
        Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(240.dp)) {
                val cx = size.width / 2
                val cy = size.height / 2
                val baseR = size.width * 0.42f
                drawCircle(accentColor.copy(alpha = glowAlpha * 0.12f), baseR + 30f, Offset(cx, cy))
                if (isPlaying) {
                    drawCircle(accentColor.copy(alpha = glowAlpha * 0.08f), baseR + 50f, Offset(cx, cy))
                }
                if (vizActive && waveform.isNotEmpty()) {
                    val count = waveform.size.coerceAtMost(64)
                    val path = Path()
                    for (i in 0 until count) {
                        val angle = (i.toFloat() / count) * 2f * PI.toFloat()
                        val amp = (waveform[i].toInt() and 0xFF) / 255f
                        val r = baseR + amp * 40f
                        val x = cx + r * cos(angle)
                        val y = cy + r * sin(angle)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    path.close()
                    drawPath(path, accentColor.copy(alpha = 0.6f))
                }
            }
            Box(Modifier.size(200.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF1A1A2E), Color(0xFF0D0D14)))),
                contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Headphones, null, Modifier.size(64.dp), tint = accentColor)
                    Spacer(Modifier.height(6.dp))
                    Text(mimeLabel(currentMime), fontSize = 10.sp, color = accentColor.copy(0.8f),
                        fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        Text(currentTrackTitle, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(currentTrackArtist, fontSize = 13.sp, color = Color(0xFF888899))

        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (dolbyStatus.isAtmosSupported) AudioBadge("ATMOS", accentColor, isAtmosActive)
            if (dolbyStatus.hasDolbyHardware) AudioBadge("DOLBY", Color(0xFF7C4DFF), true)
            if (isHiRes) AudioBadge("HI-RES", Color(0xFFFFC94D), true)
            AudioBadge("${channelCount}CH", Color(0xFF00E676), channelCount > 2)
        }

        Spacer(Modifier.height(24.dp))

        Slider(
            value = if (duration > 0) position.toFloat() / duration else 0f,
            onValueChange = { mediaController?.seekTo((it * duration).toLong()) },
            modifier = Modifier.fillMaxWidth(),
            colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor,
                inactiveTrackColor = Color(0xFF2A2A3A))
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), fontSize = 11.sp, color = Color(0xFF666677))
            Text(formatTime(duration), fontSize = 11.sp, color = Color(0xFF666677))
        }

        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { mediaController?.seekToPreviousMediaItem() }) {
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = { mediaController?.seekBack() }) {
                Icon(Icons.Default.Replay10, null, tint = Color(0xFFAAAAAA), modifier = Modifier.size(28.dp))
            }
            // FIX: Play button now properly loads playlist and plays
            Box(Modifier.size(68.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(accentColor, accentColor.copy(0.7f)))),
                contentAlignment = Alignment.Center) {
                IconButton(onClick = {
                    if (isPlaying) {
                        mediaController?.pause()
                    } else {
                        val svc = PremiumAudioService.instance
                        if (svc != null && mediaController != null) {
                            val items = svc.playlistManager.toMediaItems()
                            if (items.isNotEmpty()) {
                                val idx = svc.playlistManager.currentIndex.value
                                if (mediaController.mediaItemCount == 0) {
                                    // No items loaded yet — load all
                                    mediaController.setMediaItems(items, idx, 0L)
                                    mediaController.prepare()
                                }
                                mediaController.play()
                            }
                        } else {
                            mediaController?.play()
                        }
                    }
                }) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        null, tint = Color.Black, modifier = Modifier.size(36.dp))
                }
            }
            IconButton(onClick = { mediaController?.seekForward() }) {
                Icon(Icons.Default.Forward10, null, tint = Color(0xFFAAAAAA), modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = { mediaController?.seekToNextMediaItem() }) {
                Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.VolumeDown, null, tint = Color(0xFF555566), modifier = Modifier.size(18.dp))
            Slider(value = volume, onValueChange = { volume = it },
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor,
                    inactiveTrackColor = Color(0xFF2A2A3A))
            )
            Icon(Icons.Default.VolumeUp, null, tint = Color(0xFF555566), modifier = Modifier.size(18.dp))
        }

        Spacer(Modifier.height(16.dp))

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF111118)).padding(16.dp)) {
            Text("DEVICE CAPABILITIES", fontSize = 10.sp, color = Color(0xFF666677),
                letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            CapRow("Dolby Atmos", dolbyStatus.isAtmosSupported)
            CapRow("Dolby Hardware", dolbyStatus.hasDolbyHardware)
            CapRow("Surround Sound", dolbyStatus.supportedFormats.isNotEmpty())
            CapRow("Spatial Visualizer", vizActive)
            if (sampleRate > 0) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Sample Rate", fontSize = 13.sp, color = Color(0xFFCCCCDD))
                    Text("${sampleRate / 1000.0} kHz", fontSize = 12.sp,
                        color = if (isHiRes) Color(0xFFFFC94D) else Color(0xFF888899), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
// EQUALIZER TAB — World-Class DSP Control v5
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun EqualizerTab() {
    val context = LocalContext.current
    val service = PremiumAudioService.instance
    val dspEngine = service?.dspEngine
    val dspState by (dspEngine?.dspState ?: MutableStateFlow(PremiumDSPEngine.DSPState())).collectAsState()

    var isGlobalMode by remember { mutableStateOf(true) }
    val globalService = com.yourcompany.premiumsounds.audio.GlobalAudioEffectService.instance
    val allModes = PremiumDSPEngine.SoundMode.values().toList()

    // Custom preset dialog state
    var showSaveDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var presetNameInput by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf("") }
    var activeTab by remember { mutableIntStateOf(0) } // 0=Modes, 1=Fine Tune, 2=My Presets

    // Sub-tabs
    val eqTabs = listOf("MODES", "FINE TUNE", "MY PRESETS")

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF060608))) {

        // ── Header ──
        Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("DSP ENGINE", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                    color = Color.White, letterSpacing = 3.sp)
                Spacer(Modifier.width(8.dp))
                Surface(shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF00D4FF).copy(0.15f),
                    border = BorderStroke(1.dp, Color(0xFF00D4FF).copy(0.6f))) {
                    Text("v5 ULTRA", Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        color = Color(0xFF00D4FF), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.width(6.dp))
                // Warmth score badge
                if (dspState.dspWarmthScore > 0) {
                    Surface(shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFFF6B00).copy(0.15f),
                        border = BorderStroke(1.dp, Color(0xFFFF6B00).copy(0.5f))) {
                        Text("🔥 ${dspState.dspWarmthScore}%", Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            color = Color(0xFFFF6B00), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                if (dspState.isHardwareAttached) "🟢 DSP Active — ${dspState.bands.size}-Band EQ Attached"
                else if (isGlobalMode) "🌐 Global Mode — Play any track to activate"
                else "▶ Play a track to activate DSP",
                fontSize = 11.sp,
                color = if (dspState.isHardwareAttached) Color(0xFF00E676) else Color(0xFF666644)
            )
        }

        // ── Global Mode Toggle ──
        Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(14.dp),
            color = if (isGlobalMode) Color(0xFF0D2218) else Color(0xFF111118),
            border = BorderStroke(1.dp, if (isGlobalMode) Color(0xFF00E676).copy(0.5f) else Color(0xFF2A2A3A))
        ) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, null,
                            tint = if (isGlobalMode) Color(0xFF00E676) else Color(0xFF555566),
                            modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("GLOBAL MODE", color = if (isGlobalMode) Color(0xFF00E676) else Color(0xFF888899),
                            fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Text("YouTube · Spotify · Chrome · All Apps",
                        fontSize = 10.sp, color = Color(0xFF555566), modifier = Modifier.padding(start = 21.dp))
                }
                Switch(checked = isGlobalMode, onCheckedChange = { v ->
                    isGlobalMode = v
                    val svcIntent = Intent(context, com.yourcompany.premiumsounds.audio.GlobalAudioEffectService::class.java)
                    if (v) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                            context.startForegroundService(svcIntent)
                        else context.startService(svcIntent)
                        globalService?.setEnabled(true)
                    } else {
                        globalService?.setEnabled(false)
                    }
                },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = Color(0xFF00E676)))
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── MAIN PAGE QUICK DSP CONTROLS ──
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0D0D18)).padding(16.dp)) {

            // Auto Genre Switch
            Row(Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🎯", fontSize = 14.sp)
                    Spacer(Modifier.width(6.dp))
                    Column {
                        Text("AUTO GENRE SWITCH", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold,
                            color = if (dspState.autoGenreSwitch) Color(0xFF00D4FF) else Color(0xFF555566),
                            letterSpacing = 0.5.sp)
                        Text("Track change pe auto preset", fontSize = 9.sp, color = Color(0xFF444455))
                    }
                }
                Switch(checked = dspState.autoGenreSwitch,
                    onCheckedChange = { dspEngine?.setAutoGenreSwitch(it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = Color(0xFF00D4FF)))
            }

            Spacer(Modifier.height(14.dp))

            // Bass Exciter slider
            var bassExciterVal by remember { mutableFloatStateOf(dspState.bassExciterLevel.toFloat()) }
            LaunchedEffect(dspState.bassExciterLevel) { bassExciterVal = dspState.bassExciterLevel.toFloat() }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("💥", fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                    Text("BASS EXCITER", fontSize = 11.sp, color = Color(0xFF888899))
                }
                Text("${bassExciterVal.toInt()}%", fontSize = 11.sp,
                    color = Color(0xFFFF6B00), fontWeight = FontWeight.Bold)
            }
            Slider(value = bassExciterVal, onValueChange = { bassExciterVal = it; dspEngine?.setBassExciter(it.toInt()) },
                valueRange = 0f..100f, modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(thumbColor = Color(0xFFFF6B00),
                    activeTrackColor = Color(0xFFFF6B00), inactiveTrackColor = Color(0xFF222233)))

            Spacer(Modifier.height(4.dp))

            // Compressor row with switch
            var compVal by remember { mutableFloatStateOf(dspState.compressorLevel.toFloat()) }
            LaunchedEffect(dspState.compressorLevel) { compVal = dspState.compressorLevel.toFloat() }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🎛", fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                    Text("COMPRESSOR", fontSize = 11.sp, color = Color(0xFF888899))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (dspState.compressorEnabled) "ON ${compVal.toInt()}%" else "OFF",
                        fontSize = 11.sp,
                        color = if (dspState.compressorEnabled) Color(0xFF00D4FF) else Color(0xFF555566),
                        fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = dspState.compressorEnabled,
                        onCheckedChange = { dspEngine?.setCompressor(dspState.compressorLevel, it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.Black,
                            checkedTrackColor = Color(0xFF00D4FF)),
                        modifier = Modifier.height(24.dp))
                }
            }
            if (dspState.compressorEnabled) {
                Slider(value = compVal,
                    onValueChange = { compVal = it; dspEngine?.setCompressor(it.toInt(), true) },
                    valueRange = 0f..100f, modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00D4FF),
                        activeTrackColor = Color(0xFF00D4FF), inactiveTrackColor = Color(0xFF222233)))
            }

            Spacer(Modifier.height(4.dp))

            // 3D Surround slider
            var surroundVal by remember { mutableFloatStateOf(dspState.surroundLevel.toFloat()) }
            LaunchedEffect(dspState.surroundLevel) { surroundVal = dspState.surroundLevel.toFloat() }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🌐", fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                    Text("3D SURROUND", fontSize = 11.sp, color = Color(0xFF888899))
                }
                Text("${surroundVal.toInt()}%", fontSize = 11.sp,
                    color = Color(0xFFE040FB), fontWeight = FontWeight.Bold)
            }
            Slider(value = surroundVal, onValueChange = { surroundVal = it; dspEngine?.setSurroundLevel(it.toInt()) },
                valueRange = 0f..100f, modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(thumbColor = Color(0xFFE040FB),
                    activeTrackColor = Color(0xFFE040FB), inactiveTrackColor = Color(0xFF222233)))

            Spacer(Modifier.height(4.dp))

            // Quick feature switches
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickToggle(Modifier.weight(1f), "✨", "Presence", dspState.presenceBoost, Color(0xFFFFD54F)) {
                    dspEngine?.setPresenceBoost(!dspState.presenceBoost)
                }
                QuickToggle(Modifier.weight(1f), "🎤", "Dialogue", dspState.dialogueEnhance, Color(0xFFFF9800)) {
                    dspEngine?.setDialogueEnhance(!dspState.dialogueEnhance)
                }
                QuickToggle(Modifier.weight(1f), "🌙", "Night", dspState.nightMode, Color(0xFF4A90D9)) {
                    dspEngine?.setNightMode(!dspState.nightMode)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── Sub-tab navigation ──
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            eqTabs.forEachIndexed { i, tab ->
                val isActive = activeTab == i
                Surface(
                    onClick = { activeTab = i },
                    shape = RoundedCornerShape(10.dp),
                    color = if (isActive) Color(0xFF00D4FF).copy(0.15f) else Color(0xFF111118),
                    border = BorderStroke(1.dp, if (isActive) Color(0xFF00D4FF).copy(0.7f) else Color(0xFF222233)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(tab, Modifier.padding(vertical = 9.dp),
                        color = if (isActive) Color(0xFF00D4FF) else Color(0xFF555566),
                        fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp, textAlign = TextAlign.Center)
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // ── Tab Content ──
        val scrollState = rememberScrollState()
        Column(Modifier.fillMaxSize().verticalScroll(scrollState)) {
            when (activeTab) {
                0 -> ModesTab(dspState, dspEngine, isGlobalMode, globalService)
                1 -> FineTuneTab(dspState, dspEngine, onSavePressed = { showSaveDialog = true })
                2 -> MyPresetsTab(dspState, dspEngine,
                    onRename = { name -> renameTarget = name; presetNameInput = name; showRenameDialog = true })
            }
            Spacer(Modifier.height(32.dp))
        }
    }

    // ── Save preset dialog ──
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false; presetNameInput = "" },
            containerColor = Color(0xFF111118),
            title = { Text("Save Custom Preset", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Name your sound signature:", color = Color(0xFF888899), fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = presetNameInput, onValueChange = { presetNameInput = it },
                        placeholder = { Text("e.g. My Bass Boost", color = Color(0xFF444455)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00D4FF), unfocusedBorderColor = Color(0xFF333344),
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("This saves all EQ bands, bass, spatial & loudness settings.",
                        color = Color(0xFF444455), fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (presetNameInput.isNotBlank()) {
                        dspEngine?.saveCustomPreset(presetNameInput.trim())
                        presetNameInput = ""
                        showSaveDialog = false
                    }
                }) { Text("💾 Save", color = Color(0xFF00D4FF), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false; presetNameInput = "" }) {
                    Text("Cancel", color = Color(0xFF888899))
                }
            }
        )
    }

    // ── Rename preset dialog ──
    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false; presetNameInput = "" },
            containerColor = Color(0xFF111118),
            title = { Text("Rename Preset", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = presetNameInput, onValueChange = { presetNameInput = it },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF9C27B0), unfocusedBorderColor = Color(0xFF333344),
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (presetNameInput.isNotBlank()) {
                        dspEngine?.renameCustomPreset(renameTarget, presetNameInput.trim())
                        showRenameDialog = false; presetNameInput = ""; renameTarget = ""
                    }
                }) { Text("Rename", color = Color(0xFF9C27B0), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false; presetNameInput = "" }) {
                    Text("Cancel", color = Color(0xFF888899))
                }
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MODES TAB
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun ModesTab(
    dspState: PremiumDSPEngine.DSPState,
    dspEngine: PremiumDSPEngine?,
    isGlobalMode: Boolean,
    globalService: com.yourcompany.premiumsounds.audio.GlobalAudioEffectService?
) {
    val allModes = PremiumDSPEngine.SoundMode.values().toList()
    val activeMode = dspState.currentMode

    Column {
        // Mode cards grid (2 columns)
        Text("SOUND MODES", fontSize = 10.sp, color = Color(0xFF555566),
            letterSpacing = 1.5.sp, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(10.dp))

        // Scrollable row for modes
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(allModes.size) { i ->
                val mode = allModes[i]
                val isSelected = dspState.currentMode == mode
                val modeColor = Color(mode.accentHex)
                Surface(
                    onClick = {
                        dspEngine?.applyMode(mode)
                        if (isGlobalMode) {
                            globalService?.applyPreset(when (mode) {
                                PremiumDSPEngine.SoundMode.BASS_MONSTER, PremiumDSPEngine.SoundMode.HIP_HOP, PremiumDSPEngine.SoundMode.EDM -> "Bass Boost"
                                PremiumDSPEngine.SoundMode.CLASSICAL, PremiumDSPEngine.SoundMode.JAZZ -> "Classical"
                                PremiumDSPEngine.SoundMode.VOCAL_BOOST, PremiumDSPEngine.SoundMode.PODCAST -> "Vocal"
                                PremiumDSPEngine.SoundMode.ROCK -> "Rock"
                                PremiumDSPEngine.SoundMode.FLAT -> "Flat"
                                else -> "Custom"
                            })
                            globalService?.setBassStrength(mode.bassStrength)
                            globalService?.setVirtualizerStrength(mode.virtStrength)
                            globalService?.setPremiumBoost(mode.loudnessMb)
                        }
                    },
                    shape = RoundedCornerShape(18.dp),
                    color = if (isSelected) modeColor.copy(0.18f) else Color(0xFF0F0F18),
                    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp,
                        if (isSelected) modeColor else Color(0xFF222233)),
                    modifier = Modifier.width(110.dp)
                ) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(mode.emoji, fontSize = 24.sp)
                        Spacer(Modifier.height(5.dp))
                        Text(mode.label, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            color = if (isSelected) modeColor else Color(0xFF888899),
                            maxLines = 1, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(3.dp))
                        Text(mode.description, fontSize = 9.sp, color = Color(0xFF444455),
                            maxLines = 2, lineHeight = 12.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Active mode strip
        Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(14.dp),
            color = Color(activeMode.accentHex).copy(0.08f),
            border = BorderStroke(1.dp, Color(activeMode.accentHex).copy(0.35f))
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(activeMode.emoji, fontSize = 30.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(activeMode.label, color = Color(activeMode.accentHex),
                        fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text(activeMode.description, color = Color(0xFF666677), fontSize = 11.sp)
                    if (dspState.isCustomMode) {
                        Text("✏️ Custom adjustments active", color = Color(0xFF9C27B0), fontSize = 10.sp)
                    }
                }
                Switch(checked = dspState.isEnabled,
                    onCheckedChange = { dspEngine?.setEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black, checkedTrackColor = Color(activeMode.accentHex)))
            }
        }

        Spacer(Modifier.height(16.dp))

        // DSP Chain Status
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {
            Text("DSP CHAIN", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))
            DSPMeter("${dspState.bands.size}-Band EQ", "Frequency shaping", dspState.bands.isNotEmpty(), Color(0xFF00D4FF))
            DSPMeter("Bass Engine", "${dspState.bassStrength / 10}% power", dspState.bassStrength > 0, Color(0xFF7C4DFF))
            DSPMeter("Sub-Bass Layer", "+${dspState.subBassBoost * 3}mB boost", dspState.subBassBoost > 0, Color(0xFFFF6B00))
            DSPMeter("3D Spatial", "${dspState.stereoWidth}% width", dspState.virtualizerStrength > 0, Color(0xFF00E676))
            DSPMeter("Loudness", "+${dspState.loudnessBoostMb / 100}dB gain", dspState.loudnessBoostMb > 0, Color(0xFFFFC94D))
            DSPMeter("Reverb/Space", reverbLabel(dspState.reverbPreset), dspState.reverbPreset != 0, Color(0xFFE040FB))
            DSPMeter("Presence Boost", "Upper-mid clarity", dspState.presenceBoost, Color(0xFFFFD54F))
        }

        Spacer(Modifier.height(16.dp))

        // Quick Enhance
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {
            Text("QUICK ENHANCE", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickToggle(Modifier.weight(1f), "🌙", "Night Mode",
                    dspState.nightMode, Color(0xFF4A90D9)) { dspEngine?.setNightMode(!dspState.nightMode) }
                QuickToggle(Modifier.weight(1f), "🎤", "Dialogue",
                    dspState.dialogueEnhance, Color(0xFFFF9800)) { dspEngine?.setDialogueEnhance(!dspState.dialogueEnhance) }
                QuickToggle(Modifier.weight(1f), "✨", "Presence",
                    dspState.presenceBoost, Color(0xFFFFD54F)) { dspEngine?.setPresenceBoost(!dspState.presenceBoost) }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// FINE TUNE TAB — Advanced EQ Controls
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun FineTuneTab(
    dspState: PremiumDSPEngine.DSPState,
    dspEngine: PremiumDSPEngine?,
    onSavePressed: () -> Unit
) {
    val activeMode = dspState.currentMode
    val accentColor = Color(activeMode.accentHex)

    // ── Local slider states — gainDb -15 to +15 ──
    val bandLevels = remember(dspState.bands.size) {
        dspState.bands.map { it.gainDb }.toMutableStateList()
    }
    LaunchedEffect(dspState.currentMode) {
        dspState.bands.forEachIndexed { i, band ->
            if (i < bandLevels.size) bandLevels[i] = band.gainDb
        }
    }
    var bassVal by remember { mutableFloatStateOf(dspState.bassStrength.toFloat()) }
    var subBassVal by remember { mutableFloatStateOf(dspState.subBassBoost.toFloat()) }
    var stereoVal by remember { mutableFloatStateOf(dspState.stereoWidth.toFloat()) }
    var loudnessVal by remember { mutableFloatStateOf(dspState.loudnessBoostMb.toFloat()) }
    var reverbVal by remember { mutableFloatStateOf(dspState.reverbPreset.toFloat()) }
    // Sync advanced sliders on mode change
    LaunchedEffect(dspState.currentMode) {
        bassVal = dspState.bassStrength.toFloat()
        subBassVal = dspState.subBassBoost.toFloat()
        stereoVal = dspState.stereoWidth.toFloat()
        loudnessVal = dspState.loudnessBoostMb.toFloat()
        reverbVal = dspState.reverbPreset.toFloat()
    }

    if (dspState.bands.isEmpty()) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 40.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(24.dp),
            contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🎛️", fontSize = 36.sp)
                Spacer(Modifier.height(12.dp))
                Text("Play a track to unlock Fine Tune", color = Color(0xFF555566),
                    fontSize = 13.sp, textAlign = TextAlign.Center)
                Text("EQ sliders need an active audio session", color = Color(0xFF333344),
                    fontSize = 11.sp, textAlign = TextAlign.Center)
            }
        }
        return
    }

    Column {
        // EQ Bands section
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("EQUALIZER — ${dspState.bands.size} BANDS", fontSize = 10.sp,
                        color = Color(0xFF555566), letterSpacing = 1.5.sp)
                    if (dspState.isCustomMode) {
                        Text("✏️ Custom mode", fontSize = 10.sp, color = Color(0xFF9C27B0))
                    }
                }
                TextButton(onClick = onSavePressed) {
                    Icon(Icons.Default.Save, null, tint = Color(0xFF00D4FF), modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Save", color = Color(0xFF00D4FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(10.dp))

            // EQ Bar Visualizer — LOCAL bandLevels se sync, moves instantly on drag
            Row(Modifier.fillMaxWidth().height(80.dp)
                .clip(RoundedCornerShape(10.dp)).background(Color(0xFF080810)).padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom) {
                dspState.bands.forEachIndexed { idx, band ->
                    val localGain = if (idx < bandLevels.size) bandLevels[idx] else band.gainDb
                    // Normalize -15..+15 to 0..1, center at 0.5
                    val norm = ((localGain + 15f) / 30f).coerceIn(0f, 1f)
                    val targetH = (norm * 68f).dp
                    val animH by animateDpAsState(targetH,
                        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f), label = "bar$idx")
                    val barColor = if (localGain >= 0f) Color(activeMode.accentHex) else Color(0xFFFF5252)
                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)) {
                        Box(Modifier.fillMaxWidth(0.72f).height(68.dp), contentAlignment = Alignment.BottomCenter) {
                            // Zero-line at center (50%)
                            Box(Modifier.fillMaxWidth().height(1.dp)
                                .align(Alignment.Center).background(Color(0xFF333355)))
                            Box(Modifier.fillMaxWidth().height(animH.coerceAtLeast(2.dp))
                                .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                .background(Brush.verticalGradient(
                                    listOf(barColor, barColor.copy(0.25f)))))
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                dspState.bands.forEach { band ->
                    Text(band.freqLabel, fontSize = 8.sp, color = Color(0xFF444455),
                        modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                }
            }
            Spacer(Modifier.height(14.dp))

            // EQ Band Sliders — LOCAL state, gainDb range -15 to +15
            dspState.bands.forEachIndexed { idx, band ->
                val localVal = if (idx < bandLevels.size) bandLevels[idx] else (band.levelMb / 100f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(band.freqLabel, fontSize = 10.sp, color = Color(0xFF666677),
                        modifier = Modifier.width(40.dp))
                    Slider(
                        value = localVal,
                        onValueChange = { v ->
                            if (idx < bandLevels.size) bandLevels[idx] = v
                            dspEngine?.setBandLevel(idx, v)
                        },
                        valueRange = -15f..15f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = accentColor,
                            activeTrackColor = accentColor,
                            inactiveTrackColor = Color(0xFF222233))
                    )
                    Text(
                        "${if (localVal >= 0) "+" else ""}${String.format("%.1f", localVal)}",
                        fontSize = 10.sp, color = accentColor, fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(40.dp), textAlign = TextAlign.End
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Advanced Controls — all with local state
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {
            Text("ADVANCED CONTROLS", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
            Spacer(Modifier.height(14.dp))

            AdvancedSlider("🔊 BASS ENGINE", "${(bassVal / 10).toInt()}%",
                bassVal, 0f, 1000f, Color(0xFF7C4DFF),
                onValueChange = { bassVal = it; dspEngine?.setBassStrength(it.toInt()) })

            AdvancedSlider("💥 SUB-BASS BOOST", "+${(subBassVal * 3).toInt()}mB",
                subBassVal, 0f, 100f, Color(0xFFFF6B00),
                onValueChange = { subBassVal = it; dspEngine?.setSubBassBoost(it.toInt()) })

            AdvancedSlider("🌐 STEREO WIDTH", "${stereoVal.toInt()}%",
                stereoVal, 0f, 100f, Color(0xFF00E676),
                onValueChange = { stereoVal = it; dspEngine?.setStereoWidth(it.toInt()) })

            AdvancedSlider("📢 LOUDNESS BOOST", "+${(loudnessVal / 100).toInt()}dB",
                loudnessVal, 0f, 2000f, Color(0xFFFFC94D),
                onValueChange = { loudnessVal = it; dspEngine?.setLoudnessBoost(it.toInt()) })

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("🌊 REVERB / SPACE", fontSize = 11.sp, color = Color(0xFF888899))
                Text(reverbLabel(reverbVal.toInt()), fontSize = 11.sp,
                    color = Color(0xFFE040FB), fontWeight = FontWeight.Bold)
            }
            Slider(value = reverbVal,
                onValueChange = { reverbVal = it; dspEngine?.setReverbPreset(it.toInt()) },
                valueRange = 0f..6f, steps = 5, modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(thumbColor = Color(0xFFE040FB),
                    activeTrackColor = Color(0xFFE040FB), inactiveTrackColor = Color(0xFF222233)))
            Text(reverbLabel(reverbVal.toInt()), fontSize = 9.sp,
                color = Color(0xFF444455), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
            Spacer(Modifier.height(8.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickToggle(Modifier.weight(1f), "✨", "Presence", dspState.presenceBoost, Color(0xFFFFD54F)) {
                    dspEngine?.setPresenceBoost(!dspState.presenceBoost)
                }
                QuickToggle(Modifier.weight(1f), "🎤", "Dialogue", dspState.dialogueEnhance, Color(0xFFFF9800)) {
                    dspEngine?.setDialogueEnhance(!dspState.dialogueEnhance)
                }
                QuickToggle(Modifier.weight(1f), "🌙", "Night", dspState.nightMode, Color(0xFF4A90D9)) {
                    dspEngine?.setNightMode(!dspState.nightMode)
                }
            }
        }
    }
}

@Composable
fun AdvancedSlider(label: String, valueText: String, value: Float, min: Float, max: Float, color: Color, onValueChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 11.sp, color = Color(0xFF888899))
        Text(valueText, fontSize = 11.sp, color = color, fontWeight = FontWeight.Bold)
    }
    Slider(value = value, onValueChange = onValueChange,
        valueRange = min..max, modifier = Modifier.fillMaxWidth(),
        colors = SliderDefaults.colors(thumbColor = color,
            activeTrackColor = color, inactiveTrackColor = Color(0xFF222233)))
    Spacer(Modifier.height(4.dp))
}

// ─────────────────────────────────────────────────────────────────────────────
// MY PRESETS TAB
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun MyPresetsTab(
    dspState: PremiumDSPEngine.DSPState,
    dspEngine: PremiumDSPEngine?,
    onRename: (String) -> Unit
) {
    Column(Modifier.padding(horizontal = 16.dp)) {

        if (dspState.savedCustomPresets.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(vertical = 40.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(32.dp),
                contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🎛️", fontSize = 40.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("No saved presets yet", color = Color(0xFF555566),
                        fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Go to Fine Tune tab → adjust sliders\n→ tap Save to create your signature sound",
                        color = Color(0xFF333344), fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        } else {
            Text("MY PRESETS", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))
            Text("${dspState.savedCustomPresets.size} saved • Persistent across app restarts",
                fontSize = 11.sp, color = Color(0xFF444455))
            Spacer(Modifier.height(12.dp))

            dspState.savedCustomPresets.forEach { name ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF0F0F18),
                    border = BorderStroke(1.dp, Color(0xFF222233)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("🎛️", fontSize = 22.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Custom sound signature", color = Color(0xFF444455), fontSize = 11.sp)
                        }
                        // Load button
                        Surface(onClick = { dspEngine?.loadCustomPreset(name) },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF00D4FF).copy(0.12f),
                            border = BorderStroke(1.dp, Color(0xFF00D4FF).copy(0.5f))) {
                            Text("Load", Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                color = Color(0xFF00D4FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(6.dp))
                        // Rename button
                        Surface(onClick = { onRename(name) },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF9C27B0).copy(0.12f),
                            border = BorderStroke(1.dp, Color(0xFF9C27B0).copy(0.4f))) {
                            Text("✏️", Modifier.padding(horizontal = 8.dp, vertical = 5.dp), fontSize = 12.sp)
                        }
                        Spacer(Modifier.width(6.dp))
                        // Delete button
                        Surface(onClick = { dspEngine?.deleteCustomPreset(name) },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFF5252).copy(0.1f),
                            border = BorderStroke(1.dp, Color(0xFFFF5252).copy(0.3f))) {
                            Text("🗑", Modifier.padding(horizontal = 8.dp, vertical = 5.dp), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// PLAYLIST TAB
// ─────────────────────────────────────────────────────────────────────────────
@UnstableApi
@Composable
fun PlaylistTab(mediaController: MediaController?) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val service = PremiumAudioService.instance
    val playlistManager = service?.playlistManager
    val tracks by (playlistManager?.playlist ?: MutableStateFlow(emptyList<Track>())).collectAsState()
    val currentIndex by (playlistManager?.currentIndex ?: MutableStateFlow(0)).collectAsState()
    val accentColor = Color(0xFF00D4FF)

    var isScanning by remember { mutableStateOf(false) }
    var scannedTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    val selectedIds = remember { mutableStateMapOf<String, Boolean>() }
    var showImportDialog by remember { mutableStateOf(false) }

    val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    // Auto-scan silently on first open if playlist is empty
    fun autoScanAndLoad() {
        if (isScanning) return
        isScanning = true
        coroutineScope.launch {
            val found = withContext(Dispatchers.IO) { DeviceMusicScanner.scan(context) }
            if (found.isNotEmpty()) {
                // Auto-add ALL tracks directly — no dialog needed
                playlistManager?.addTracks(found)
                // Sync to MediaController so player picks them up immediately
                if (mediaController != null && playlistManager != null) {
                    val items = playlistManager.toMediaItems()
                    mediaController.setMediaItems(items)
                    mediaController.prepare()
                }
            }
            isScanning = false
        }
    }

    fun startScan() {
        isScanning = true
        coroutineScope.launch {
            val found = withContext(Dispatchers.IO) { DeviceMusicScanner.scan(context) }
            scannedTracks = found
            selectedIds.clear()
            found.forEach { selectedIds[it.id] = true }
            isScanning = false
            showImportDialog = true
        }
    }

    val autoPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) autoScanAndLoad() }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startScan() }

    // Auto-scan when playlist is empty
    LaunchedEffect(Unit) {
        if (tracks.isEmpty()) {
            val hasPermission = ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) autoScanAndLoad()
            else autoPermissionLauncher.launch(audioPermission)
        }
    }

    fun onImportClicked() {
        val hasPermission = ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) startScan() else permissionLauncher.launch(audioPermission)
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF060608))) {
        Column(Modifier.padding(20.dp)) {
            Text("PLAYLIST", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, letterSpacing = 3.sp)
            Text("${tracks.size} tracks", fontSize = 11.sp, color = Color(0xFF555566))
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    if (playlistManager != null && mediaController != null && tracks.isNotEmpty()) {
                        mediaController.setMediaItems(playlistManager.toMediaItems())
                        mediaController.prepare()
                        mediaController.play()
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.Black)
                Spacer(Modifier.width(4.dp))
                Text("Play All", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { if (mediaController != null) mediaController.shuffleModeEnabled = !mediaController.shuffleModeEnabled },
                modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF333344))
            ) {
                Icon(Icons.Default.Shuffle, null, tint = Color(0xFF888899))
                Spacer(Modifier.width(4.dp))
                Text("Shuffle", color = Color(0xFF888899))
            }
        }

        Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            OutlinedButton(onClick = { onImportClicked() }, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFFFC94D).copy(0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFFC94D))
            ) {
                if (isScanning) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color(0xFFFFC94D))
                    Spacer(Modifier.width(8.dp))
                    Text("Scanning device...")
                } else {
                    Icon(Icons.Default.LibraryMusic, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Import Songs From Device", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        if (tracks.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.QueueMusic, null, tint = Color(0xFF333344), modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Your playlist is empty", color = Color(0xFF888899), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text("Tap \"Import Songs From Device\" to add music", color = Color(0xFF555566), fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(tracks) { index, track ->
                val isCurrentTrack = index == currentIndex
                Row(
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isCurrentTrack) accentColor.copy(0.1f) else Color(0xFF111118))
                        .border(if (isCurrentTrack) BorderStroke(1.dp, accentColor.copy(0.4f))
                            else BorderStroke(0.dp, Color.Transparent), RoundedCornerShape(14.dp))
                        .clickable {
                            if (playlistManager != null && mediaController != null) {
                                playlistManager.setCurrentIndex(index)
                                val items = playlistManager.toMediaItems()
                                mediaController.setMediaItems(items, index, 0L)
                                mediaController.prepare()
                                mediaController.play()
                            }
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                        .background(if (isCurrentTrack) accentColor.copy(0.2f) else Color(0xFF1A1A2A)),
                        contentAlignment = Alignment.Center) {
                        if (isCurrentTrack) {
                            Icon(Icons.Default.VolumeUp, null, tint = accentColor, modifier = Modifier.size(20.dp))
                        } else {
                            Text("${index + 1}", color = Color(0xFF555566), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, color = if (isCurrentTrack) accentColor else Color.White,
                            fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${track.artist} · ${track.format}", color = Color(0xFF666677),
                            fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { playlistManager?.removeTrack(track.id) }) {
                        Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFF444455))
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    if (showImportDialog) {
        AlertDialog(onDismissRequest = { showImportDialog = false },
            containerColor = Color(0xFF111118),
            title = { Text("Import Songs", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                if (scannedTracks.isEmpty()) {
                    Text("No audio files found on this device.", color = Color(0xFF888899))
                } else {
                    Column(Modifier.fillMaxWidth().heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                        Text("${scannedTracks.size} tracks found", color = Color(0xFF888899),
                            fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                        scannedTracks.forEach { track ->
                            Row(Modifier.fillMaxWidth()
                                .clickable { selectedIds[track.id] = !(selectedIds[track.id] ?: false) }
                                .padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = selectedIds[track.id] ?: false,
                                    onCheckedChange = { selectedIds[track.id] = it },
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFFFFC94D)))
                                Spacer(Modifier.width(4.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(track.title, color = Color.White, fontSize = 13.sp,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${track.artist} · ${track.format}", color = Color(0xFF666677),
                                        fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val chosen = scannedTracks.filter { selectedIds[it.id] == true }
                    playlistManager?.addTracks(chosen)
                    showImportDialog = false
                }) { Text("Add Selected (${selectedIds.values.count { it }})", color = Color(0xFFFFC94D), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) { Text("Cancel", color = Color(0xFF888899)) }
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// REUSABLE COMPOSABLES
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun DSPMeter(label: String, value: String, isActive: Boolean, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (isActive) color else Color(0xFF2A2A3A)))
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 12.sp, color = Color(0xFFCCCCDD), modifier = Modifier.width(110.dp))
        Spacer(Modifier.weight(1f))
        Text(value, fontSize = 11.sp, color = if (isActive) color else Color(0xFF444455),
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun QuickToggle(modifier: Modifier, emoji: String, label: String, isOn: Boolean, color: Color, onToggle: () -> Unit) {
    Surface(onClick = onToggle, modifier = modifier, shape = RoundedCornerShape(14.dp),
        color = if (isOn) color.copy(0.15f) else Color(0xFF0A0A12),
        border = BorderStroke(1.dp, if (isOn) color.copy(0.6f) else Color(0xFF1A1A2A))
    ) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 22.sp)
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isOn) color else Color(0xFF555566))
            Text(if (isOn) "ON" else "OFF", fontSize = 9.sp,
                color = if (isOn) color.copy(0.8f) else Color(0xFF333344),
                fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun AudioBadge(text: String, color: Color, isActive: Boolean) {
    Surface(shape = RoundedCornerShape(20.dp),
        color = if (isActive) color.copy(0.15f) else Color(0xFF1A1A2A),
        border = if (isActive) BorderStroke(1.dp, color.copy(0.6f)) else null
    ) {
        Text(text, Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            color = if (isActive) color else Color(0xFF555566),
            fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
    }
}

@Composable
fun CapRow(label: String, supported: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = Color(0xFFCCCCDD))
        Text(if (supported) "✓ YES" else "✗ NO", fontSize = 12.sp,
            color = if (supported) Color(0xFF00E676) else Color(0xFF555566), fontWeight = FontWeight.Bold)
    }
}

private fun reverbLabel(preset: Int) = when (preset) {
    0 -> "Off"; 1 -> "Small Room"; 2 -> "Medium Room"
    3 -> "Large Room"; 4 -> "Medium Hall"; 5 -> "Large Hall"; 6 -> "Plate"
    else -> "Active"
}

private fun mimeLabel(mime: String) = when (mime) {
    "audio/eac3-joc" -> "DOLBY ATMOS"; "audio/eac3" -> "DOLBY D+"
    "audio/ac3" -> "DOLBY D"; "audio/mp4a-latm" -> "AAC"; else -> "PCM"
}

private fun formatTime(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val s = ms / 1000
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}
