package com.yourcompany.premiumsounds.audio

/**
 * DynamicCompressor — Software Dynamic Range Compressor
 * Auto volume leveling + prevents clipping
 * Uses RMS-based gain reduction with attack/release envelope
 */
class DynamicCompressor {

    // Compressor params
    var threshold = -18f    // dB — above this, compress
    var ratio = 4f          // 4:1 compression
    var attackMs = 10f      // ms — how fast it reacts
    var releaseMs = 150f    // ms — how fast it recovers
    var makeupGainDb = 6f   // compensate for gain reduction
    var enabled = true

    private var sampleRate = 44100f
    private var envelope = 0f          // current RMS envelope
    private var gainReduction = 1f     // current gain multiplier

    fun configure(sampleRate: Int) {
        this.sampleRate = sampleRate.toFloat()
    }

    /**
     * Process a block of PCM samples (interleaved stereo, float -1..1)
     * Returns processed samples in-place
     */
    fun processSamples(samples: FloatArray, count: Int) {
        if (!enabled) return

        val attackCoeff = Math.exp(-1.0 / (attackMs * sampleRate / 1000.0)).toFloat()
        val releaseCoeff = Math.exp(-1.0 / (releaseMs * sampleRate / 1000.0)).toFloat()
        val thresholdLinear = Math.pow(10.0, threshold / 20.0).toFloat()
        val makeupGain = Math.pow(10.0, makeupGainDb / 20.0).toFloat()

        for (i in 0 until count) {
            val absVal = Math.abs(samples[i])

            // RMS envelope follower
            envelope = if (absVal > envelope)
                attackCoeff * envelope + (1f - attackCoeff) * absVal
            else
                releaseCoeff * envelope + (1f - releaseCoeff) * absVal

            // Gain computer
            val targetGain = if (envelope > thresholdLinear) {
                val excessDb = 20f * Math.log10(envelope / thresholdLinear.toDouble()).toFloat()
                val reductionDb = excessDb * (1f - 1f / ratio)
                Math.pow(10.0, -reductionDb / 20.0).toFloat()
            } else 1f

            // Smooth gain changes
            gainReduction = if (targetGain < gainReduction)
                attackCoeff * gainReduction + (1f - attackCoeff) * targetGain
            else
                releaseCoeff * gainReduction + (1f - releaseCoeff) * targetGain

            samples[i] = (samples[i] * gainReduction * makeupGain).coerceIn(-1f, 1f)
        }
    }

    fun getCurrentGainReductionDb(): Float {
        return if (gainReduction > 0) 20f * Math.log10(gainReduction.toDouble()).toFloat() else -60f
    }
}
