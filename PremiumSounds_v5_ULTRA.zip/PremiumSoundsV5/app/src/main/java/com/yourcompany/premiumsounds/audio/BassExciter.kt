package com.yourcompany.premiumsounds.audio

import kotlin.math.*

/**
 * BassExciter — Harmonic Bass Enhancement
 * Generates 2nd/3rd harmonics from low frequencies
 * Makes bass feel deeper even on small speakers
 * Classic "psychoacoustic bass" technique
 */
class BassExciter {

    var intensity = 0.5f    // 0-1, how much harmonic to add
    var frequency = 150f    // Hz — crossover, only bass below this gets excited
    var enabled = true

    private var sampleRate = 44100f

    // Simple 1-pole lowpass filter state (per channel)
    private val lpState = FloatArray(2) { 0f }
    // Highpass complement
    private val hpState = FloatArray(2) { 0f }

    fun configure(sampleRate: Int) {
        this.sampleRate = sampleRate.toFloat()
    }

    /**
     * Process interleaved stereo PCM float samples
     * Extracts bass, generates harmonics, mixes back
     */
    fun processSamples(samples: FloatArray, count: Int, channelCount: Int) {
        if (!enabled || intensity < 0.01f) return

        val rc = 1f / (2f * PI.toFloat() * frequency)
        val dt = 1f / sampleRate
        val alpha = dt / (rc + dt)  // lowpass coefficient

        for (i in 0 until count) {
            val ch = i % channelCount.coerceIn(1, 2)

            // Extract bass via lowpass
            lpState[ch] = lpState[ch] + alpha * (samples[i] - lpState[ch])
            val bass = lpState[ch]

            // Generate 2nd harmonic (full-wave rectify = even harmonics)
            // Generate 3rd harmonic (cubic distortion = odd harmonics)
            val h2 = bass * bass * sign(bass)      // 2nd harmonic
            val h3 = bass * bass * bass             // 3rd harmonic
            val harmonic = h2 * 0.6f + h3 * 0.4f

            // Mix harmonic back with intensity control
            samples[i] = (samples[i] + harmonic * intensity * 0.3f).coerceIn(-1f, 1f)
        }
    }

    private fun sign(x: Float) = if (x >= 0f) 1f else -1f
}
