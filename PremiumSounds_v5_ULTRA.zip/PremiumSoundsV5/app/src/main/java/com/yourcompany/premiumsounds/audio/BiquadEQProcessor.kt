package com.yourcompany.premiumsounds.audio

import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.C
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * BiquadEQProcessor — 20-Band Software Peaking EQ
 * Injected into ExoPlayer via DefaultAudioSink.DefaultAudioProcessorChain
 *
 * 20 bands: 25,40,63,100,160,250,400,630,1k,1.6k,2.5k,4k,6.3k,8k,10k,12.5k,14k,16k,18k,20k
 * Each band: peaking biquad IIR, gain -15dB to +15dB, Q=1.41
 * Processes PCM_16BIT and PCM_FLOAT interleaved stereo.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class BiquadEQProcessor : AudioProcessor {

    val BAND_FREQS = floatArrayOf(
        25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f,
        1000f, 1600f, 2500f, 4000f, 6300f, 8000f,
        10000f, 12500f, 14000f, 16000f, 18000f, 20000f
    )
    val BAND_COUNT = BAND_FREQS.size  // 20

    private val gains = FloatArray(BAND_COUNT) { 0f }

    // coeffs[band] = [b0, b1, b2, a1, a2] (normalized, a0=1)
    private val coeffs = Array(BAND_COUNT) { DoubleArray(5).also { it[0] = 1.0 } }

    // states[band][ch] = [z1, z2]  — max 8 channels
    private var states = Array(BAND_COUNT) { Array(8) { DoubleArray(2) } }

    private var sampleRate = 44100
    private var channelCount = 2
    private var enabled = true

    private var inputAudioFormat = AudioProcessor.AudioFormat.NOT_SET
    private var outputBuffer = AudioProcessor.EMPTY_BUFFER
    private var inputEnded = false

    // ── Public API ─────────────────────────────────────────────────────────────

    fun setBandGain(band: Int, gainDb: Float) {
        if (band !in 0 until BAND_COUNT) return
        gains[band] = gainDb.coerceIn(-15f, 15f)
        recalcCoeffs(band)
    }

    fun setAllGains(gainList: List<Float>) {
        gainList.take(BAND_COUNT).forEachIndexed { i, g ->
            gains[i] = g.coerceIn(-15f, 15f)
            recalcCoeffs(i)
        }
    }

    fun getGains(): FloatArray = gains.copyOf()

    fun setEnabled(on: Boolean) { enabled = on }

    // ── AudioProcessor ─────────────────────────────────────────────────────────

    override fun configure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val enc = inputAudioFormat.encoding
        if (enc != C.ENCODING_PCM_16BIT && enc != C.ENCODING_PCM_FLOAT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        this.inputAudioFormat = inputAudioFormat
        sampleRate = inputAudioFormat.sampleRate
        channelCount = inputAudioFormat.channelCount.coerceIn(1, 8)
        for (i in 0 until BAND_COUNT) recalcCoeffs(i)
        clearStates()
        return inputAudioFormat  // same format out
    }

    override fun isActive(): Boolean =
        enabled && inputAudioFormat != AudioProcessor.AudioFormat.NOT_SET

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return

        val inputBytes = inputBuffer.remaining()
        if (outputBuffer === AudioProcessor.EMPTY_BUFFER || outputBuffer.capacity() < inputBytes) {
            outputBuffer = ByteBuffer.allocateDirect(inputBytes).order(ByteOrder.nativeOrder())
        }
        outputBuffer.clear()

        when (inputAudioFormat.encoding) {
            C.ENCODING_PCM_16BIT -> process16(inputBuffer, outputBuffer)
            C.ENCODING_PCM_FLOAT -> processFloat(inputBuffer, outputBuffer)
        }

        outputBuffer.flip()
        inputBuffer.position(inputBuffer.limit())
    }

    override fun getOutput(): ByteBuffer {
        val out = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return out
    }

    override fun queueEndOfStream() { inputEnded = true }
    override fun isEnded() = inputEnded && outputBuffer === AudioProcessor.EMPTY_BUFFER
    override fun flush() { outputBuffer = AudioProcessor.EMPTY_BUFFER; inputEnded = false; clearStates() }
    override fun reset() { inputAudioFormat = AudioProcessor.AudioFormat.NOT_SET; flush() }

    // ── PCM Processing ─────────────────────────────────────────────────────────

    private fun process16(input: ByteBuffer, output: ByteBuffer) {
        // Work directly with ByteBuffer to avoid ShortBuffer position confusion
        var ch = 0
        while (input.remaining() >= 2) {
            val raw = input.short.toInt()
            var sample = raw / 32768.0

            for (band in 0 until BAND_COUNT) {
                if (gains[band] == 0f) continue
                sample = applyBiquad(sample, band, ch)
            }

            val out = (sample.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort()
            output.putShort(out)
            ch = (ch + 1) % channelCount
        }
    }

    private fun processFloat(input: ByteBuffer, output: ByteBuffer) {
        var ch = 0
        while (input.remaining() >= 4) {
            var sample = input.float.toDouble()

            for (band in 0 until BAND_COUNT) {
                if (gains[band] == 0f) continue
                sample = applyBiquad(sample, band, ch)
            }

            output.putFloat(sample.coerceIn(-1.0, 1.0).toFloat())
            ch = (ch + 1) % channelCount
        }
    }

    // Direct Form II Transposed biquad
    private fun applyBiquad(x: Double, band: Int, ch: Int): Double {
        val c = coeffs[band]
        val s = states[band][ch]
        val y = c[0] * x + s[0]
        s[0] = c[1] * x - c[3] * y + s[1]
        s[1] = c[2] * x - c[4] * y
        return y
    }

    // ── Coefficient Calculation (Audio EQ Cookbook — peaking EQ) ──────────────

    private fun recalcCoeffs(band: Int) {
        val gainDb = gains[band].toDouble()
        val freq   = BAND_FREQS[band].toDouble()
        val Q      = 1.41  // ~1 octave

        if (abs(gainDb) < 0.01) {
            coeffs[band] = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 0.0)  // passthrough
            return
        }

        val A     = 10.0.pow(gainDb / 40.0)
        val w0    = 2.0 * PI * freq / sampleRate
        val alpha = sin(w0) / (2.0 * Q)
        val cos0  = cos(w0)

        val b0 =  1.0 + alpha * A
        val b1 = -2.0 * cos0
        val b2 =  1.0 - alpha * A
        val a0 =  1.0 + alpha / A
        val a1 = -2.0 * cos0
        val a2 =  1.0 - alpha / A

        coeffs[band] = doubleArrayOf(b0/a0, b1/a0, b2/a0, a1/a0, a2/a0)
    }

    private fun clearStates() {
        for (band in states) for (ch in band) ch.fill(0.0)
    }
}
