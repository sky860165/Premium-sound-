package com.yourcompany.premiumsounds.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * BiquadEQProcessor — 20-Band Software Peaking EQ
 * Implements AudioProcessor directly for ExoPlayer injection.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class BiquadEQProcessor : AudioProcessor {

    val BAND_FREQS = floatArrayOf(
        25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f,
        1000f, 1600f, 2500f, 4000f, 6300f, 8000f,
        10000f, 12500f, 14000f, 16000f, 18000f, 20000f
    )
    val BAND_COUNT = BAND_FREQS.size

    private val gains = FloatArray(BAND_COUNT) { 0f }
    private val coeffs = Array(BAND_COUNT) { DoubleArray(5).also { it[0] = 1.0 } }
    private var states = Array(BAND_COUNT) { Array(8) { DoubleArray(2) } }

    private var sampleRate = 44100
    private var channelCount = 2
    @Volatile private var enabled = true

    // ── Integrated processors ─────────────────────────────────────────────────
    val compressor = DynamicCompressor()
    val bassExciter = BassExciter()
    val surroundProcessor = SurroundProcessor()

    private var audioFormat = AudioProcessor.AudioFormat.NOT_SET
    private var outputBuffer = AudioProcessor.EMPTY_BUFFER
    private var inputEnded = false

    fun setBandGain(band: Int, gainDb: Float) {
        if (band !in 0 until BAND_COUNT) return
        gains[band] = gainDb.coerceIn(-15f, 15f)
        recalcCoeffs(band)
    }

    fun setAllGains(gainList: List<Float>) {
        gainList.take(BAND_COUNT).forEachIndexed { i, g ->
            gains[i] = g.coerceIn(-15f, 15f)
            recalcCoeffs(i)
        }
    }

    fun getGains(): FloatArray = gains.copyOf()
    fun setEnabled(on: Boolean) { enabled = on }

    override fun configure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val enc = inputAudioFormat.encoding
        if (enc != C.ENCODING_PCM_16BIT && enc != C.ENCODING_PCM_FLOAT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        audioFormat = inputAudioFormat
        sampleRate = inputAudioFormat.sampleRate
        channelCount = inputAudioFormat.channelCount.coerceIn(1, 8)
        for (i in 0 until BAND_COUNT) recalcCoeffs(i)
        clearStates()
        // Configure integrated processors
        compressor.configure(sampleRate)
        bassExciter.configure(sampleRate)
        surroundProcessor.configure(sampleRate)
        return inputAudioFormat
    }

    override fun isActive(): Boolean = audioFormat != AudioProcessor.AudioFormat.NOT_SET

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return
        val bytes = inputBuffer.remaining()
        if (outputBuffer === AudioProcessor.EMPTY_BUFFER || outputBuffer.capacity() < bytes) {
            outputBuffer = ByteBuffer.allocateDirect(bytes).order(ByteOrder.nativeOrder())
        }
        outputBuffer.clear()
        if (enabled) {
            when (audioFormat.encoding) {
                C.ENCODING_PCM_16BIT -> process16(inputBuffer, outputBuffer)
                C.ENCODING_PCM_FLOAT -> processFloat(inputBuffer, outputBuffer)
                else -> outputBuffer.put(inputBuffer)
            }
        } else {
            outputBuffer.put(inputBuffer)
        }
        outputBuffer.flip()
        inputBuffer.position(inputBuffer.limit())
    }

    override fun getOutput(): ByteBuffer {
        val out = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return out
    }

    override fun queueEndOfStream() { inputEnded = true }
    override fun isEnded() = inputEnded && outputBuffer === AudioProcessor.EMPTY_BUFFER
    override fun flush() { outputBuffer = AudioProcessor.EMPTY_BUFFER; inputEnded = false; clearStates() }
    override fun reset() { audioFormat = AudioProcessor.AudioFormat.NOT_SET; flush() }

    private fun process16(input: ByteBuffer, output: ByteBuffer) {
        val count = input.remaining() / 2
        val buf = FloatArray(count) { input.short / 32768f }
        processPipeline(buf, count)
        for (s in buf) output.putShort((s.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
    }

    private fun processFloat(input: ByteBuffer, output: ByteBuffer) {
        val count = input.remaining() / 4
        val buf = FloatArray(count) { input.float }
        processPipeline(buf, count)
        for (s in buf) output.putFloat(s.coerceIn(-1f, 1f))
    }

    private fun processPipeline(buf: FloatArray, count: Int) {
        // Stage 1: Biquad EQ bands
        var ch = 0
        for (i in 0 until count) {
            var s = buf[i].toDouble()
            for (band in 0 until BAND_COUNT) {
                if (abs(gains[band]) < 0.01f) continue
                s = applyBiquad(s, band, ch)
            }
            buf[i] = s.coerceIn(-1.0, 1.0).toFloat()
            ch = (ch + 1) % channelCount
        }
        // Stage 2: Bass Exciter (harmonic bass enhancement)
        bassExciter.processSamples(buf, count, channelCount)
        // Stage 3: Dynamic Compressor (auto leveling, no clipping)
        compressor.processSamples(buf, count)
        // Stage 4: 3D Surround (stereo widening + Haas effect)
        if (channelCount == 2) surroundProcessor.processStereo(buf, count)
    }

    private fun applyBiquad(x: Double, band: Int, ch: Int): Double {
        val c = coeffs[band]
        val s = states[band][ch]
        val y = c[0] * x + s[0]
        s[0] = c[1] * x - c[3] * y + s[1]
        s[1] = c[2] * x - c[4] * y
        return y
    }

    private fun recalcCoeffs(band: Int) {
        val gainDb = gains[band].toDouble()
        val freq = BAND_FREQS[band].toDouble()
        val Q = 1.41
        if (abs(gainDb) < 0.01) {
            coeffs[band] = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 0.0)
            return
        }
        val A = 10.0.pow(gainDb / 40.0)
        val w0 = 2.0 * PI * freq / sampleRate
        val alpha = sin(w0) / (2.0 * Q)
        val cos0 = cos(w0)
        val b0 = 1.0 + alpha * A;  val b1 = -2.0 * cos0;  val b2 = 1.0 - alpha * A
        val a0 = 1.0 + alpha / A;  val a1 = -2.0 * cos0;  val a2 = 1.0 - alpha / A
        coeffs[band] = doubleArrayOf(b0/a0, b1/a0, b2/a0, a1/a0, a2/a0)
    }

    private fun clearStates() {
        for (b in states) for (c in b) c.fill(0.0)
    }
}
