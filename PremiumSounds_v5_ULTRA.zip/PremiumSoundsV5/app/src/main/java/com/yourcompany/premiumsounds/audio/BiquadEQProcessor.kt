package com.yourcompany.premiumsounds.audio

import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.C
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * BiquadEQProcessor — 20-Band Software EQ for ExoPlayer
 *
 * Pure software signal processing — no hardware dependency.
 * Each band = 1 peaking biquad IIR filter (Direct Form II Transposed).
 *
 * 20 ISO bands (Hz):
 * 25, 40, 63, 100, 160, 250, 400, 630, 1k, 1.6k,
 * 2.5k, 4k, 6.3k, 8k, 10k, 12.5k, 14k, 16k, 18k, 20k
 *
 * Each band: gain -15dB to +15dB, Q = 1.41 (octave width)
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class BiquadEQProcessor : AudioProcessor {

    // ── 20-Band center frequencies ────────────────────────────────────────────
    val BAND_FREQS = floatArrayOf(
        25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f,
        1000f, 1600f, 2500f, 4000f, 6300f, 8000f,
        10000f, 12500f, 14000f, 16000f, 18000f, 20000f
    )
    val BAND_COUNT = BAND_FREQS.size

    // Gain per band in dB (-15 to +15), default 0
    private val gains = FloatArray(BAND_COUNT) { 0f }

    // Per-band biquad coefficients [b0, b1, b2, a1, a2]
    private val coeffs = Array(BAND_COUNT) { DoubleArray(5) }

    // Per-band, per-channel state [z1, z2]
    private var states = Array(BAND_COUNT) { Array(2) { DoubleArray(2) } }

    private var sampleRate = 44100
    private var channelCount = 2
    private var isActive = true

    private var inputFormat = AudioProcessor.AudioFormat.NOT_SET
    private var outputFormat = AudioProcessor.AudioFormat.NOT_SET
    private var buffer = AudioProcessor.EMPTY_BUFFER
    private var inputEnded = false

    // ── Public API ─────────────────────────────────────────────────────────────

    /** Set gain for a single band (0-indexed). gainDb: -15 to +15 */
    fun setBandGain(bandIndex: Int, gainDb: Float) {
        if (bandIndex !in 0 until BAND_COUNT) return
        gains[bandIndex] = gainDb.coerceIn(-15f, 15f)
        recalcCoeffs(bandIndex)
    }

    /** Set all 20 bands at once from a list of dB values */
    fun setAllGains(gainDb: List<Float>) {
        gainDb.take(BAND_COUNT).forEachIndexed { i, g ->
            gains[i] = g.coerceIn(-15f, 15f)
            recalcCoeffs(i)
        }
    }

    /** Reset all bands to 0dB */
    fun resetAll() {
        for (i in 0 until BAND_COUNT) {
            gains[i] = 0f
            recalcCoeffs(i)
        }
        clearStates()
    }

    fun getGains(): FloatArray = gains.copyOf()

    fun setEnabled(enabled: Boolean) { isActive = enabled }

    // ── AudioProcessor interface ───────────────────────────────────────────────

    override fun configure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT &&
            inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        inputFormat = inputAudioFormat
        outputFormat = inputAudioFormat
        sampleRate = inputAudioFormat.sampleRate
        channelCount = inputAudioFormat.channelCount.coerceIn(1, 2)
        // Recalc all coefficients for new sample rate
        for (i in 0 until BAND_COUNT) recalcCoeffs(i)
        resetStates()
        return outputFormat
    }

    override fun isActive(): Boolean = isActive && inputFormat != AudioProcessor.AudioFormat.NOT_SET

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return

        val remaining = inputBuffer.remaining()
        if (buffer.capacity() < remaining) {
            buffer = ByteBuffer.allocateDirect(remaining).order(ByteOrder.nativeOrder())
        }
        buffer.clear()

        when (inputFormat.encoding) {
            C.ENCODING_PCM_16BIT -> process16Bit(inputBuffer, buffer)
            C.ENCODING_PCM_FLOAT -> processFloat(inputBuffer, buffer)
        }

        buffer.flip()
        inputBuffer.position(inputBuffer.limit())
    }

    override fun getOutput(): ByteBuffer {
        val out = buffer
        buffer = AudioProcessor.EMPTY_BUFFER
        return out
    }

    override fun queueEndOfStream() { inputEnded = true }
    override fun isEnded(): Boolean = inputEnded && buffer === AudioProcessor.EMPTY_BUFFER
    override fun flush() { inputEnded = false; buffer = AudioProcessor.EMPTY_BUFFER; clearStates() }
    override fun reset() { inputFormat = AudioProcessor.AudioFormat.NOT_SET; flush() }

    // ── Signal Processing ─────────────────────────────────────────────────────

    private fun process16Bit(input: ByteBuffer, output: ByteBuffer) {
        val shortInput = input.asShortBuffer()
        val shortOutput = output.asShortBuffer()
        val sampleCount = shortInput.remaining()

        while (shortInput.hasRemaining()) {
            // Interleaved: [L, R, L, R, ...]
            val ch = (shortInput.position() % channelCount).coerceIn(0, channelCount - 1)
            var sample = shortInput.get().toDouble() / 32768.0

            // Apply all 20 biquad filters in series
            for (band in 0 until BAND_COUNT) {
                if (gains[band] == 0f) continue // skip flat bands for perf
                sample = applyBiquad(sample, band, ch)
            }

            // Clip to [-1, 1] and convert back
            shortOutput.put((sample.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort())
        }
        output.position(sampleCount * 2)
    }

    private fun processFloat(input: ByteBuffer, output: ByteBuffer) {
        val floatInput = input.asFloatBuffer()
        val floatOutput = output.asFloatBuffer()
        val sampleCount = floatInput.remaining()

        while (floatInput.hasRemaining()) {
            val ch = (floatInput.position() % channelCount).coerceIn(0, channelCount - 1)
            var sample = floatInput.get().toDouble()

            for (band in 0 until BAND_COUNT) {
                if (gains[band] == 0f) continue
                sample = applyBiquad(sample, band, ch)
            }

            floatOutput.put(sample.coerceIn(-1.0, 1.0).toFloat())
        }
        output.position(sampleCount * 4)
    }

    /** Direct Form II Transposed biquad */
    private fun applyBiquad(x: Double, band: Int, ch: Int): Double {
        val (b0, b1, b2, a1, a2) = coeffs[band]
        val z = states[band][ch]
        val y = b0 * x + z[0]
        z[0] = b1 * x - a1 * y + z[1]
        z[1] = b2 * x - a2 * y
        return y
    }

    // ── Peaking EQ Biquad Coefficient Calculation ─────────────────────────────
    // Formula: Audio EQ Cookbook by Robert Bristow-Johnson
    private fun recalcCoeffs(band: Int) {
        val gainDb = gains[band].toDouble()
        val freq = BAND_FREQS[band].toDouble()
        val Q = 1.41  // ~1 octave bandwidth

        if (abs(gainDb) < 0.01) {
            // Identity filter (passthrough)
            coeffs[band] = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 0.0)
            return
        }

        val A = 10.0.pow(gainDb / 40.0)  // sqrt(10^(dB/20))
        val w0 = 2.0 * PI * freq / sampleRate.toDouble()
        val cosW0 = cos(w0)
        val sinW0 = sin(w0)
        val alpha = sinW0 / (2.0 * Q)

        // Peaking EQ filter
        val b0 = 1.0 + alpha * A
        val b1 = -2.0 * cosW0
        val b2 = 1.0 - alpha * A
        val a0 = 1.0 + alpha / A
        val a1 = -2.0 * cosW0
        val a2 = 1.0 - alpha / A

        coeffs[band] = doubleArrayOf(
            b0 / a0,
            b1 / a0,
            b2 / a0,
            a1 / a0,
            a2 / a0
        )
    }

    private fun resetStates() {
        states = Array(BAND_COUNT) { Array(channelCount.coerceIn(1, 2)) { DoubleArray(2) } }
    }

    private fun clearStates() {
        for (band in states) for (ch in band) ch.fill(0.0)
    }

    // Destructuring for coeffs array
    private operator fun DoubleArray.component1() = this[0]
    private operator fun DoubleArray.component2() = this[1]
    private operator fun DoubleArray.component3() = this[2]
    private operator fun DoubleArray.component4() = this[3]
    private operator fun DoubleArray.component5() = this[4]
}
