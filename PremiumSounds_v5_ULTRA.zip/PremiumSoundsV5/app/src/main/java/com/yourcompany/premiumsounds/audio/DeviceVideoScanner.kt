package com.yourcompany.premiumsounds.audio

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class VideoTrack(
    val id: String,
    val title: String,
    val duration: Long,   // ms
    val size: Long,       // bytes
    val resolution: String, // e.g. "3840x2160"
    val width: Int,
    val height: Int,
    val uri: Uri,
    val mimeType: String
) {
    val is4K get() = width >= 3840 || height >= 2160
    val isFullHD get() = width >= 1920 || height >= 1080
    val qualityLabel get() = when {
        is4K -> "4K"
        isFullHD -> "FHD"
        width >= 1280 -> "HD"
        else -> "SD"
    }
    val sizeLabel get() = when {
        size > 1_000_000_000L -> String.format("%.1f GB", size / 1_000_000_000.0)
        size > 1_000_000L -> String.format("%.0f MB", size / 1_000_000.0)
        else -> String.format("%.0f KB", size / 1_000.0)
    }
}

object DeviceVideoScanner {
    fun scan(context: Context): List<VideoTrack> {
        val videos = mutableListOf<VideoTrack>()
        val collection = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q)
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.MIME_TYPE
        )

        try {
            context.contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val wCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val hCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: continue
                    val w = cursor.getInt(wCol)
                    val h = cursor.getInt(hCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    videos.add(VideoTrack(
                        id = id.toString(),
                        title = name.substringBeforeLast('.'),
                        duration = cursor.getLong(durCol),
                        size = cursor.getLong(sizeCol),
                        resolution = "${w}x${h}",
                        width = w, height = h,
                        uri = uri,
                        mimeType = cursor.getString(mimeCol) ?: "video/mp4"
                    ))
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
        return videos
    }
}
