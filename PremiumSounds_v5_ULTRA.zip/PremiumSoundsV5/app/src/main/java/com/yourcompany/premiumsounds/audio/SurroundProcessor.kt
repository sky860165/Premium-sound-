package com.yourcompany.premiumsounds.audio

import kotlin.math.*

/**
 * SurroundProcessor — 3D Virtual Surround Sound
 * Uses Haas effect + comb filtering + ITD (Interaural Time Delay)
 * to create virtual speaker positioning
 *
 * Technique: Cross-feed with delay + phase shift simulates
 * sound coming from outside the head (like speakers, not headphones)
 */
class SurroundProcessor {

    var width = 0.5f        // 0-1, stereo width / surround strength
    var enabled = true

    private var sampleRate = 44100f

    // Delay buffer for Haas effect (ITD ~0.6ms per degree)
    private val DELAY_SAMPLES_MAX = 512
    private val leftDelay = FloatArray(DELAY_SAMPLES_MAX)
    private val rightDelay = FloatArray(DELAY_SAMPLES_MAX)
    private var delayWrite = 0

    // Crossfeed amount — how much L bleeds into R and vice versa
    // This simulates speaker crossfeed (headphones sound like speakers)
    private val CROSSFEED_DELAY_MS = 0.3f   // ~30cm speaker spacing
    private var crossfeedDelaySamples = 13   // updated on configure

    fun configure(sampleRate: Int) {
        this.sampleRate = sampleRate.toFloat()
        crossfeedDelaySamples = (CROSSFEED_DELAY_MS * sampleRate / 1000f).toInt().coerceIn(1, DELAY_SAMPLES_MAX - 1)
        leftDelay.fill(0f)
        rightDelay.fill(0f)
    }

    /**
     * Process stereo interleaved PCM [L,R,L,R,...]
     * Applies 3D widening via crossfeed + Haas delay
     */
    fun processStereo(samples: FloatArray, count: Int) {
        if (!enabled || width < 0.01f || count < 2) return

        val crossAmt = width * 0.35f     // crossfeed blend (max 35%)
        val directAmt = 1f - crossAmt
        val wideAmt = width * 0.4f       // side channel boost

        var i = 0
        while (i < count - 1) {
            val L = samples[i]
            val R = samples[i + 1]

            // Mid/Side processing for width
            val mid = (L + R) * 0.5f
            val side = (L - R) * 0.5f
            val widenedL = mid + side * (1f + wideAmt)
            val widenedR = mid - side * (1f + wideAmt)

            // Store in delay buffer
            leftDelay[delayWrite % DELAY_SAMPLES_MAX] = widenedL
            rightDelay[delayWrite % DELAY_SAMPLES_MAX] = widenedR

            // Read delayed signal for crossfeed (Haas effect)
            val delayIdx = ((delayWrite - crossfeedDelaySamples) + DELAY_SAMPLES_MAX) % DELAY_SAMPLES_MAX
            val delayedL = leftDelay[delayIdx]
            val delayedR = rightDelay[delayIdx]

            // Mix: direct + crossfeed from opposite channel (delayed)
            samples[i]     = (widenedL * directAmt + delayedR * crossAmt).coerceIn(-1f, 1f)
            samples[i + 1] = (widenedR * directAmt + delayedL * crossAmt).coerceIn(-1f, 1f)

            delayWrite = (delayWrite + 1) % DELAY_SAMPLES_MAX
            i += 2
        }
    }
}
