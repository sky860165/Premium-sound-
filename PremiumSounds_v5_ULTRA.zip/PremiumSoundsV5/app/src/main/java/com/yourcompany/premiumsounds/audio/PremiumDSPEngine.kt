package com.yourcompany.premiumsounds.audio

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * PremiumDSPEngine v5 ULTRA
 * Uses NativeEQController (12 virtual bands → hardware EQ) — 100% guaranteed sound change.
 * Plus BassBoost, Virtualizer, LoudnessEnhancer, PresetReverb for full DSP chain.
 */
class PremiumDSPEngine {

    private var context: Context? = null
    private var prefs: SharedPreferences? = null

    // Native EQ — 12 virtual bands mapped to hardware
    val nativeEQ = NativeEQController()

    // Software processors (via ExoPlayer pipeline)
    var biquadEQ: BiquadEQProcessor? = null

    // Auto genre detection
    var autoSwitchEnabled = true
    private var lastAutoTitle = ""

    // Supplementary hardware effects
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var presetReverb: PresetReverb? = null

    private val _dspState = MutableStateFlow(DSPState())
    val dspState: StateFlow<DSPState> = _dspState

    private val customPresets = mutableMapOf<String, CustomPreset>()

    // ── Data Classes ──────────────────────────────────────────────────────────

    data class CustomPreset(
        val name: String,
        val virtualGainsMb: List<Int>,   // 12 bands in mB
        val bassStrength: Int,
        val virtStrength: Int,
        val loudnessMb: Int,
        val reverbPreset: Int,
        val subBassBoost: Int,
        val presenceBoost: Boolean,
        val stereoWidth: Int
    )

    data class DSPState(
        val currentMode: SoundMode = SoundMode.MUSIC_HD,
        val isEnabled: Boolean = true,
        val bands: List<BandState> = emptyList(),
        val bassStrength: Int = 500,
        val virtualizerStrength: Int = 500,
        val loudnessBoostMb: Int = 0,
        val reverbPreset: Int = 0,
        val dialogueEnhance: Boolean = false,
        val nightMode: Boolean = false,
        val isHardwareAttached: Boolean = false,
        val savedCustomPresets: List<String> = emptyList(),
        val subBassBoost: Int = 0,
        val presenceBoost: Boolean = false,
        val stereoWidth: Int = 50,
        val dspWarmthScore: Int = 0,
        val isCustomMode: Boolean = false
    )

    data class BandState(
        val index: Int,
        val centerFreqHz: Int,
        val gainMb: Int,
        val minMb: Int = -1500,
        val maxMb: Int = 1500,
        val freqLabel: String,
        val gainDb: Float = 0f
    )

    // ── 12-Band Sound Modes ───────────────────────────────────────────────────
    // Values in mB: [31,62,125,250,500,1k,2k,4k,6k,8k,12k,16k]
    enum class SoundMode(
        val label: String,
        val emoji: String,
        val description: String,
        val eqMb: List<Int>,
        val bassStrength: Int,
        val virtStrength: Int,
        val loudnessMb: Int,
        val reverbPreset: Int,
        val subBassBoost: Int,
        val presenceBoost: Boolean,
        val stereoWidth: Int,
        val accentHex: Long
    ) {
        FLAT("Flat","◼","Pure unprocessed signal",
            listOf(0,0,0,0,0,0,0,0,0,0,0,0),
            0,0,0,0,0,false,50,0xFF888899L),
        MUSIC_HD("Music HD","🎵","Balanced richness for all genres",
            listOf(300,500,400,200,0,100,200,300,400,500,450,400),
            450,550,400,0,20,false,60,0xFF00D4FFL),
        BASS_MONSTER("Bass Monster","🔊","Max sub-bass punch",
            listOf(1200,1000,900,500,200,-200,-300,0,50,100,0,-100),
            1000,200,500,0,100,false,40,0xFF7C4DFFL),
        CINEMA("Cinema","🎬","Wide surround + loud dialogue",
            listOf(700,600,500,300,100,400,700,600,500,400,300,100),
            500,950,700,5,30,true,80,0xFFFF6B6BL),
        GAME("Game","🎮","3D positional spatial audio",
            listOf(400,500,400,100,-100,200,400,600,700,650,500,400),
            600,1000,400,1,20,false,85,0xFF00E676L),
        PODCAST("Podcast","🎙️","Voice clarity, cut rumble",
            listOf(-800,-700,-500,-200,100,800,1000,900,700,400,100,-100),
            0,200,900,0,0,true,40,0xFFFFC94DL),
        NIGHT_MODE("Night Mode","🌙","Smooth dynamics, low-vol comfort",
            listOf(300,250,200,150,100,150,200,150,100,50,-100,-200),
            200,150,1400,0,10,false,45,0xFF4A90D9L),
        CONCERT_HALL("Concert Hall","🎻","Live acoustic hall simulation",
            listOf(400,350,300,100,-200,-100,200,400,500,600,700,600),
            150,800,200,5,0,false,75,0xFFE040FBL),
        DEEP_SPACE("Deep Space","🚀","Maximum 3D immersion",
            listOf(700,650,500,300,100,100,200,400,600,750,800,700),
            400,1000,600,3,40,false,90,0xFF00BCD4L),
        VOCAL_BOOST("Vocal Boost","🎤","Enhanced singer clarity",
            listOf(-700,-500,-200,0,200,700,1000,1000,900,700,400,200),
            100,350,600,0,0,true,55,0xFFFF9800L),
        ROCK("Rock","🎸","Punchy mids, aggressive highs",
            listOf(900,800,700,200,-200,-100,300,600,800,900,850,700),
            800,600,300,0,30,true,65,0xFFFF5252L),
        CLASSICAL("Classical","🎼","Natural warmth, airy highs",
            listOf(500,400,300,100,-300,-400,-200,100,200,400,700,800),
            100,400,150,4,0,false,70,0xFFF8BBD0L),
        HIP_HOP("Hip Hop","🎤","Heavy bass + crisp hi-hats",
            listOf(1100,900,700,200,-100,-100,0,100,200,500,650,700),
            950,500,500,0,70,false,60,0xFFFF6B00L),
        EDM("EDM","⚡","Club bass drop + air",
            listOf(1000,900,700,100,-300,-400,0,200,400,700,900,1000),
            950,900,600,2,80,false,80,0xFF00E5FFL),
        LOFI("Lo-Fi","☕","Warm vintage cassette feel",
            listOf(600,500,400,300,100,-100,-300,-500,-600,-700,-800,-900),
            300,100,100,1,20,false,35,0xFFD4A04DL),
        JAZZ("Jazz","🎺","Warm mids, smooth highs",
            listOf(300,400,500,600,300,100,0,100,200,300,250,200),
            200,300,200,3,10,false,60,0xFFFFD54FL),
        CUSTOM("Custom","🎛️","Your personal sound signature",
            listOf(0,0,0,0,0,0,0,0,0,0,0,0),
            500,500,400,0,30,false,60,0xFF9C27B0L)
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    fun init(ctx: Context) {
        context = ctx.applicationContext
        prefs = context?.getSharedPreferences("dsp_presets_v5", Context.MODE_PRIVATE)
        loadPresetsFromDisk()
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
        refreshBandState()
    }

    // ── Hardware Attach ───────────────────────────────────────────────────────

    fun attach(audioSessionId: Int) {
        // Attach native EQ (12 virtual bands)
        nativeEQ.attach(audioSessionId)
        val eqOk = nativeEQ.isAttached()

        // Attach supplementary effects
        try {
            bassBoost = BassBoost(-1, audioSessionId).apply { enabled = true }
        } catch (_: Exception) {}
        try {
            virtualizer = Virtualizer(-1, audioSessionId).apply { enabled = true }
        } catch (_: Exception) {}
        try {
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(0); enabled = false
            }
        } catch (_: Exception) {}
        try {
            presetReverb = PresetReverb(-1, audioSessionId).apply { enabled = false }
        } catch (_: Exception) {}

        _dspState.value = _dspState.value.copy(isHardwareAttached = eqOk)
        applyMode(_dspState.value.currentMode)
    }

    // ── Apply Mode ────────────────────────────────────────────────────────────

    fun applyMode(mode: SoundMode) {
        // 1. Native 12-band EQ (hardware — for all apps via session 0)
        nativeEQ.setAllVirtualBands(mode.eqMb.toIntArray())

        // 2. Software biquad EQ (for ExoPlayer playlist)
        biquadEQ?.setAllGains(mode.eqMb.map { it / 100f })

        // 3. Bass Exciter
        biquadEQ?.bassExciter?.intensity = when (mode) {
            SoundMode.BASS_MONSTER, SoundMode.HIP_HOP, SoundMode.EDM -> 0.8f
            SoundMode.MUSIC_HD, SoundMode.ROCK -> 0.5f
            SoundMode.CLASSICAL, SoundMode.JAZZ -> 0.2f
            SoundMode.FLAT -> 0f
            else -> 0.4f
        }
        biquadEQ?.bassExciter?.enabled = mode != SoundMode.FLAT

        // 4. Compressor
        biquadEQ?.compressor?.apply {
            when (mode) {
                SoundMode.NIGHT_MODE -> { threshold = -12f; ratio = 6f; makeupGainDb = 4f }
                SoundMode.CINEMA, SoundMode.PODCAST -> { threshold = -18f; ratio = 3f; makeupGainDb = 5f }
                SoundMode.BASS_MONSTER, SoundMode.EDM -> { threshold = -24f; ratio = 8f; makeupGainDb = 8f }
                SoundMode.FLAT -> { enabled = false }
                else -> { threshold = -18f; ratio = 4f; makeupGainDb = 6f; enabled = true }
            }
        }

        // 5. 3D Surround
        biquadEQ?.surroundProcessor?.apply {
            width = when (mode) {
                SoundMode.DEEP_SPACE -> 0.9f
                SoundMode.CINEMA, SoundMode.GAME -> 0.8f
                SoundMode.CONCERT_HALL -> 0.7f
                SoundMode.MUSIC_HD, SoundMode.ROCK, SoundMode.EDM -> 0.5f
                SoundMode.PODCAST, SoundMode.VOCAL_BOOST -> 0.2f
                SoundMode.FLAT -> 0f
                else -> 0.4f
            }
            enabled = mode != SoundMode.FLAT
        }

        // 6. BassBoost hardware
        try {
            bassBoost?.setStrength(mode.bassStrength.toShort())
            bassBoost?.enabled = mode.bassStrength > 0
        } catch (_: Exception) {}

        // 7. Virtualizer
        val virtCalc = ((mode.stereoWidth / 100f) * mode.virtStrength).toInt().coerceIn(0, 1000)
        try {
            virtualizer?.setStrength(virtCalc.toShort())
            virtualizer?.enabled = virtCalc > 0
        } catch (_: Exception) {}

        // 8. Loudness
        try {
            loudnessEnhancer?.setTargetGain(mode.loudnessMb)
            loudnessEnhancer?.enabled = mode.loudnessMb > 0
        } catch (_: Exception) {}

        // 9. Reverb
        try {
            presetReverb?.preset = mode.reverbPreset.toShort()
            presetReverb?.enabled = mode.reverbPreset != 0
        } catch (_: Exception) {}

        _dspState.value = _dspState.value.copy(
            currentMode = mode,
            bassStrength = mode.bassStrength,
            virtualizerStrength = mode.virtStrength,
            loudnessBoostMb = mode.loudnessMb,
            reverbPreset = mode.reverbPreset,
            subBassBoost = mode.subBassBoost,
            presenceBoost = mode.presenceBoost,
            stereoWidth = mode.stereoWidth,
            nightMode = mode == SoundMode.NIGHT_MODE,
            isCustomMode = mode == SoundMode.CUSTOM
        )
        refreshBandState()
        updateWarmthScore()
        // Sync to global session — YouTube, all apps
        GlobalAudioEffectService.instance?.syncFromDSPEngine()
    }

    // ── Fine Tune — 12 virtual bands ─────────────────────────────────────────

    /** gainDb: -15.0 to +15.0 */
    fun setBandLevel(bandIndex: Int, gainDb: Float) {
        val gainMb = (gainDb * 100).toInt().coerceIn(-1500, 1500)
        nativeEQ.setVirtualBand(bandIndex, gainMb)
        refreshBandState()
        if (_dspState.value.currentMode != SoundMode.CUSTOM) {
            _dspState.value = _dspState.value.copy(isCustomMode = true)
        }
        updateWarmthScore()
        GlobalAudioEffectService.instance?.syncFromDSPEngine()
    }

    fun setBassStrength(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        try { bassBoost?.setStrength(clamped.toShort()); bassBoost?.enabled = clamped > 0 } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(bassStrength = clamped, isCustomMode = true)
        updateWarmthScore()
    }

    fun setVirtualizerStrength(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        try { virtualizer?.setStrength(clamped.toShort()); virtualizer?.enabled = clamped > 0 } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(virtualizerStrength = clamped, isCustomMode = true)
    }

    fun setLoudnessBoost(gainMb: Int) {
        val clamped = gainMb.coerceIn(0, 2000)
        try { loudnessEnhancer?.setTargetGain(clamped); loudnessEnhancer?.enabled = clamped > 0 } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(loudnessBoostMb = clamped)
        updateWarmthScore()
    }

    fun setReverbPreset(preset: Int) {
        try { presetReverb?.preset = preset.toShort(); presetReverb?.enabled = preset != 0 } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(reverbPreset = preset, isCustomMode = true)
    }

    fun setSubBassBoost(value: Int) {
        val clamped = value.coerceIn(0, 100)
        // Push band 0 (31Hz) and band 1 (62Hz) extra
        val baseGain = _dspState.value.currentMode.eqMb.getOrElse(0) { 0 }
        val extra = clamped * 3   // 0-300 mB extra
        nativeEQ.setVirtualBand(0, (baseGain + extra).coerceIn(-1500, 1500))
        _dspState.value = _dspState.value.copy(subBassBoost = clamped, isCustomMode = true)
        refreshBandState(); updateWarmthScore()
    }

    fun setStereoWidth(value: Int) {
        val clamped = value.coerceIn(0, 100)
        val virtCalc = ((clamped / 100f) * _dspState.value.virtualizerStrength).toInt().coerceIn(0, 1000)
        try { virtualizer?.setStrength(virtCalc.toShort()); virtualizer?.enabled = virtCalc > 0 } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(stereoWidth = clamped, isCustomMode = true)
    }

    fun setPresenceBoost(on: Boolean) {
        // Boost bands 8-10 (6k,8k,12k) by 200mB
        val gains = nativeEQ.getVirtualGains()
        listOf(8, 9, 10).forEach { i ->
            if (i < gains.size) {
                nativeEQ.setVirtualBand(i, (gains[i] + if (on) 200 else -200).coerceIn(-1500, 1500))
            }
        }
        _dspState.value = _dspState.value.copy(presenceBoost = on, isCustomMode = true)
        refreshBandState()
    }

    // ── Auto Genre Detection ──────────────────────────────────────────────────

    /**
     * Call this when track changes. If autoSwitchEnabled, detects genre
     * from title+artist and auto-applies best preset.
     * Returns DetectionResult if switched, null if no match or disabled.
     */
    fun autoDetectAndSwitch(title: String, artist: String): GenreDetector.DetectionResult? {
        if (!autoSwitchEnabled) return null
        if (title == lastAutoTitle) return null  // same track, skip
        lastAutoTitle = title

        val result = GenreDetector.detect(title, artist) ?: return null
        // Don't override if user manually set custom mode
        if (_dspState.value.isCustomMode) return null

        applyMode(result.mode)
        return result
    }

    fun setNightMode(on: Boolean) {
        if (on) applyMode(SoundMode.NIGHT_MODE) else applyMode(SoundMode.MUSIC_HD)
        _dspState.value = _dspState.value.copy(nightMode = on)
    }

    fun setDialogueEnhance(on: Boolean) {
        if (on) {
            nativeEQ.setVirtualBand(6, 1000)  // 2kHz
            nativeEQ.setVirtualBand(7, 1000)  // 4kHz
            nativeEQ.setVirtualBand(8, 800)   // 6kHz
        } else {
            applyMode(_dspState.value.currentMode)
        }
        _dspState.value = _dspState.value.copy(dialogueEnhance = on)
        refreshBandState()
    }

    fun setEnabled(enabled: Boolean) {
        nativeEQ.setEnabled(enabled)
        try { bassBoost?.enabled = enabled && _dspState.value.bassStrength > 0 } catch (_: Exception) {}
        try { virtualizer?.enabled = enabled && _dspState.value.virtualizerStrength > 0 } catch (_: Exception) {}
        try { loudnessEnhancer?.enabled = enabled && _dspState.value.loudnessBoostMb > 0 } catch (_: Exception) {}
        try { presetReverb?.enabled = enabled && _dspState.value.reverbPreset != 0 } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(isEnabled = enabled)
    }

    // ── Custom Presets ────────────────────────────────────────────────────────

    fun saveCustomPreset(name: String) {
        val state = _dspState.value
        val preset = CustomPreset(
            name = name,
            virtualGainsMb = nativeEQ.getVirtualGains().toList(),
            bassStrength = state.bassStrength,
            virtStrength = state.virtualizerStrength,
            loudnessMb = state.loudnessBoostMb,
            reverbPreset = state.reverbPreset,
            subBassBoost = state.subBassBoost,
            presenceBoost = state.presenceBoost,
            stereoWidth = state.stereoWidth
        )
        customPresets[name] = preset
        savePresetToDisk(preset)
        _dspState.value = state.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun loadCustomPreset(name: String) {
        val preset = customPresets[name] ?: return
        nativeEQ.setAllVirtualBands(preset.virtualGainsMb.toIntArray())
        setBassStrength(preset.bassStrength)
        setVirtualizerStrength(preset.virtStrength)
        setLoudnessBoost(preset.loudnessMb)
        setReverbPreset(preset.reverbPreset)
        _dspState.value = _dspState.value.copy(
            subBassBoost = preset.subBassBoost,
            presenceBoost = preset.presenceBoost,
            stereoWidth = preset.stereoWidth,
            isCustomMode = true,
            currentMode = SoundMode.CUSTOM
        )
        refreshBandState(); updateWarmthScore()
    }

    fun renameCustomPreset(oldName: String, newName: String) {
        val p = customPresets.remove(oldName) ?: return
        val renamed = p.copy(name = newName)
        customPresets[newName] = renamed
        deletePresetFromDisk(oldName); savePresetToDisk(renamed)
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun deleteCustomPreset(name: String) {
        customPresets.remove(name); deletePresetFromDisk(name)
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    private fun refreshBandState() {
        val states = nativeEQ.getVirtualBandStates()
        val bands = states.map { s ->
            BandState(
                index = s.index,
                centerFreqHz = s.freqHz,
                gainMb = s.gainMb,
                minMb = nativeEQ.getMinLevel(),
                maxMb = nativeEQ.getMaxLevel(),
                freqLabel = s.freqLabel,
                gainDb = s.gainMb / 100f
            )
        }
        _dspState.value = _dspState.value.copy(bands = bands)
    }

    private fun updateWarmthScore() {
        val s = _dspState.value
        val score = ((s.bassStrength / 10 + s.subBassBoost + s.loudnessBoostMb / 20) / 3).coerceIn(0, 100)
        _dspState.value = _dspState.value.copy(dspWarmthScore = score)
    }

    private fun savePresetToDisk(preset: CustomPreset) {
        try {
            val json = JSONObject().apply {
                put("name", preset.name)
                put("bands", JSONArray(preset.virtualGainsMb))
                put("bassStrength", preset.bassStrength)
                put("virtStrength", preset.virtStrength)
                put("loudnessMb", preset.loudnessMb)
                put("reverbPreset", preset.reverbPreset)
                put("subBassBoost", preset.subBassBoost)
                put("presenceBoost", preset.presenceBoost)
                put("stereoWidth", preset.stereoWidth)
            }
            prefs?.edit()?.putString("preset_${preset.name}", json.toString())?.apply()
            prefs?.edit()?.putString("preset_index", JSONArray(customPresets.keys.toList()).toString())?.apply()
        } catch (_: Exception) {}
    }

    private fun deletePresetFromDisk(name: String) {
        try {
            prefs?.edit()?.remove("preset_$name")?.apply()
            prefs?.edit()?.putString("preset_index", JSONArray(customPresets.keys.toList()).toString())?.apply()
        } catch (_: Exception) {}
    }

    private fun loadPresetsFromDisk() {
        try {
            val indexStr = prefs?.getString("preset_index", null) ?: return
            val names = JSONArray(indexStr)
            for (i in 0 until names.length()) {
                val name = names.getString(i)
                val jsonStr = prefs?.getString("preset_$name", null) ?: continue
                val json = JSONObject(jsonStr)
                val arr = json.getJSONArray("bands")
                val bands = (0 until arr.length()).map { arr.getInt(it) }
                customPresets[name] = CustomPreset(
                    name = name,
                    virtualGainsMb = bands,
                    bassStrength = json.optInt("bassStrength", 500),
                    virtStrength = json.optInt("virtStrength", 500),
                    loudnessMb = json.optInt("loudnessMb", 0),
                    reverbPreset = json.optInt("reverbPreset", 0),
                    subBassBoost = json.optInt("subBassBoost", 0),
                    presenceBoost = json.optBoolean("presenceBoost", false),
                    stereoWidth = json.optInt("stereoWidth", 50)
                )
            }
        } catch (_: Exception) {}
    }

    fun release() {
        nativeEQ.release()
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        try { loudnessEnhancer?.release() } catch (_: Exception) {}
        try { presetReverb?.release() } catch (_: Exception) {}
        bassBoost = null; virtualizer = null; loudnessEnhancer = null; presetReverb = null
        _dspState.value = _dspState.value.copy(isHardwareAttached = false)
    }
}
