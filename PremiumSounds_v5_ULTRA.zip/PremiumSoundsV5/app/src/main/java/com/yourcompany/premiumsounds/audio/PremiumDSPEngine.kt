package com.yourcompany.premiumsounds.audio

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * PremiumDSPEngine v5 ULTRA — 20-Band Software DSP
 *
 * Signal chain:
 * Input → BiquadEQProcessor (20-band software EQ, hardware-independent)
 *       → BassBoost → PresetReverb → Virtualizer → LoudnessEnhancer → Output
 */
class PremiumDSPEngine {

    private var context: Context? = null
    private var prefs: SharedPreferences? = null

    // Hardware effects (supplementary)
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var presetReverb: PresetReverb? = null

    // ── SOFTWARE 20-band biquad EQ (injected from service) ───────────────────
    var biquadEQ: BiquadEQProcessor? = null

    private val _dspState = MutableStateFlow(DSPState())
    val dspState: StateFlow<DSPState> = _dspState

    private val customPresets = mutableMapOf<String, CustomPreset>()

    // 20-band center frequencies — matches BiquadEQProcessor.BAND_FREQS
    val BAND_FREQS = floatArrayOf(
        25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f,
        1000f, 1600f, 2500f, 4000f, 6300f, 8000f,
        10000f, 12500f, 14000f, 16000f, 18000f, 20000f
    )
    val BAND_COUNT = 20

    // ── Data classes ──────────────────────────────────────────────────────────
    data class CustomPreset(
        val name: String,
        val bands: List<Int>,
        val bassStrength: Int,
        val virtStrength: Int,
        val loudnessMb: Int,
        val reverbPreset: Int,
        val subBassBoost: Int,      // NEW: 0-100 sub-bass extra push
        val presenceBoost: Boolean, // NEW: upper-mid clarity toggle
        val stereoWidth: Int        // NEW: 0-100 stereo width
    )

    data class DSPState(
        val currentMode: SoundMode = SoundMode.MUSIC_HD,
        val isEnabled: Boolean = true,
        val bands: List<BandState> = emptyList(),       // software 20-band state
        val bassStrength: Int = 500,
        val virtualizerStrength: Int = 500,
        val loudnessBoostMb: Int = 0,
        val reverbPreset: Int = 0,
        val dialogueEnhance: Boolean = false,
        val nightMode: Boolean = false,
        val isHardwareAttached: Boolean = false,
        val savedCustomPresets: List<String> = emptyList(),
        val subBassBoost: Int = 0,
        val presenceBoost: Boolean = false,
        val stereoWidth: Int = 50,
        val dspWarmthScore: Int = 0,
        val isCustomMode: Boolean = false,
        val softwareEQActive: Boolean = true   // true = software 20-band running
    )

    data class BandState(
        val index: Int,
        val centerFreqHz: Int,
        val levelMb: Int,       // in millibels for compat, but SW EQ uses dB directly
        val minLevelMb: Int,
        val maxLevelMb: Int,
        val freqLabel: String,
        val gainDb: Float = 0f  // actual software EQ gain in dB
    )

    // ── Sound Modes — 17 total ────────────────────────────────────────────────
    enum class SoundMode(
        val label: String,
        val emoji: String,
        val description: String,
        // 20-band SW EQ gains in dB (float): matches BiquadEQProcessor.BAND_FREQS
        // [25,40,63,100,160,250,400,630,1k,1.6k,2.5k,4k,6.3k,8k,10k,12.5k,14k,16k,18k,20k]
        val eqBands: List<Float>,
        val bassStrength: Int,
        val virtStrength: Int,
        val loudnessMb: Int,
        val reverbPreset: Int,
        val subBassBoost: Int,
        val presenceBoost: Boolean,
        val stereoWidth: Int,
        val accentHex: Long
    ) {
        FLAT(
            "Flat", "◼", "Pure unprocessed signal",
            listOf(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f),
            0,0,0,0,0,false,50,0xFF888899L
        ),
        MUSIC_HD(
            "Music HD", "🎵", "Balanced richness for all genres",
            listOf(3f,4f,3.5f,2f,1f,0f,0.5f,1f,1.5f,2f,2.5f,3f,3.5f,4f,3.5f,3f,2.5f,2f,1f,0.5f),
            450,550,400,0,20,false,60,0xFF00D4FFL
        ),
        BASS_MONSTER(
            "Bass Monster", "🔊", "Max sub-bass punch",
            listOf(10f,12f,10f,8f,6f,3f,-1f,-2f,-2f,-1f,0f,0.5f,1f,1f,0.5f,0f,0f,-1f,-1f,-2f),
            1000,200,500,0,100,false,40,0xFF7C4DFFL
        ),
        CINEMA(
            "Cinema", "🎬", "Wide surround + loud dialogue",
            listOf(6f,5f,4f,3f,2f,1f,0.5f,1f,3f,5f,6f,5f,4f,3f,2f,1.5f,1f,0.5f,0f,-0.5f),
            500,950,700,5,30,true,80,0xFFFF6B6BL
        ),
        GAME(
            "Game", "🎮", "3D positional spatial audio",
            listOf(4f,5f,4f,3f,1f,-1f,0f,1f,2f,3f,4f,5f,6f,5f,4f,3f,2f,1.5f,1f,0.5f),
            600,1000,400,1,20,false,85,0xFF00E676L
        ),
        PODCAST(
            "Podcast", "🎙️", "Voice clarity, cut rumble",
            listOf(-8f,-7f,-5f,-2f,0f,1f,2f,3f,7f,9f,10f,8f,6f,4f,2f,1f,0.5f,0f,-0.5f,-1f),
            0,200,900,0,0,true,40,0xFFFFC94DL
        ),
        NIGHT_MODE(
            "Night Mode", "🌙", "Smooth dynamics, low-vol comfort",
            listOf(3f,2.5f,2f,1.5f,1f,0.5f,0f,0.5f,1f,1.5f,1f,0.5f,0f,-0.5f,-1f,-1.5f,-2f,-2f,-2.5f,-3f),
            200,150,1400,0,10,false,45,0xFF4A90D9L
        ),
        CONCERT_HALL(
            "Concert Hall", "🎻", "Live acoustic hall simulation",
            listOf(4f,3.5f,3f,2f,0f,-1f,-0.5f,0f,1f,2f,3f,4f,5f,5.5f,6f,5.5f,5f,4f,3f,2f),
            150,800,200,5,0,false,75,0xFFE040FBL
        ),
        DEEP_SPACE(
            "Deep Space", "🚀", "Maximum 3D immersion",
            listOf(7f,6.5f,5f,4f,2f,1f,0.5f,1f,2f,3f,4f,5f,6f,7f,7.5f,7f,6f,5f,4f,3f),
            400,1000,600,3,40,false,90,0xFF00BCD4L
        ),
        VOCAL_BOOST(
            "Vocal Boost", "🎤", "Enhanced singer clarity",
            listOf(-6f,-5f,-3f,-1f,0f,1f,2f,3f,6f,9f,10f,9f,7f,5f,3f,2f,1.5f,1f,0.5f,0f),
            100,350,600,0,0,true,55,0xFFFF9800L
        ),
        ROCK(
            "Rock", "🎸", "Punchy mids, aggressive highs",
            listOf(8f,7f,6f,4f,1f,-1f,-0.5f,1f,3f,4f,5f,6f,7f,8f,8f,7.5f,7f,6f,5f,4f),
            800,600,300,0,30,true,65,0xFFFF5252L
        ),
        CLASSICAL(
            "Classical", "🎼", "Natural warmth, airy highs",
            listOf(4f,3.5f,3f,2f,0f,-2f,-3f,-2f,-1f,0f,0.5f,1f,2f,3f,4f,5f,6f,6.5f,6f,5f),
            100,400,150,4,0,false,70,0xFFF8BBD0L
        ),
        HIP_HOP(
            "Hip Hop", "🎤", "Heavy bass + crisp hi-hats",
            listOf(9f,10f,8f,6f,3f,0f,-1f,-0.5f,0f,0.5f,1f,1.5f,2f,4f,5f,6f,6.5f,6f,5f,4f),
            950,500,500,0,70,false,60,0xFFFF6B00L
        ),
        EDM(
            "EDM", "⚡", "Club bass drop + air",
            listOf(10f,11f,9f,6f,2f,-2f,-3f,-1f,0f,1f,2f,3f,5f,7f,9f,10f,10f,9f,8f,7f),
            950,900,600,2,80,false,80,0xFF00E5FFL
        ),
        LOFI(
            "Lo-Fi", "☕", "Warm vintage cassette feel",
            listOf(5f,4.5f,4f,3f,2f,1f,0f,-1f,-2f,-3f,-4f,-5f,-6f,-7f,-8f,-9f,-10f,-11f,-12f,-13f),
            300,100,100,1,20,false,35,0xFFD4A04DL
        ),
        JAZZ(
            "Jazz", "🎺", "Warm mids, smooth highs",
            listOf(3f,4f,5f,5f,4f,3f,2f,1f,0f,-0.5f,0f,0.5f,1f,1.5f,2f,2f,1.5f,1f,0.5f,0f),
            200,300,200,3,10,false,60,0xFFFFD54FL
        ),
        CUSTOM(
            "Custom", "🎛️", "Your personal sound signature",
            listOf(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f),
            500,500,400,0,30,false,60,0xFF9C27B0L
        )
    }

    // ── Init with context for persistence ─────────────────────────────────────
    fun init(ctx: Context) {
        context = ctx.applicationContext
        prefs = context?.getSharedPreferences("dsp_custom_presets_v5", Context.MODE_PRIVATE)
        loadPresetsFromDisk()
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
        // Init software bands immediately (biquadEQ gets set later from service)
        refreshSoftwareBandState()
    }

    /** Called by service after biquadEQ is set, to sync initial band state */
    fun onBiquadAttached() {
        applyMode(_dspState.value.currentMode)
        refreshSoftwareBandState()
    }

    // ── Attach to audio session ────────────────────────────────────────────────
    fun attach(audioSessionId: Int) {
        release()
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(0); enabled = false
            }
            presetReverb = try {
                PresetReverb(0, audioSessionId).apply { enabled = false }
            } catch (_: Exception) { null }

            _dspState.value = _dspState.value.copy(isHardwareAttached = true)
            applyMode(_dspState.value.currentMode)
        } catch (e: Exception) {
            e.printStackTrace()
            _dspState.value = _dspState.value.copy(isHardwareAttached = false)
        }
    }

    // ── Apply full sound mode ──────────────────────────────────────────────────
    fun applyMode(mode: SoundMode) {
        // ── SOFTWARE 20-band biquad EQ (primary, always works) ────────────────
        val bq = biquadEQ
        if (bq != null) {
            bq.setAllGains(mode.eqBands)
            bq.setEnabled(true)
        }

        // ── Hardware EQ (supplementary, if available) ─────────────────────────
        val eq = equalizer
        if (eq != null) {
            val bandCount = eq.numberOfBands.toInt()
            // Convert float dB gains to mB for hardware EQ (1dB = 100mB)
            val mBands = mode.eqBands.map { (it * 100).toInt() }
            applyEQBands(eq, mBands, bandCount)
        }

        // Sub-bass hardware push
        if (mode.subBassBoost > 0 && eq != null && eq.numberOfBands > 0) {
            try {
                val current = eq.getBandLevel(0).toInt()
                val extra = mode.subBassBoost * 3
                eq.setBandLevel(0, (current + extra).coerceIn(-1500, 1500).toShort())
            } catch (_: Exception) {}
        }


        }

        // 3. Bass Boost
        try {
            bassBoost?.setStrength(mode.bassStrength.toShort())
            bassBoost?.enabled = mode.bassStrength > 0
        } catch (_: Exception) {}

        // 4. Virtualizer (stereo width)
        val virtStrength = ((mode.stereoWidth / 100f) * mode.virtStrength).toInt()
        try {
            virtualizer?.setStrength(virtStrength.coerceIn(0, 1000).toShort())
            virtualizer?.enabled = virtStrength > 0
        } catch (_: Exception) {}

        // 5. Loudness
        try {
            loudnessEnhancer?.setTargetGain(mode.loudnessMb)
            loudnessEnhancer?.enabled = mode.loudnessMb > 0
        } catch (_: Exception) {}

        // 6. Reverb
        try {
            presetReverb?.preset = mode.reverbPreset.toShort()
            presetReverb?.enabled = mode.reverbPreset != 0
        } catch (_: Exception) {}

        // 7. Presence boost (upper-mid clarity on bands 5-7)
        if (mode.presenceBoost && bandCount >= 7) {
            try {
                val presenceBands = minOf(3, bandCount - 5)
                for (bi in 5 until 5 + presenceBands) {
                    val cur = eq.getBandLevel(bi.toShort()).toInt()
                    eq.setBandLevel(bi.toShort(), (cur + 200).coerceIn(-1500, 1500).toShort())
                }
            } catch (_: Exception) {}
        }

        _dspState.value = _dspState.value.copy(
            currentMode = mode,
            bassStrength = mode.bassStrength,
            virtualizerStrength = mode.virtStrength,
            loudnessBoostMb = mode.loudnessMb,
            reverbPreset = mode.reverbPreset,
            subBassBoost = mode.subBassBoost,
            presenceBoost = mode.presenceBoost,
            stereoWidth = mode.stereoWidth,
            nightMode = mode == SoundMode.NIGHT_MODE,
            isCustomMode = mode == SoundMode.CUSTOM
        )
        refreshBandState()
        updateWarmthScore()
    }

    private fun applyEQBands(eq: Equalizer, targetBands: List<Int>, bandCount: Int) {
        when {
            bandCount == targetBands.size -> {
                // Exact match
                targetBands.forEachIndexed { i, lvl ->
                    try { eq.setBandLevel(i.toShort(), lvl.toShort()) } catch (_: Exception) {}
                }
            }
            bandCount < targetBands.size -> {
                // Fewer bands: average down
                val step = targetBands.size.toFloat() / bandCount
                for (i in 0 until bandCount) {
                    val start = (i * step).toInt()
                    val end = ((i + 1) * step).toInt().coerceAtMost(targetBands.size)
                    val avg = if (end > start) targetBands.subList(start, end).average().toInt() else 0
                    try { eq.setBandLevel(i.toShort(), avg.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
                }
            }
            else -> {
                // More bands: interpolate up
                targetBands.take(bandCount).forEachIndexed { i, lvl ->
                    try { eq.setBandLevel(i.toShort(), lvl.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
                }
                // Fill extra bands by extrapolating last value
                val last = targetBands.lastOrNull() ?: 0
                for (i in targetBands.size until bandCount) {
                    try { eq.setBandLevel(i.toShort(), last.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
                }
            }
        }
    }

    // ── Manual fine-tune controls ──────────────────────────────────────────────
    /** bandIndex: 0-19 for software 20-band EQ. gainDb: -15 to +15 */
    fun setBandLevel(bandIndex: Int, gainDb: Float) {
        // Software biquad (primary)
        biquadEQ?.setBandGain(bandIndex, gainDb)
        // Hardware EQ sync (convert dB -> mB, map to available bands)
        try {
            val eq = equalizer
            if (eq != null) {
                val hwBand = (bandIndex * eq.numberOfBands / BAND_COUNT).coerceIn(0, eq.numberOfBands - 1)
                eq.setBandLevel(hwBand.toShort(), (gainDb * 100).toInt().coerceIn(-1500, 1500).toShort())
            }
        } catch (_: Exception) {}
        refreshSoftwareBandState()
        updateWarmthScore()
        if (_dspState.value.currentMode != SoundMode.CUSTOM) {
            _dspState.value = _dspState.value.copy(isCustomMode = true)
        }
    }

    // Legacy mB overload for compat
    fun setBandLevel(bandIndex: Int, levelMb: Int) {
        setBandLevel(bandIndex, levelMb / 100f)
    }

    fun setBassStrength(strength: Int) {
        try {
            val clamped = strength.coerceIn(0, 1000)
            bassBoost?.setStrength(clamped.toShort())
            bassBoost?.enabled = clamped > 0
            _dspState.value = _dspState.value.copy(bassStrength = clamped, isCustomMode = true)
            updateWarmthScore()
        } catch (_: Exception) {}
    }

    fun setVirtualizerStrength(strength: Int) {
        try {
            val clamped = strength.coerceIn(0, 1000)
            virtualizer?.setStrength(clamped.toShort())
            virtualizer?.enabled = clamped > 0
            _dspState.value = _dspState.value.copy(virtualizerStrength = clamped, isCustomMode = true)
        } catch (_: Exception) {}
    }

    fun setLoudnessBoost(gainMb: Int) {
        try {
            val clamped = gainMb.coerceIn(0, 2000)
            loudnessEnhancer?.setTargetGain(clamped)
            loudnessEnhancer?.enabled = clamped > 0
            _dspState.value = _dspState.value.copy(loudnessBoostMb = clamped)
            updateWarmthScore()
        } catch (_: Exception) {}
    }

    fun setReverbPreset(preset: Int) {
        try {
            presetReverb?.preset = preset.toShort()
            presetReverb?.enabled = preset != 0
            _dspState.value = _dspState.value.copy(reverbPreset = preset, isCustomMode = true)
        } catch (_: Exception) {}
    }

    // NEW: Sub-bass dedicated control
    fun setSubBassBoost(value: Int) {
        try {
            val clamped = value.coerceIn(0, 100)
            val eq = equalizer
            if (eq != null && eq.numberOfBands > 0) {
                val extra = (clamped * 3)  // up to +300 mB on sub-bass band
                val base = _dspState.value.currentMode.eqBands.getOrElse(0) { 0 }
                eq.setBandLevel(0, (base + extra).coerceIn(-1500, 1500).toShort())
                refreshBandState()
            }
            _dspState.value = _dspState.value.copy(subBassBoost = clamped, isCustomMode = true)
            updateWarmthScore()
        } catch (_: Exception) {}
    }

    // NEW: Stereo width control
    fun setStereoWidth(value: Int) {
        try {
            val clamped = value.coerceIn(0, 100)
            val virtCalc = ((clamped / 100f) * _dspState.value.virtualizerStrength).toInt()
            virtualizer?.setStrength(virtCalc.coerceIn(0, 1000).toShort())
            virtualizer?.enabled = virtCalc > 0
            _dspState.value = _dspState.value.copy(stereoWidth = clamped, isCustomMode = true)
        } catch (_: Exception) {}
    }

    // NEW: Presence boost (upper-mid air)
    fun setPresenceBoost(on: Boolean) {
        val eq = equalizer ?: run {
            _dspState.value = _dspState.value.copy(presenceBoost = on)
            return
        }
        try {
            val bandCount = eq.numberOfBands.toInt()
            if (bandCount >= 7) {
                val presenceBands = minOf(3, bandCount - 5)
                for (bi in 5 until 5 + presenceBands) {
                    val cur = eq.getBandLevel(bi.toShort()).toInt()
                    val target = if (on) (cur + 200).coerceIn(-1500, 1500) else (cur - 200).coerceIn(-1500, 1500)
                    eq.setBandLevel(bi.toShort(), target.toShort())
                }
                refreshBandState()
            }
        } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(presenceBoost = on, isCustomMode = true)
    }

    fun setNightMode(on: Boolean) {
        if (on) applyMode(SoundMode.NIGHT_MODE)
        else applyMode(SoundMode.MUSIC_HD)
        _dspState.value = _dspState.value.copy(nightMode = on)
    }

    fun setDialogueEnhance(on: Boolean) {
        val eq = equalizer ?: return
        try {
            val bandCount = eq.numberOfBands.toInt()
            if (on) {
                if (bandCount > 4) eq.setBandLevel(4, 1000)
                if (bandCount > 5) eq.setBandLevel(5, 1000)
                if (bandCount > 6) eq.setBandLevel(6, 800)
            } else {
                applyMode(_dspState.value.currentMode)
            }
            _dspState.value = _dspState.value.copy(dialogueEnhance = on)
            refreshBandState()
        } catch (_: Exception) {}
    }

    fun setEnabled(enabled: Boolean) {
        equalizer?.enabled = enabled
        bassBoost?.enabled = enabled && _dspState.value.bassStrength > 0
        virtualizer?.enabled = enabled && _dspState.value.virtualizerStrength > 0
        loudnessEnhancer?.enabled = enabled && _dspState.value.loudnessBoostMb > 0
        presetReverb?.enabled = enabled && _dspState.value.reverbPreset != 0
        _dspState.value = _dspState.value.copy(isEnabled = enabled)
    }

    // ── Custom Preset Save/Load/Rename (with disk persistence) ────────────────
    fun saveCustomPreset(name: String) {
        val state = _dspState.value
        val preset = CustomPreset(
            name = name,
            bands = state.bands.map { it.levelMb },
            bassStrength = state.bassStrength,
            virtStrength = state.virtualizerStrength,
            loudnessMb = state.loudnessBoostMb,
            reverbPreset = state.reverbPreset,
            subBassBoost = state.subBassBoost,
            presenceBoost = state.presenceBoost,
            stereoWidth = state.stereoWidth
        )
        customPresets[name] = preset
        savePresetToDisk(preset)
        _dspState.value = state.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun loadCustomPreset(name: String) {
        val preset = customPresets[name] ?: return
        val eq = equalizer ?: run {
            _dspState.value = _dspState.value.copy(
                bassStrength = preset.bassStrength,
                virtualizerStrength = preset.virtStrength,
                loudnessBoostMb = preset.loudnessMb,
                reverbPreset = preset.reverbPreset,
                subBassBoost = preset.subBassBoost,
                presenceBoost = preset.presenceBoost,
                stereoWidth = preset.stereoWidth,
                isCustomMode = true
            )
            return
        }
        val bandCount = eq.numberOfBands.toInt()
        preset.bands.take(bandCount).forEachIndexed { i, lvl ->
            try { eq.setBandLevel(i.toShort(), lvl.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
        }
        setBassStrength(preset.bassStrength)
        setVirtualizerStrength(preset.virtStrength)
        setLoudnessBoost(preset.loudnessMb)
        setReverbPreset(preset.reverbPreset)
        _dspState.value = _dspState.value.copy(
            subBassBoost = preset.subBassBoost,
            presenceBoost = preset.presenceBoost,
            stereoWidth = preset.stereoWidth,
            isCustomMode = true,
            currentMode = SoundMode.CUSTOM
        )
        refreshBandState()
        updateWarmthScore()
    }

    fun renameCustomPreset(oldName: String, newName: String) {
        val preset = customPresets.remove(oldName) ?: return
        val renamed = preset.copy(name = newName)
        customPresets[newName] = renamed
        deletePresetFromDisk(oldName)
        savePresetToDisk(renamed)
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun deleteCustomPreset(name: String) {
        customPresets.remove(name)
        deletePresetFromDisk(name)
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun getCustomPresets(): Map<String, CustomPreset> = customPresets.toMap()

    // ── DSP Warmth Score (0-100) ───────────────────────────────────────────────
    private fun updateWarmthScore() {
        val state = _dspState.value
        val bassScore = state.bassStrength / 10
        val subScore = state.subBassBoost
        val loudScore = (state.loudnessBoostMb / 20)
        val warmth = ((bassScore + subScore + loudScore) / 3).coerceIn(0, 100)
        _dspState.value = _dspState.value.copy(dspWarmthScore = warmth)
    }

    // ── Internal helpers ───────────────────────────────────────────────────────

    /** Always shows 20 software bands from biquad gains */
    private fun refreshSoftwareBandState() {
        val gains = biquadEQ?.getGains() ?: FloatArray(BAND_COUNT) { 0f }
        val bands = (0 until BAND_COUNT).map { i ->
            val gainDb = gains.getOrElse(i) { 0f }
            BandState(
                index = i,
                centerFreqHz = BAND_FREQS[i].toInt(),
                levelMb = (gainDb * 100).toInt(),
                minLevelMb = -1500,
                maxLevelMb = 1500,
                freqLabel = formatFreqFloat(BAND_FREQS[i]),
                gainDb = gainDb
            )
        }
        _dspState.value = _dspState.value.copy(
            bands = bands,
            softwareEQActive = biquadEQ != null
        )
    }

    private fun refreshBandState() = refreshSoftwareBandState()

    private fun formatFreqFloat(hz: Float): String = when {
        hz >= 1000f -> {
            val k = hz / 1000f
            if (k == k.toInt().toFloat()) "${k.toInt()}kHz" else "${String.format("%.1f", k)}kHz"
        }
        else -> "${hz.toInt()}Hz"
    }

    private fun formatFreq(hz: Int): String = when {
        hz >= 1000 -> "${hz / 1000}kHz"
        else -> "${hz}Hz"
    }

    // ── Disk Persistence ──────────────────────────────────────────────────────
    private fun savePresetToDisk(preset: CustomPreset) {
        try {
            val json = JSONObject().apply {
                put("name", preset.name)
                put("bands", JSONArray(preset.bands))
                put("bassStrength", preset.bassStrength)
                put("virtStrength", preset.virtStrength)
                put("loudnessMb", preset.loudnessMb)
                put("reverbPreset", preset.reverbPreset)
                put("subBassBoost", preset.subBassBoost)
                put("presenceBoost", preset.presenceBoost)
                put("stereoWidth", preset.stereoWidth)
            }
            prefs?.edit()?.putString("preset_${preset.name}", json.toString())?.apply()
            // Update index
            val names = customPresets.keys.toSet()
            prefs?.edit()?.putString("preset_index", JSONArray(names.toList()).toString())?.apply()
        } catch (_: Exception) {}
    }

    private fun deletePresetFromDisk(name: String) {
        try {
            prefs?.edit()?.remove("preset_$name")?.apply()
            val remaining = customPresets.keys.toList()
            prefs?.edit()?.putString("preset_index", JSONArray(remaining).toString())?.apply()
        } catch (_: Exception) {}
    }

    private fun loadPresetsFromDisk() {
        try {
            val indexStr = prefs?.getString("preset_index", null) ?: return
            val names = JSONArray(indexStr)
            for (i in 0 until names.length()) {
                val name = names.getString(i)
                val jsonStr = prefs?.getString("preset_$name", null) ?: continue
                val json = JSONObject(jsonStr)
                val bandsArr = json.getJSONArray("bands")
                val bands = (0 until bandsArr.length()).map { bandsArr.getInt(it) }
                customPresets[name] = CustomPreset(
                    name = name,
                    bands = bands,
                    bassStrength = json.optInt("bassStrength", 500),
                    virtStrength = json.optInt("virtStrength", 500),
                    loudnessMb = json.optInt("loudnessMb", 0),
                    reverbPreset = json.optInt("reverbPreset", 0),
                    subBassBoost = json.optInt("subBassBoost", 0),
                    presenceBoost = json.optBoolean("presenceBoost", false),
                    stereoWidth = json.optInt("stereoWidth", 50)
                )
            }
        } catch (_: Exception) {}
    }

    fun release() {
        listOf(equalizer, bassBoost, virtualizer, loudnessEnhancer, presetReverb).forEach {
            try { it?.release() } catch (_: Exception) {}
        }
        equalizer = null; bassBoost = null; virtualizer = null
        loudnessEnhancer = null; presetReverb = null
        _dspState.value = _dspState.value.copy(isHardwareAttached = false, bands = emptyList())
    }
}
