package com.yourcompany.premiumsounds.audio

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * PremiumDSPEngine v5 ULTRA
 * Signal chain:
 * Input → BiquadEQProcessor (20-band SW EQ) → BassBoost → PresetReverb
 *       → Virtualizer → LoudnessEnhancer → Output
 */
class PremiumDSPEngine {

    private var context: Context? = null
    private var prefs: SharedPreferences? = null

    // Hardware effects (supplementary)
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var presetReverb: PresetReverb? = null

    // Software 20-band biquad EQ (primary, set from service)
    var biquadEQ: BiquadEQProcessor? = null

    private val _dspState = MutableStateFlow(DSPState())
    val dspState: StateFlow<DSPState> = _dspState

    private val customPresets = mutableMapOf<String, CustomPreset>()

    // 20-band SW EQ frequencies — matches BiquadEQProcessor
    val BAND_FREQS = floatArrayOf(
        25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f,
        1000f, 1600f, 2500f, 4000f, 6300f, 8000f,
        10000f, 12500f, 14000f, 16000f, 18000f, 20000f
    )
    val BAND_COUNT = 20

    // ── Data Classes ──────────────────────────────────────────────────────────

    data class CustomPreset(
        val name: String,
        val bands: List<Float>,
        val bassStrength: Int,
        val virtStrength: Int,
        val loudnessMb: Int,
        val reverbPreset: Int,
        val subBassBoost: Int,
        val presenceBoost: Boolean,
        val stereoWidth: Int
    )

    data class DSPState(
        val currentMode: SoundMode = SoundMode.MUSIC_HD,
        val isEnabled: Boolean = true,
        val bands: List<BandState> = emptyList(),
        val bassStrength: Int = 500,
        val virtualizerStrength: Int = 500,
        val loudnessBoostMb: Int = 0,
        val reverbPreset: Int = 0,
        val dialogueEnhance: Boolean = false,
        val nightMode: Boolean = false,
        val isHardwareAttached: Boolean = false,
        val savedCustomPresets: List<String> = emptyList(),
        val subBassBoost: Int = 0,
        val presenceBoost: Boolean = false,
        val stereoWidth: Int = 50,
        val dspWarmthScore: Int = 0,
        val isCustomMode: Boolean = false,
        val softwareEQActive: Boolean = false,
        val bassExciterLevel: Int = 47,
        val compressorLevel: Int = 63,
        val compressorEnabled: Boolean = true,
        val surroundLevel: Int = 81,
        val autoGenreSwitch: Boolean = true
    )

    data class BandState(
        val index: Int,
        val centerFreqHz: Int,
        val levelMb: Int,
        val minLevelMb: Int = -1500,
        val maxLevelMb: Int = 1500,
        val freqLabel: String,
        val gainDb: Float = 0f
    )

    // ── Sound Modes ───────────────────────────────────────────────────────────
    // 20-band gains in dB: [25,40,63,100,160,250,400,630,1k,1.6k,2.5k,4k,6.3k,8k,10k,12.5k,14k,16k,18k,20k]
    enum class SoundMode(
        val label: String,
        val emoji: String,
        val description: String,
        val eqBands: List<Float>,
        val bassStrength: Int,
        val virtStrength: Int,
        val loudnessMb: Int,
        val reverbPreset: Int,
        val subBassBoost: Int,
        val presenceBoost: Boolean,
        val stereoWidth: Int,
        val accentHex: Long
    ) {
        FLAT("Flat","◼","Pure unprocessed signal",
            listOf(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f),
            0,0,0,0,0,false,50,0xFF888899L),
        MUSIC_HD("Music HD","🎵","Balanced richness for all genres",
            listOf(3f,4f,3.5f,2f,1f,0f,0.5f,1f,1.5f,2f,2.5f,3f,3.5f,4f,3.5f,3f,2.5f,2f,1f,0.5f),
            450,550,400,0,20,false,60,0xFF00D4FFL),
        BASS_MONSTER("Bass Monster","🔊","Max sub-bass punch",
            listOf(10f,12f,10f,8f,6f,3f,-1f,-2f,-2f,-1f,0f,0.5f,1f,1f,0.5f,0f,0f,-1f,-1f,-2f),
            1000,200,500,0,100,false,40,0xFF7C4DFFL),
        CINEMA("Cinema","🎬","Wide surround + loud dialogue",
            listOf(6f,5f,4f,3f,2f,1f,0.5f,1f,3f,5f,6f,5f,4f,3f,2f,1.5f,1f,0.5f,0f,-0.5f),
            500,950,700,5,30,true,80,0xFFFF6B6BL),
        GAME("Game","🎮","3D positional spatial audio",
            listOf(4f,5f,4f,3f,1f,-1f,0f,1f,2f,3f,4f,5f,6f,5f,4f,3f,2f,1.5f,1f,0.5f),
            600,1000,400,1,20,false,85,0xFF00E676L),
        PODCAST("Podcast","🎙️","Voice clarity, cut rumble",
            listOf(-8f,-7f,-5f,-2f,0f,1f,2f,3f,7f,9f,10f,8f,6f,4f,2f,1f,0.5f,0f,-0.5f,-1f),
            0,200,900,0,0,true,40,0xFFFFC94DL),
        NIGHT_MODE("Night Mode","🌙","Smooth dynamics, low-vol comfort",
            listOf(3f,2.5f,2f,1.5f,1f,0.5f,0f,0.5f,1f,1.5f,1f,0.5f,0f,-0.5f,-1f,-1.5f,-2f,-2f,-2.5f,-3f),
            200,150,1400,0,10,false,45,0xFF4A90D9L),
        CONCERT_HALL("Concert Hall","🎻","Live acoustic hall simulation",
            listOf(4f,3.5f,3f,2f,0f,-1f,-0.5f,0f,1f,2f,3f,4f,5f,5.5f,6f,5.5f,5f,4f,3f,2f),
            150,800,200,5,0,false,75,0xFFE040FBL),
        DEEP_SPACE("Deep Space","🚀","Maximum 3D immersion",
            listOf(7f,6.5f,5f,4f,2f,1f,0.5f,1f,2f,3f,4f,5f,6f,7f,7.5f,7f,6f,5f,4f,3f),
            400,1000,600,3,40,false,90,0xFF00BCD4L),
        VOCAL_BOOST("Vocal Boost","🎤","Enhanced singer clarity",
            listOf(-6f,-5f,-3f,-1f,0f,1f,2f,3f,6f,9f,10f,9f,7f,5f,3f,2f,1.5f,1f,0.5f,0f),
            100,350,600,0,0,true,55,0xFFFF9800L),
        ROCK("Rock","🎸","Punchy mids, aggressive highs",
            listOf(8f,7f,6f,4f,1f,-1f,-0.5f,1f,3f,4f,5f,6f,7f,8f,8f,7.5f,7f,6f,5f,4f),
            800,600,300,0,30,true,65,0xFFFF5252L),
        CLASSICAL("Classical","🎼","Natural warmth, airy highs",
            listOf(4f,3.5f,3f,2f,0f,-2f,-3f,-2f,-1f,0f,0.5f,1f,2f,3f,4f,5f,6f,6.5f,6f,5f),
            100,400,150,4,0,false,70,0xFFF8BBD0L),
        HIP_HOP("Hip Hop","🎤","Heavy bass + crisp hi-hats",
            listOf(9f,10f,8f,6f,3f,0f,-1f,-0.5f,0f,0.5f,1f,1.5f,2f,4f,5f,6f,6.5f,6f,5f,4f),
            950,500,500,0,70,false,60,0xFFFF6B00L),
        EDM("EDM","⚡","Club bass drop + air",
            listOf(10f,11f,9f,6f,2f,-2f,-3f,-1f,0f,1f,2f,3f,5f,7f,9f,10f,10f,9f,8f,7f),
            950,900,600,2,80,false,80,0xFF00E5FFL),
        LOFI("Lo-Fi","☕","Warm vintage cassette feel",
            listOf(5f,4.5f,4f,3f,2f,1f,0f,-1f,-2f,-3f,-4f,-5f,-6f,-7f,-8f,-9f,-10f,-11f,-12f,-13f),
            300,100,100,1,20,false,35,0xFFD4A04DL),
        JAZZ("Jazz","🎺","Warm mids, smooth highs",
            listOf(3f,4f,5f,5f,4f,3f,2f,1f,0f,-0.5f,0f,0.5f,1f,1.5f,2f,2f,1.5f,1f,0.5f,0f),
            200,300,200,3,10,false,60,0xFFFFD54FL),
        CUSTOM("Custom","🎛️","Your personal sound signature",
            listOf(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f),
            500,500,400,0,30,false,60,0xFF9C27B0L)
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    fun init(ctx: Context) {
        context = ctx.applicationContext
        prefs = context?.getSharedPreferences("dsp_custom_presets_v5", Context.MODE_PRIVATE)
        loadPresetsFromDisk()
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
        refreshSoftwareBandState()
    }

    fun onBiquadAttached() {
        applyMode(_dspState.value.currentMode)
        refreshSoftwareBandState()
    }

    // ── Hardware Attach ───────────────────────────────────────────────────────

    fun attach(audioSessionId: Int) {
        release()
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(0); enabled = false
            }
            presetReverb = try {
                PresetReverb(0, audioSessionId).apply { enabled = false }
            } catch (_: Exception) { null }
            _dspState.value = _dspState.value.copy(isHardwareAttached = true)
            applyMode(_dspState.value.currentMode)
        } catch (e: Exception) {
            e.printStackTrace()
            _dspState.value = _dspState.value.copy(isHardwareAttached = false)
        }
    }

    // ── Apply Mode ────────────────────────────────────────────────────────────

    fun applyMode(mode: SoundMode) {
        // 1. Software 20-band biquad (primary)
        biquadEQ?.setAllGains(mode.eqBands)
        biquadEQ?.setEnabled(true)

        // 2. Hardware EQ (supplementary, if available)
        val eq = equalizer
        if (eq != null) {
            val bandCount = eq.numberOfBands.toInt()
            val mBands = mode.eqBands.map { (it * 100).toInt() }
            applyEQBands(eq, mBands, bandCount)
        }

        // 3. Sub-bass hardware push
        if (mode.subBassBoost > 0 && eq != null && eq.numberOfBands > 0) {
            try {
                val current = eq.getBandLevel(0).toInt()
                val extra = mode.subBassBoost * 3
                eq.setBandLevel(0, (current + extra).coerceIn(-1500, 1500).toShort())
            } catch (_: Exception) {}
        }

        // 4. BassBoost
        try {
            bassBoost?.setStrength(mode.bassStrength.toShort())
            bassBoost?.enabled = mode.bassStrength > 0
        } catch (_: Exception) {}

        // 5. Virtualizer
        val virtCalc = ((mode.stereoWidth / 100f) * mode.virtStrength).toInt()
        try {
            virtualizer?.setStrength(virtCalc.coerceIn(0, 1000).toShort())
            virtualizer?.enabled = virtCalc > 0
        } catch (_: Exception) {}

        // 6. Loudness
        try {
            loudnessEnhancer?.setTargetGain(mode.loudnessMb)
            loudnessEnhancer?.enabled = mode.loudnessMb > 0
        } catch (_: Exception) {}

        // 7. Reverb
        try {
            presetReverb?.preset = mode.reverbPreset.toShort()
            presetReverb?.enabled = mode.reverbPreset != 0
        } catch (_: Exception) {}

        // 8. Presence boost
        if (mode.presenceBoost && eq != null && eq.numberOfBands >= 7) {
            try {
                val bc = eq.numberOfBands.toInt()
                for (bi in 5 until minOf(8, bc)) {
                    val cur = eq.getBandLevel(bi.toShort()).toInt()
                    eq.setBandLevel(bi.toShort(), (cur + 200).coerceIn(-1500, 1500).toShort())
                }
            } catch (_: Exception) {}
        }

        _dspState.value = _dspState.value.copy(
            currentMode = mode,
            bassStrength = mode.bassStrength,
            virtualizerStrength = mode.virtStrength,
            loudnessBoostMb = mode.loudnessMb,
            reverbPreset = mode.reverbPreset,
            subBassBoost = mode.subBassBoost,
            presenceBoost = mode.presenceBoost,
            stereoWidth = mode.stereoWidth,
            nightMode = mode == SoundMode.NIGHT_MODE,
            isCustomMode = mode == SoundMode.CUSTOM
        )
        refreshSoftwareBandState()
        updateWarmthScore()
    }

    private fun applyEQBands(eq: Equalizer, targetBands: List<Int>, bandCount: Int) {
        when {
            bandCount <= targetBands.size -> {
                val step = targetBands.size.toFloat() / bandCount
                for (i in 0 until bandCount) {
                    val start = (i * step).toInt()
                    val end = ((i + 1) * step).toInt().coerceAtMost(targetBands.size)
                    val avg = if (end > start) targetBands.subList(start, end).average().toInt() else 0
                    try { eq.setBandLevel(i.toShort(), avg.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
                }
            }
            else -> {
                targetBands.take(bandCount).forEachIndexed { i, lvl ->
                    try { eq.setBandLevel(i.toShort(), lvl.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
                }
            }
        }
    }

    // ── Fine Tune Controls ────────────────────────────────────────────────────

    fun setBandLevel(bandIndex: Int, gainDb: Float) {
        biquadEQ?.setBandGain(bandIndex, gainDb)
        try {
            val eq = equalizer
            if (eq != null) {
                val hwBand = (bandIndex * eq.numberOfBands / BAND_COUNT).coerceIn(0, eq.numberOfBands - 1)
                eq.setBandLevel(hwBand.toShort(), (gainDb * 100).toInt().coerceIn(-1500, 1500).toShort())
            }
        } catch (_: Exception) {}
        refreshSoftwareBandState()
        updateWarmthScore()
        if (_dspState.value.currentMode != SoundMode.CUSTOM) {
            _dspState.value = _dspState.value.copy(isCustomMode = true)
        }
    }

    fun setBassStrength(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        try {
            bassBoost?.setStrength(clamped.toShort())
            bassBoost?.enabled = clamped > 0
        } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(bassStrength = clamped, isCustomMode = true)
        updateWarmthScore()
    }

    fun setVirtualizerStrength(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        try {
            virtualizer?.setStrength(clamped.toShort())
            virtualizer?.enabled = clamped > 0
        } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(virtualizerStrength = clamped, isCustomMode = true)
    }

    fun setLoudnessBoost(gainMb: Int) {
        val clamped = gainMb.coerceIn(0, 2000)
        try {
            loudnessEnhancer?.setTargetGain(clamped)
            loudnessEnhancer?.enabled = clamped > 0
        } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(loudnessBoostMb = clamped)
        updateWarmthScore()
    }

    fun setReverbPreset(preset: Int) {
        try {
            presetReverb?.preset = preset.toShort()
            presetReverb?.enabled = preset != 0
        } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(reverbPreset = preset, isCustomMode = true)
    }

    fun setSubBassBoost(value: Int) {
        val clamped = value.coerceIn(0, 100)
        try {
            val eq = equalizer
            if (eq != null && eq.numberOfBands > 0) {
                val extra = clamped * 3
                val base = (_dspState.value.currentMode.eqBands.getOrElse(0) { 0f } * 100).toInt()
                eq.setBandLevel(0, (base + extra).coerceIn(-1500, 1500).toShort())
            }
        } catch (_: Exception) {}
        // Also apply to SW EQ band 0
        biquadEQ?.setBandGain(0, (_dspState.value.currentMode.eqBands.getOrElse(0) { 0f } + clamped * 0.15f).coerceIn(-15f, 15f))
        _dspState.value = _dspState.value.copy(subBassBoost = clamped, isCustomMode = true)
        updateWarmthScore()
    }

    fun setStereoWidth(value: Int) {
        val clamped = value.coerceIn(0, 100)
        val virtCalc = ((clamped / 100f) * _dspState.value.virtualizerStrength).toInt()
        try {
            virtualizer?.setStrength(virtCalc.coerceIn(0, 1000).toShort())
            virtualizer?.enabled = virtCalc > 0
        } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(stereoWidth = clamped, isCustomMode = true)
    }

    fun setPresenceBoost(on: Boolean) {
        val eq = equalizer
        if (eq != null) {
            try {
                val bandCount = eq.numberOfBands.toInt()
                if (bandCount >= 7) {
                    for (bi in 5 until minOf(8, bandCount)) {
                        val cur = eq.getBandLevel(bi.toShort()).toInt()
                        val target = if (on) (cur + 200).coerceIn(-1500, 1500) else (cur - 200).coerceIn(-1500, 1500)
                        eq.setBandLevel(bi.toShort(), target.toShort())
                    }
                }
            } catch (_: Exception) {}
        }
        _dspState.value = _dspState.value.copy(presenceBoost = on, isCustomMode = true)
    }

    fun setNightMode(on: Boolean) {
        if (on) applyMode(SoundMode.NIGHT_MODE)
        else applyMode(SoundMode.MUSIC_HD)
        _dspState.value = _dspState.value.copy(nightMode = on)
    }

    fun setDialogueEnhance(on: Boolean) {
        val eq = equalizer
        if (eq != null) {
            try {
                val bandCount = eq.numberOfBands.toInt()
                if (on) {
                    if (bandCount > 4) eq.setBandLevel(4, 1000)
                    if (bandCount > 5) eq.setBandLevel(5, 1000)
                    if (bandCount > 6) eq.setBandLevel(6, 800)
                } else {
                    applyMode(_dspState.value.currentMode)
                }
            } catch (_: Exception) {}
        }
        _dspState.value = _dspState.value.copy(dialogueEnhance = on)
    }

    fun setBassExciter(level: Int) {
        _dspState.value = _dspState.value.copy(bassExciterLevel = level.coerceIn(0, 100))
    }

    fun setCompressor(level: Int, enabled: Boolean? = null) {
        val en = enabled ?: _dspState.value.compressorEnabled
        _dspState.value = _dspState.value.copy(
            compressorLevel = level.coerceIn(0, 100),
            compressorEnabled = en
        )
    }

    fun setSurroundLevel(level: Int) {
        _dspState.value = _dspState.value.copy(surroundLevel = level.coerceIn(0, 100))
        // Map 0-100 to virtualizer 0-1000
        val virt = (level * 10).coerceIn(0, 1000)
        try { virtualizer?.setStrength(virt.toShort()) } catch (_: Exception) {}
    }

    fun setAutoGenreSwitch(on: Boolean) {
        _dspState.value = _dspState.value.copy(autoGenreSwitch = on)
    }

    fun setEnabled(enabled: Boolean) {
        equalizer?.enabled = enabled
        bassBoost?.enabled = enabled && _dspState.value.bassStrength > 0
        virtualizer?.enabled = enabled && _dspState.value.virtualizerStrength > 0
        loudnessEnhancer?.enabled = enabled && _dspState.value.loudnessBoostMb > 0
        presetReverb?.enabled = enabled && _dspState.value.reverbPreset != 0
        biquadEQ?.setEnabled(enabled)
        _dspState.value = _dspState.value.copy(isEnabled = enabled)
    }

    // ── Custom Presets ────────────────────────────────────────────────────────

    fun saveCustomPreset(name: String) {
        val state = _dspState.value
        val gains = biquadEQ?.getGains()?.toList()?.map { it } ?: List(BAND_COUNT) { 0f }
        val preset = CustomPreset(
            name = name,
            bands = gains,
            bassStrength = state.bassStrength,
            virtStrength = state.virtualizerStrength,
            loudnessMb = state.loudnessBoostMb,
            reverbPreset = state.reverbPreset,
            subBassBoost = state.subBassBoost,
            presenceBoost = state.presenceBoost,
            stereoWidth = state.stereoWidth
        )
        customPresets[name] = preset
        savePresetToDisk(preset)
        _dspState.value = state.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun loadCustomPreset(name: String) {
        val preset = customPresets[name] ?: return
        biquadEQ?.setAllGains(preset.bands)
        setBassStrength(preset.bassStrength)
        setVirtualizerStrength(preset.virtStrength)
        setLoudnessBoost(preset.loudnessMb)
        setReverbPreset(preset.reverbPreset)
        _dspState.value = _dspState.value.copy(
            subBassBoost = preset.subBassBoost,
            presenceBoost = preset.presenceBoost,
            stereoWidth = preset.stereoWidth,
            isCustomMode = true,
            currentMode = SoundMode.CUSTOM
        )
        refreshSoftwareBandState()
        updateWarmthScore()
    }

    fun renameCustomPreset(oldName: String, newName: String) {
        val preset = customPresets.remove(oldName) ?: return
        val renamed = preset.copy(name = newName)
        customPresets[newName] = renamed
        deletePresetFromDisk(oldName)
        savePresetToDisk(renamed)
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun deleteCustomPreset(name: String) {
        customPresets.remove(name)
        deletePresetFromDisk(name)
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun getCustomPresets(): Map<String, CustomPreset> = customPresets.toMap()

    // ── Internal Helpers ──────────────────────────────────────────────────────

    private fun refreshSoftwareBandState() {
        val gains = biquadEQ?.getGains() ?: FloatArray(BAND_COUNT) { 0f }
        val bands = (0 until BAND_COUNT).map { i ->
            val gainDb = gains.getOrElse(i) { 0f }
            BandState(
                index = i,
                centerFreqHz = BAND_FREQS[i].toInt(),
                levelMb = (gainDb * 100).toInt(),
                minLevelMb = -1500,
                maxLevelMb = 1500,
                freqLabel = formatFreqFloat(BAND_FREQS[i]),
                gainDb = gainDb
            )
        }
        _dspState.value = _dspState.value.copy(
            bands = bands,
            softwareEQActive = biquadEQ != null
        )
    }

    private fun updateWarmthScore() {
        val state = _dspState.value
        val bassScore = state.bassStrength / 10
        val subScore = state.subBassBoost
        val loudScore = state.loudnessBoostMb / 20
        _dspState.value = _dspState.value.copy(
            dspWarmthScore = ((bassScore + subScore + loudScore) / 3).coerceIn(0, 100)
        )
    }

    private fun formatFreqFloat(hz: Float): String = when {
        hz >= 1000f -> {
            val k = hz / 1000f
            if (k == k.toInt().toFloat()) "${k.toInt()}kHz"
            else String.format("%.1fkHz", k)
        }
        else -> "${hz.toInt()}Hz"
    }

    // ── Disk Persistence ──────────────────────────────────────────────────────

    private fun savePresetToDisk(preset: CustomPreset) {
        try {
            val json = JSONObject().apply {
                put("name", preset.name)
                put("bands", JSONArray(preset.bands))
                put("bassStrength", preset.bassStrength)
                put("virtStrength", preset.virtStrength)
                put("loudnessMb", preset.loudnessMb)
                put("reverbPreset", preset.reverbPreset)
                put("subBassBoost", preset.subBassBoost)
                put("presenceBoost", preset.presenceBoost)
                put("stereoWidth", preset.stereoWidth)
            }
            prefs?.edit()?.putString("preset_${preset.name}", json.toString())?.apply()
            val names = customPresets.keys.toList()
            prefs?.edit()?.putString("preset_index", JSONArray(names).toString())?.apply()
        } catch (_: Exception) {}
    }

    private fun deletePresetFromDisk(name: String) {
        try {
            prefs?.edit()?.remove("preset_$name")?.apply()
            val remaining = customPresets.keys.toList()
            prefs?.edit()?.putString("preset_index", JSONArray(remaining).toString())?.apply()
        } catch (_: Exception) {}
    }

    private fun loadPresetsFromDisk() {
        try {
            val indexStr = prefs?.getString("preset_index", null) ?: return
            val names = JSONArray(indexStr)
            for (i in 0 until names.length()) {
                val name = names.getString(i)
                val jsonStr = prefs?.getString("preset_$name", null) ?: continue
                val json = JSONObject(jsonStr)
                val bandsArr = json.getJSONArray("bands")
                val bands = (0 until bandsArr.length()).map { bandsArr.getDouble(it).toFloat() }
                customPresets[name] = CustomPreset(
                    name = name,
                    bands = bands,
                    bassStrength = json.optInt("bassStrength", 500),
                    virtStrength = json.optInt("virtStrength", 500),
                    loudnessMb = json.optInt("loudnessMb", 0),
                    reverbPreset = json.optInt("reverbPreset", 0),
                    subBassBoost = json.optInt("subBassBoost", 0),
                    presenceBoost = json.optBoolean("presenceBoost", false),
                    stereoWidth = json.optInt("stereoWidth", 50)
                )
            }
        } catch (_: Exception) {}
    }

    fun release() {
        listOf(equalizer, bassBoost, virtualizer, loudnessEnhancer, presetReverb).forEach {
            try { it?.release() } catch (_: Exception) {}
        }
        equalizer = null
        bassBoost = null
        virtualizer = null
        loudnessEnhancer = null
        presetReverb = null
        _dspState.value = _dspState.value.copy(isHardwareAttached = false)
    }
}
