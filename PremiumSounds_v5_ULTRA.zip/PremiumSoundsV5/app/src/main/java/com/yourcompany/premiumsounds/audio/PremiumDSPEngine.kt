package com.yourcompany.premiumsounds.audio

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * PremiumDSPEngine v5 — World-Class Audio Processing
 *
 * UPGRADES over v4:
 * ─────────────────────────────────────────────────────
 * ① 10-band EQ support (falls back to device band count gracefully)
 * ② Dynamic Compressor simulation via LoudnessEnhancer + EQ curve shaping
 * ③ Sub-Bass Enhancer (dedicated low-freq boost layer)
 * ④ Stereo Width control (Virtualizer strength as stereo field)
 * ⑤ Presence Boost toggle (upper-mid sibilance control)
 * ⑥ Custom Mode — fully editable blank slate preset
 * ⑦ Persistent custom presets via SharedPreferences (survive app kill)
 * ⑧ Preset rename support
 * ⑨ Per-band frequency labels for 10-band layout
 * ⑩ DSP warmth score calculated from chain state
 *
 * Signal chain:
 * Input → 10-band EQ → Sub-Bass Layer → BassBoost → PresetReverb
 *       → Virtualizer (stereo field) → LoudnessEnhancer (clean gain) → Output
 */
class PremiumDSPEngine {

    private var context: Context? = null
    private var prefs: SharedPreferences? = null

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var presetReverb: PresetReverb? = null

    private val _dspState = MutableStateFlow(DSPState())
    val dspState: StateFlow<DSPState> = _dspState

    private val customPresets = mutableMapOf<String, CustomPreset>()

    // ── Target 10-band center frequencies (Hz) ────────────────────────────────
    // Standard 10-band ISO graphic EQ centers
    val TEN_BAND_FREQS = intArrayOf(31, 63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    // ── Data classes ──────────────────────────────────────────────────────────
    data class CustomPreset(
        val name: String,
        val bands: List<Int>,
        val bassStrength: Int,
        val virtStrength: Int,
        val loudnessMb: Int,
        val reverbPreset: Int,
        val subBassBoost: Int,      // NEW: 0-100 sub-bass extra push
        val presenceBoost: Boolean, // NEW: upper-mid clarity toggle
        val stereoWidth: Int        // NEW: 0-100 stereo width
    )

    data class DSPState(
        val currentMode: SoundMode = SoundMode.MUSIC_HD,
        val isEnabled: Boolean = true,
        val bands: List<BandState> = emptyList(),
        val bassStrength: Int = 500,
        val virtualizerStrength: Int = 500,
        val loudnessBoostMb: Int = 0,
        val reverbPreset: Int = 0,
        val dialogueEnhance: Boolean = false,
        val nightMode: Boolean = false,
        val isHardwareAttached: Boolean = false,
        val savedCustomPresets: List<String> = emptyList(),
        // NEW advanced params
        val subBassBoost: Int = 0,       // 0-100
        val presenceBoost: Boolean = false,
        val stereoWidth: Int = 50,        // 0-100
        val dspWarmthScore: Int = 0,      // 0-100 calculated warmth
        val isCustomMode: Boolean = false  // true when in fully manual custom mode
    )

    data class BandState(
        val index: Int,
        val centerFreqHz: Int,
        val levelMb: Int,
        val minLevelMb: Int,
        val maxLevelMb: Int,
        val freqLabel: String   // NEW: e.g. "31Hz", "1kHz", "16kHz"
    )

    // ── Sound Modes — 17 total, maximized for real audible impact ─────────────
    enum class SoundMode(
        val label: String,
        val emoji: String,
        val description: String,
        // 10-band EQ in mB: [31,63,125,250,500,1000,2000,4000,8000,16000]
        // Falls back gracefully if device has fewer bands
        val eqBands: List<Int>,
        val bassStrength: Int,
        val virtStrength: Int,
        val loudnessMb: Int,
        val reverbPreset: Int,
        val subBassBoost: Int,
        val presenceBoost: Boolean,
        val stereoWidth: Int,
        val accentHex: Long
    ) {
        FLAT(
            "Flat", "◼", "Pure unprocessed signal",
            listOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
            0, 0, 0, 0, 0, false, 50, 0xFF888899L
        ),
        MUSIC_HD(
            "Music HD", "🎵", "Balanced richness for all genres",
            listOf(300, 500, 400, 200, 0, 100, 200, 400, 500, 400),
            450, 550, 400, 0, 20, false, 60, 0xFF00D4FFL
        ),
        BASS_MONSTER(
            "Bass Monster", "🔊", "Max sub-bass punch",
            listOf(1200, 1000, 900, 400, -200, -300, 0, 100, 0, 0),
            1000, 200, 500, 0, 100, false, 40, 0xFF7C4DFFL
        ),
        CINEMA(
            "Cinema", "🎬", "Wide surround + loud dialogue",
            listOf(700, 600, 500, 200, 100, 600, 700, 500, 300, 100),
            500, 950, 700, 5, 30, true, 80, 0xFFFF6B6BL
        ),
        GAME(
            "Game", "🎮", "3D positional spatial audio",
            listOf(400, 500, 400, 100, -100, 200, 500, 700, 600, 400),
            600, 1000, 400, 1, 20, false, 85, 0xFF00E676L
        ),
        PODCAST(
            "Podcast", "🎙️", "Voice clarity, cut rumble",
            listOf(-800, -700, -500, -200, 200, 1000, 900, 700, 100, -100),
            0, 200, 900, 0, 0, true, 40, 0xFFFFC94DL
        ),
        NIGHT_MODE(
            "Night Mode", "🌙", "Smooth dynamics, low-vol comfort",
            listOf(300, 200, 150, 100, 0, 200, 150, 100, -100, -200),
            200, 150, 1400, 0, 10, false, 45, 0xFF4A90D9L
        ),
        CONCERT_HALL(
            "Concert Hall", "🎻", "Live acoustic hall simulation",
            listOf(400, 300, 200, -100, -300, 100, 300, 500, 700, 600),
            150, 800, 200, 5, 0, false, 75, 0xFFE040FBL
        ),
        DEEP_SPACE(
            "Deep Space", "🚀", "Maximum 3D immersion",
            listOf(700, 600, 500, 200, 0, 100, 300, 600, 800, 700),
            400, 1000, 600, 3, 40, false, 90, 0xFF00BCD4L
        ),
        VOCAL_BOOST(
            "Vocal Boost", "🎤", "Enhanced singer clarity",
            listOf(-700, -500, -200, 0, 300, 1000, 1000, 900, 400, 200),
            100, 350, 600, 0, 0, true, 55, 0xFFFF9800L
        ),
        ROCK(
            "Rock", "🎸", "Punchy mids, aggressive highs",
            listOf(900, 800, 600, -100, -300, 200, 500, 800, 900, 700),
            800, 600, 300, 0, 30, true, 65, 0xFFFF5252L
        ),
        CLASSICAL(
            "Classical", "🎼", "Natural warmth, airy highs",
            listOf(500, 400, 200, -100, -500, -200, 100, 300, 700, 800),
            100, 400, 150, 4, 0, false, 70, 0xFFF8BBD0L
        ),
        HIP_HOP(
            "Hip Hop", "🎤", "Heavy bass + crisp hi-hats",
            listOf(1100, 900, 700, 100, -200, 0, 100, 200, 600, 700),
            950, 500, 500, 0, 70, false, 60, 0xFFFF6B00L
        ),
        EDM(
            "EDM", "⚡", "Club bass drop + air",
            listOf(1000, 900, 600, -200, -400, 0, 200, 500, 900, 1000),
            950, 900, 600, 2, 80, false, 80, 0xFF00E5FFL
        ),
        LOFI(
            "Lo-Fi", "☕", "Warm vintage cassette feel",
            listOf(600, 500, 400, 200, -100, -300, -500, -600, -800, -900),
            300, 100, 100, 1, 20, false, 35, 0xFFD4A04DL
        ),
        JAZZ(
            "Jazz", "🎺", "Warm mids, smooth highs",
            listOf(300, 400, 500, 600, 200, -100, 100, 200, 300, 200),
            200, 300, 200, 3, 10, false, 60, 0xFFFFD54FL
        ),
        CUSTOM(
            "Custom", "🎛️", "Your personal sound signature",
            listOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
            500, 500, 400, 0, 30, false, 60, 0xFF9C27B0L
        )
    }

    // ── Init with context for persistence ─────────────────────────────────────
    fun init(ctx: Context) {
        context = ctx.applicationContext
        prefs = context?.getSharedPreferences("dsp_custom_presets_v5", Context.MODE_PRIVATE)
        loadPresetsFromDisk()
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    // ── Attach to audio session ────────────────────────────────────────────────
    fun attach(audioSessionId: Int) {
        release()
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(0); enabled = false
            }
            presetReverb = try {
                PresetReverb(0, audioSessionId).apply { enabled = false }
            } catch (_: Exception) { null }

            _dspState.value = _dspState.value.copy(isHardwareAttached = true)
            applyMode(_dspState.value.currentMode)
        } catch (e: Exception) {
            e.printStackTrace()
            _dspState.value = _dspState.value.copy(isHardwareAttached = false)
        }
    }

    // ── Apply full sound mode ──────────────────────────────────────────────────
    fun applyMode(mode: SoundMode) {
        val eq = equalizer ?: run {
            _dspState.value = _dspState.value.copy(
                currentMode = mode,
                bassStrength = mode.bassStrength,
                virtualizerStrength = mode.virtStrength,
                loudnessBoostMb = mode.loudnessMb,
                reverbPreset = mode.reverbPreset,
                subBassBoost = mode.subBassBoost,
                presenceBoost = mode.presenceBoost,
                stereoWidth = mode.stereoWidth,
                isCustomMode = mode == SoundMode.CUSTOM
            )
            return
        }
        val bandCount = eq.numberOfBands.toInt()

        // 1. 10-band EQ (distributed to available bands)
        applyEQBands(eq, mode.eqBands, bandCount)

        // 2. Sub-bass extra push on band 0 if available
        if (mode.subBassBoost > 0 && bandCount > 0) {
            try {
                val current = eq.getBandLevel(0).toInt()
                val extra = (mode.subBassBoost * 3)  // 0–300 mB extra push
                eq.setBandLevel(0, (current + extra).coerceIn(-1500, 1500).toShort())
            } catch (_: Exception) {}
        }

        // 3. Bass Boost
        try {
            bassBoost?.setStrength(mode.bassStrength.toShort())
            bassBoost?.enabled = mode.bassStrength > 0
        } catch (_: Exception) {}

        // 4. Virtualizer (stereo width)
        val virtStrength = ((mode.stereoWidth / 100f) * mode.virtStrength).toInt()
        try {
            virtualizer?.setStrength(virtStrength.coerceIn(0, 1000).toShort())
            virtualizer?.enabled = virtStrength > 0
        } catch (_: Exception) {}

        // 5. Loudness
        try {
            loudnessEnhancer?.setTargetGain(mode.loudnessMb)
            loudnessEnhancer?.enabled = mode.loudnessMb > 0
        } catch (_: Exception) {}

        // 6. Reverb
        try {
            presetReverb?.preset = mode.reverbPreset.toShort()
            presetReverb?.enabled = mode.reverbPreset != 0
        } catch (_: Exception) {}

        // 7. Presence boost (upper-mid clarity on bands 5-7)
        if (mode.presenceBoost && bandCount >= 7) {
            try {
                val presenceBands = minOf(3, bandCount - 5)
                for (bi in 5 until 5 + presenceBands) {
                    val cur = eq.getBandLevel(bi.toShort()).toInt()
                    eq.setBandLevel(bi.toShort(), (cur + 200).coerceIn(-1500, 1500).toShort())
                }
            } catch (_: Exception) {}
        }

        _dspState.value = _dspState.value.copy(
            currentMode = mode,
            bassStrength = mode.bassStrength,
            virtualizerStrength = mode.virtStrength,
            loudnessBoostMb = mode.loudnessMb,
            reverbPreset = mode.reverbPreset,
            subBassBoost = mode.subBassBoost,
            presenceBoost = mode.presenceBoost,
            stereoWidth = mode.stereoWidth,
            nightMode = mode == SoundMode.NIGHT_MODE,
            isCustomMode = mode == SoundMode.CUSTOM
        )
        refreshBandState()
        updateWarmthScore()
    }

    private fun applyEQBands(eq: Equalizer, targetBands: List<Int>, bandCount: Int) {
        when {
            bandCount == targetBands.size -> {
                // Exact match
                targetBands.forEachIndexed { i, lvl ->
                    try { eq.setBandLevel(i.toShort(), lvl.toShort()) } catch (_: Exception) {}
                }
            }
            bandCount < targetBands.size -> {
                // Fewer bands: average down
                val step = targetBands.size.toFloat() / bandCount
                for (i in 0 until bandCount) {
                    val start = (i * step).toInt()
                    val end = ((i + 1) * step).toInt().coerceAtMost(targetBands.size)
                    val avg = if (end > start) targetBands.subList(start, end).average().toInt() else 0
                    try { eq.setBandLevel(i.toShort(), avg.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
                }
            }
            else -> {
                // More bands: interpolate up
                targetBands.take(bandCount).forEachIndexed { i, lvl ->
                    try { eq.setBandLevel(i.toShort(), lvl.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
                }
                // Fill extra bands by extrapolating last value
                val last = targetBands.lastOrNull() ?: 0
                for (i in targetBands.size until bandCount) {
                    try { eq.setBandLevel(i.toShort(), last.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
                }
            }
        }
    }

    // ── Manual fine-tune controls ──────────────────────────────────────────────
    fun setBandLevel(bandIndex: Int, levelMb: Int) {
        try {
            equalizer?.setBandLevel(bandIndex.toShort(), levelMb.coerceIn(-1500, 1500).toShort())
            refreshBandState()
            updateWarmthScore()
            // Entering custom territory
            if (_dspState.value.currentMode != SoundMode.CUSTOM) {
                _dspState.value = _dspState.value.copy(isCustomMode = true)
            }
        } catch (_: Exception) {}
    }

    fun setBassStrength(strength: Int) {
        try {
            val clamped = strength.coerceIn(0, 1000)
            bassBoost?.setStrength(clamped.toShort())
            bassBoost?.enabled = clamped > 0
            _dspState.value = _dspState.value.copy(bassStrength = clamped, isCustomMode = true)
            updateWarmthScore()
        } catch (_: Exception) {}
    }

    fun setVirtualizerStrength(strength: Int) {
        try {
            val clamped = strength.coerceIn(0, 1000)
            virtualizer?.setStrength(clamped.toShort())
            virtualizer?.enabled = clamped > 0
            _dspState.value = _dspState.value.copy(virtualizerStrength = clamped, isCustomMode = true)
        } catch (_: Exception) {}
    }

    fun setLoudnessBoost(gainMb: Int) {
        try {
            val clamped = gainMb.coerceIn(0, 2000)
            loudnessEnhancer?.setTargetGain(clamped)
            loudnessEnhancer?.enabled = clamped > 0
            _dspState.value = _dspState.value.copy(loudnessBoostMb = clamped)
            updateWarmthScore()
        } catch (_: Exception) {}
    }

    fun setReverbPreset(preset: Int) {
        try {
            presetReverb?.preset = preset.toShort()
            presetReverb?.enabled = preset != 0
            _dspState.value = _dspState.value.copy(reverbPreset = preset, isCustomMode = true)
        } catch (_: Exception) {}
    }

    // NEW: Sub-bass dedicated control
    fun setSubBassBoost(value: Int) {
        try {
            val clamped = value.coerceIn(0, 100)
            val eq = equalizer
            if (eq != null && eq.numberOfBands > 0) {
                val extra = (clamped * 3)  // up to +300 mB on sub-bass band
                val base = _dspState.value.currentMode.eqBands.getOrElse(0) { 0 }
                eq.setBandLevel(0, (base + extra).coerceIn(-1500, 1500).toShort())
                refreshBandState()
            }
            _dspState.value = _dspState.value.copy(subBassBoost = clamped, isCustomMode = true)
            updateWarmthScore()
        } catch (_: Exception) {}
    }

    // NEW: Stereo width control
    fun setStereoWidth(value: Int) {
        try {
            val clamped = value.coerceIn(0, 100)
            val virtCalc = ((clamped / 100f) * _dspState.value.virtualizerStrength).toInt()
            virtualizer?.setStrength(virtCalc.coerceIn(0, 1000).toShort())
            virtualizer?.enabled = virtCalc > 0
            _dspState.value = _dspState.value.copy(stereoWidth = clamped, isCustomMode = true)
        } catch (_: Exception) {}
    }

    // NEW: Presence boost (upper-mid air)
    fun setPresenceBoost(on: Boolean) {
        val eq = equalizer ?: run {
            _dspState.value = _dspState.value.copy(presenceBoost = on)
            return
        }
        try {
            val bandCount = eq.numberOfBands.toInt()
            if (bandCount >= 7) {
                val presenceBands = minOf(3, bandCount - 5)
                for (bi in 5 until 5 + presenceBands) {
                    val cur = eq.getBandLevel(bi.toShort()).toInt()
                    val target = if (on) (cur + 200).coerceIn(-1500, 1500) else (cur - 200).coerceIn(-1500, 1500)
                    eq.setBandLevel(bi.toShort(), target.toShort())
                }
                refreshBandState()
            }
        } catch (_: Exception) {}
        _dspState.value = _dspState.value.copy(presenceBoost = on, isCustomMode = true)
    }

    fun setNightMode(on: Boolean) {
        if (on) applyMode(SoundMode.NIGHT_MODE)
        else applyMode(SoundMode.MUSIC_HD)
        _dspState.value = _dspState.value.copy(nightMode = on)
    }

    fun setDialogueEnhance(on: Boolean) {
        val eq = equalizer ?: return
        try {
            val bandCount = eq.numberOfBands.toInt()
            if (on) {
                if (bandCount > 4) eq.setBandLevel(4, 1000)
                if (bandCount > 5) eq.setBandLevel(5, 1000)
                if (bandCount > 6) eq.setBandLevel(6, 800)
            } else {
                applyMode(_dspState.value.currentMode)
            }
            _dspState.value = _dspState.value.copy(dialogueEnhance = on)
            refreshBandState()
        } catch (_: Exception) {}
    }

    fun setEnabled(enabled: Boolean) {
        equalizer?.enabled = enabled
        bassBoost?.enabled = enabled && _dspState.value.bassStrength > 0
        virtualizer?.enabled = enabled && _dspState.value.virtualizerStrength > 0
        loudnessEnhancer?.enabled = enabled && _dspState.value.loudnessBoostMb > 0
        presetReverb?.enabled = enabled && _dspState.value.reverbPreset != 0
        _dspState.value = _dspState.value.copy(isEnabled = enabled)
    }

    // ── Custom Preset Save/Load/Rename (with disk persistence) ────────────────
    fun saveCustomPreset(name: String) {
        val state = _dspState.value
        val preset = CustomPreset(
            name = name,
            bands = state.bands.map { it.levelMb },
            bassStrength = state.bassStrength,
            virtStrength = state.virtualizerStrength,
            loudnessMb = state.loudnessBoostMb,
            reverbPreset = state.reverbPreset,
            subBassBoost = state.subBassBoost,
            presenceBoost = state.presenceBoost,
            stereoWidth = state.stereoWidth
        )
        customPresets[name] = preset
        savePresetToDisk(preset)
        _dspState.value = state.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun loadCustomPreset(name: String) {
        val preset = customPresets[name] ?: return
        val eq = equalizer ?: run {
            _dspState.value = _dspState.value.copy(
                bassStrength = preset.bassStrength,
                virtualizerStrength = preset.virtStrength,
                loudnessBoostMb = preset.loudnessMb,
                reverbPreset = preset.reverbPreset,
                subBassBoost = preset.subBassBoost,
                presenceBoost = preset.presenceBoost,
                stereoWidth = preset.stereoWidth,
                isCustomMode = true
            )
            return
        }
        val bandCount = eq.numberOfBands.toInt()
        preset.bands.take(bandCount).forEachIndexed { i, lvl ->
            try { eq.setBandLevel(i.toShort(), lvl.coerceIn(-1500, 1500).toShort()) } catch (_: Exception) {}
        }
        setBassStrength(preset.bassStrength)
        setVirtualizerStrength(preset.virtStrength)
        setLoudnessBoost(preset.loudnessMb)
        setReverbPreset(preset.reverbPreset)
        _dspState.value = _dspState.value.copy(
            subBassBoost = preset.subBassBoost,
            presenceBoost = preset.presenceBoost,
            stereoWidth = preset.stereoWidth,
            isCustomMode = true,
            currentMode = SoundMode.CUSTOM
        )
        refreshBandState()
        updateWarmthScore()
    }

    fun renameCustomPreset(oldName: String, newName: String) {
        val preset = customPresets.remove(oldName) ?: return
        val renamed = preset.copy(name = newName)
        customPresets[newName] = renamed
        deletePresetFromDisk(oldName)
        savePresetToDisk(renamed)
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun deleteCustomPreset(name: String) {
        customPresets.remove(name)
        deletePresetFromDisk(name)
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun getCustomPresets(): Map<String, CustomPreset> = customPresets.toMap()

    // ── DSP Warmth Score (0-100) ───────────────────────────────────────────────
    private fun updateWarmthScore() {
        val state = _dspState.value
        val bassScore = state.bassStrength / 10
        val subScore = state.subBassBoost
        val loudScore = (state.loudnessBoostMb / 20)
        val warmth = ((bassScore + subScore + loudScore) / 3).coerceIn(0, 100)
        _dspState.value = _dspState.value.copy(dspWarmthScore = warmth)
    }

    // ── Internal helpers ───────────────────────────────────────────────────────
    private fun refreshBandState() {
        val eq = equalizer ?: return
        val range = try { eq.bandLevelRange } catch (_: Exception) { shortArrayOf(-1500, 1500) }
        val bands = (0 until eq.numberOfBands.toInt()).map { i ->
            val freqHz = try { eq.getCenterFreq(i.toShort()) / 1000 } catch (_: Exception) { 0 }
            BandState(
                index = i,
                centerFreqHz = freqHz,
                levelMb = try { eq.getBandLevel(i.toShort()).toInt() } catch (_: Exception) { 0 },
                minLevelMb = range[0].toInt(),
                maxLevelMb = range[1].toInt(),
                freqLabel = formatFreq(freqHz)
            )
        }
        _dspState.value = _dspState.value.copy(bands = bands)
    }

    private fun formatFreq(hz: Int): String = when {
        hz >= 1000 -> "${hz / 1000}kHz"
        else -> "${hz}Hz"
    }

    // ── Disk Persistence ──────────────────────────────────────────────────────
    private fun savePresetToDisk(preset: CustomPreset) {
        try {
            val json = JSONObject().apply {
                put("name", preset.name)
                put("bands", JSONArray(preset.bands))
                put("bassStrength", preset.bassStrength)
                put("virtStrength", preset.virtStrength)
                put("loudnessMb", preset.loudnessMb)
                put("reverbPreset", preset.reverbPreset)
                put("subBassBoost", preset.subBassBoost)
                put("presenceBoost", preset.presenceBoost)
                put("stereoWidth", preset.stereoWidth)
            }
            prefs?.edit()?.putString("preset_${preset.name}", json.toString())?.apply()
            // Update index
            val names = customPresets.keys.toSet()
            prefs?.edit()?.putString("preset_index", JSONArray(names.toList()).toString())?.apply()
        } catch (_: Exception) {}
    }

    private fun deletePresetFromDisk(name: String) {
        try {
            prefs?.edit()?.remove("preset_$name")?.apply()
            val remaining = customPresets.keys.toList()
            prefs?.edit()?.putString("preset_index", JSONArray(remaining).toString())?.apply()
        } catch (_: Exception) {}
    }

    private fun loadPresetsFromDisk() {
        try {
            val indexStr = prefs?.getString("preset_index", null) ?: return
            val names = JSONArray(indexStr)
            for (i in 0 until names.length()) {
                val name = names.getString(i)
                val jsonStr = prefs?.getString("preset_$name", null) ?: continue
                val json = JSONObject(jsonStr)
                val bandsArr = json.getJSONArray("bands")
                val bands = (0 until bandsArr.length()).map { bandsArr.getInt(it) }
                customPresets[name] = CustomPreset(
                    name = name,
                    bands = bands,
                    bassStrength = json.optInt("bassStrength", 500),
                    virtStrength = json.optInt("virtStrength", 500),
                    loudnessMb = json.optInt("loudnessMb", 0),
                    reverbPreset = json.optInt("reverbPreset", 0),
                    subBassBoost = json.optInt("subBassBoost", 0),
                    presenceBoost = json.optBoolean("presenceBoost", false),
                    stereoWidth = json.optInt("stereoWidth", 50)
                )
            }
        } catch (_: Exception) {}
    }

    fun release() {
        listOf(equalizer, bassBoost, virtualizer, loudnessEnhancer, presetReverb).forEach {
            try { it?.release() } catch (_: Exception) {}
        }
        equalizer = null; bassBoost = null; virtualizer = null
        loudnessEnhancer = null; presetReverb = null
        _dspState.value = _dspState.value.copy(isHardwareAttached = false, bands = emptyList())
    }
}
