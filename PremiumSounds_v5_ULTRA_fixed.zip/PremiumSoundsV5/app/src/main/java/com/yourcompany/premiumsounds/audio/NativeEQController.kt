package com.yourcompany.premiumsounds.audio

import android.media.audiofx.Equalizer

/**
 * NativeEQController — 12 Virtual Bands → Native Hardware EQ
 *
 * Device ke actual bands (usually 5) ko 12 virtual bands se map karta hai.
 * UI 12 sliders dikhata hai, internally hardware bands update hote hain.
 * 100% guaranteed sound change — native Android AudioEffect use karta hai.
 *
 * Virtual 12 bands (Hz): 31,62,125,250,500,1k,2k,4k,6k,8k,12k,16k
 * Gain range: -1500mB to +1500mB (-15dB to +15dB)
 */
class NativeEQController {

    // 12 virtual band center frequencies
    val VIRTUAL_BANDS = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 6000, 8000, 12000, 16000)
    val VIRTUAL_BAND_COUNT = 12

    // User-set gains for 12 virtual bands (in mB)
    private val virtualGains = IntArray(VIRTUAL_BAND_COUNT) { 0 }

    private var equalizer: Equalizer? = null
    private var hardwareBandCount = 0
    private var hwMinLevel = -1500
    private var hwMaxLevel = 1500

    data class VirtualBandState(
        val index: Int,
        val freqHz: Int,
        val gainMb: Int,
        val freqLabel: String
    )

    // ── Attach to audio session ───────────────────────────────────────────────

    fun attach(audioSessionId: Int): Boolean {
        release()
        return try {
            equalizer = Equalizer(-1, audioSessionId).apply {
                enabled = true
            }
            val eq = equalizer!!
            hardwareBandCount = eq.numberOfBands.toInt()
            val range = eq.bandLevelRange
            hwMinLevel = range[0].toInt()
            hwMaxLevel = range[1].toInt()
            applyAllToHardware()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // ── Set single virtual band ───────────────────────────────────────────────

    fun setVirtualBand(virtualIndex: Int, gainMb: Int) {
        if (virtualIndex !in 0 until VIRTUAL_BAND_COUNT) return
        virtualGains[virtualIndex] = gainMb.coerceIn(hwMinLevel, hwMaxLevel)
        applyAllToHardware()
    }

    // ── Set all 12 virtual bands (for mode presets) ───────────────────────────

    fun setAllVirtualBands(gains: IntArray) {
        gains.take(VIRTUAL_BAND_COUNT).forEachIndexed { i, g ->
            virtualGains[i] = g.coerceIn(hwMinLevel, hwMaxLevel)
        }
        applyAllToHardware()
    }

    fun setAllVirtualBandsDb(gainsDb: List<Float>) {
        gainsDb.take(VIRTUAL_BAND_COUNT).forEachIndexed { i, g ->
            virtualGains[i] = (g * 100).toInt().coerceIn(hwMinLevel, hwMaxLevel)
        }
        applyAllToHardware()
    }

    fun getVirtualGains(): IntArray = virtualGains.copyOf()

    // ── Apply virtual → hardware mapping ──────────────────────────────────────
    // Each hardware band gets weighted average of nearby virtual bands

    private fun applyAllToHardware() {
        val eq = equalizer ?: return
        if (hardwareBandCount == 0) return

        // Get actual hardware band center frequencies
        val hwFreqs = (0 until hardwareBandCount).map { i ->
            try { eq.getCenterFreq(i.toShort()) / 1000 } catch (_: Exception) { 0 }
        }

        // For each hardware band, find nearest virtual band(s) and interpolate
        for (hwBand in 0 until hardwareBandCount) {
            val hwFreq = hwFreqs[hwBand]
            if (hwFreq == 0) continue

            val gain = interpolateGain(hwFreq)
            try {
                eq.setBandLevel(hwBand.toShort(), gain.coerceIn(hwMinLevel, hwMaxLevel).toShort())
            } catch (_: Exception) {}
        }
    }

    /**
     * Interpolate virtual band gains for a given hardware frequency.
     * Uses weighted average of 2 nearest virtual bands.
     */
    private fun interpolateGain(hwFreqHz: Int): Int {
        if (hardwareBandCount == 0) return 0

        // Find the two nearest virtual bands by frequency
        var lowerIdx = 0
        var upperIdx = VIRTUAL_BAND_COUNT - 1

        for (i in 0 until VIRTUAL_BAND_COUNT - 1) {
            if (VIRTUAL_BANDS[i] <= hwFreqHz && VIRTUAL_BANDS[i + 1] >= hwFreqHz) {
                lowerIdx = i
                upperIdx = i + 1
                break
            }
        }

        if (lowerIdx == upperIdx) return virtualGains[lowerIdx]

        val lowerFreq = VIRTUAL_BANDS[lowerIdx].toFloat()
        val upperFreq = VIRTUAL_BANDS[upperIdx].toFloat()
        val hwF = hwFreqHz.toFloat()

        // Linear interpolation in log frequency space
        val logLower = Math.log10(lowerFreq.toDouble())
        val logUpper = Math.log10(upperFreq.toDouble())
        val logHw = Math.log10(hwF.toDouble())

        val t = if (logUpper - logLower > 0)
            ((logHw - logLower) / (logUpper - logLower)).coerceIn(0.0, 1.0).toFloat()
        else 0.5f

        return (virtualGains[lowerIdx] * (1f - t) + virtualGains[upperIdx] * t).toInt()
    }

    // ── State for UI ──────────────────────────────────────────────────────────

    fun getVirtualBandStates(): List<VirtualBandState> {
        return (0 until VIRTUAL_BAND_COUNT).map { i ->
            VirtualBandState(
                index = i,
                freqHz = VIRTUAL_BANDS[i],
                gainMb = virtualGains[i],
                freqLabel = formatFreq(VIRTUAL_BANDS[i])
            )
        }
    }

    fun isAttached() = equalizer != null
    fun getHardwareBandCount() = hardwareBandCount
    fun getMinLevel() = hwMinLevel
    fun getMaxLevel() = hwMaxLevel

    fun setEnabled(enabled: Boolean) {
        equalizer?.enabled = enabled
    }

    fun release() {
        try { equalizer?.release() } catch (_: Exception) {}
        equalizer = null
        hardwareBandCount = 0
    }

    private fun formatFreq(hz: Int) = if (hz >= 1000) "${hz / 1000}kHz" else "${hz}Hz"
}
