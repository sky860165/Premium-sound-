package com.yourcompany.premiumsounds.audio

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

@OptIn(UnstableApi::class)
class PremiumAudioService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    lateinit var player: ExoPlayer
    private lateinit var capabilityDetector: AudioCapabilityDetector
    private lateinit var spatialAudioController: SpatialAudioController
    private val handler = Handler(Looper.getMainLooper())

    val dspEngine = PremiumDSPEngine()
    val equalizerController = EqualizerController()
    val visualizerController = VisualizerController()
    val playlistManager = PlaylistManager()

    companion object {
        const val ACTION_AUDIO_QUALITY = "com.yourcompany.premiumsounds.AUDIO_QUALITY_CHANGED"
        const val HIRES_SAMPLE_RATE_THRESHOLD = 48000
        var instance: PremiumAudioService? = null
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        dspEngine.init(this)
        capabilityDetector = AudioCapabilityDetector(this)
        spatialAudioController = SpatialAudioController(this)
        initializePlayer()
    }

    /**
     * FIX #1: Attach DSP to audio session immediately after player ready,
     * don't wait for track change. Also retry after short delay if session = 0.
     */
    private fun tryAttachDSP() {
        val sessionId = player.audioSessionId
        if (sessionId != 0) {
            dspEngine.attach(sessionId)
            // Note: equalizerController removed — conflicts with dspEngine's NativeEQController
            visualizerController.attach(sessionId)
        } else {
            handler.postDelayed({ tryAttachDSP() }, 300)
        }
    }

    private fun initializePlayer() {
        val trackSelector = DefaultTrackSelector(this).apply {
            val params = buildUponParameters()
            params.setMaxAudioChannelCount(8)
            setParameters(params.build())
        }

        player = ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(), true
            )
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setHandleAudioBecomingNoisy(true)
            .build()

        // FIX #1: Attach DSP immediately on service create
        tryAttachDSP()

        player.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val format = player.currentTracks.groups
                    .flatMap { g -> (0 until g.length).map { g.getTrackFormat(it) } }
                    .firstOrNull { it.sampleMimeType?.startsWith("audio") == true }
                val mimeType = format?.sampleMimeType ?: "audio/raw"
                val ch = format?.channelCount ?: 2
                val sampleRate = format?.sampleRate ?: 0
                val isHiRes = sampleRate >= HIRES_SAMPLE_RATE_THRESHOLD

                spatialAudioController.refreshSpatialState(ch, mimeType)
                broadcastAudioQuality(
                    isAtmos = mimeType == "audio/eac3-joc",
                    isSurround = ch > 2,
                    channelCount = ch,
                    mimeType = mimeType,
                    sampleRate = sampleRate,
                    isHiRes = isHiRes
                )

                // FIX #1: Re-attach on every track to ensure fresh DSP binding
                val sessionId = player.audioSessionId
                if (sessionId != 0) {
                    dspEngine.attach(sessionId)
                    visualizerController.attach(sessionId)
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                playlistManager.setCurrentIndex(player.currentMediaItemIndex)
            }

            // FIX #2: Attach DSP when playback state becomes ready
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    val sessionId = player.audioSessionId
                    if (sessionId != 0) {
                        dspEngine.attach(sessionId)
                        visualizerController.attach(sessionId)
                    }
                }
            }
        })

        mediaSession = MediaSession.Builder(this, player)
            .setCallback(object : MediaSession.Callback {
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: androidx.media3.session.MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>
                ): ListenableFuture<MutableList<MediaItem>> {
                    // Fix: use localConfiguration.uri if already set,
                    // else fall back to requestMetadata.mediaUri
                    val resolved = mediaItems.map { item ->
                        val uri = item.localConfiguration?.uri
                            ?: item.requestMetadata.mediaUri
                        item.buildUpon().setUri(uri).build()
                    }.toMutableList()
                    return Futures.immediateFuture(resolved)
                }
            })
            .build()
    }

    private fun broadcastAudioQuality(
        isAtmos: Boolean, isSurround: Boolean, channelCount: Int,
        mimeType: String, sampleRate: Int, isHiRes: Boolean
    ) {
        sendBroadcast(Intent(ACTION_AUDIO_QUALITY).apply {
            putExtra("is_atmos", isAtmos)
            putExtra("is_surround", isSurround)
            putExtra("channel_count", channelCount)
            putExtra("mime_type", mimeType)
            putExtra("sample_rate", sampleRate)
            putExtra("is_hires", isHiRes)
        })
    }

    override fun onGetSession(controllerInfo: androidx.media3.session.MediaSession.ControllerInfo) = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.playWhenReady) stopSelf()
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        dspEngine.release()
        equalizerController.release()
        visualizerController.release()
        mediaSession?.run { player.release(); release(); mediaSession = null }
        super.onDestroy()
    }
}
