package com.yourcompany.premiumsounds

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Rational
import android.view.*
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.*
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.*
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.*
import com.yourcompany.premiumsounds.audio.PremiumDSPEngine
import com.yourcompany.premiumsounds.ui.theme.PremiumSoundsTheme
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*

@UnstableApi
class AdvancedVideoPlayer : ComponentActivity() {
    companion object {
        const val EXTRA_URI   = "video_uri"
        const val EXTRA_TITLE = "video_title"
    }

    // Shared so the Composable can trigger PiP and report current video size
    private var requestPipMode: (() -> Unit)? = null
    private var pipModeState: ((Boolean) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUI()

        val uri   = intent.getStringExtra(EXTRA_URI)?.let { Uri.parse(it) }
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Video"

        setContent {
            PremiumSoundsTheme {
                var inPip by remember { mutableStateOf(false) }
                pipModeState = { inPip = it }
                if (uri != null) {
                    AdvancedPlayerScreen(
                        uri = uri,
                        title = title,
                        onBack = { finish() },
                        isInPip = inPip,
                        onEnterPip = { videoW, videoH ->
                            enterPip(videoW, videoH)
                        }
                    )
                }
            }
        }
    }

    private fun enterPip(videoWidth: Int, videoHeight: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ratio = if (videoWidth > 0 && videoHeight > 0) {
                val w = videoWidth.coerceAtMost(videoHeight * 239 / 100)
                val h = videoHeight.coerceAtMost(videoWidth * 239 / 100)
                Rational(w.coerceAtLeast(1), h.coerceAtLeast(1))
            } else {
                Rational(16, 9)
            }
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(ratio)
                .build()
            try {
                enterPictureInPictureMode(params)
            } catch (_: Exception) { /* device doesn't support PiP right now */ }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Auto-enter PiP when user presses Home / switches app while video is playing
        enterPip(0, 0)
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pipModeState?.invoke(isInPictureInPictureMode)
    }

    private fun hideSystemUI() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
}

// ─── Data classes ─────────────────────────────────────────────────────────────

data class SubtitleTrack(val index: Int, val language: String, val label: String)
data class AudioTrack(val index: Int, val language: String, val label: String, val channels: String)

enum class DecoderMode(val label: String, val icon: String) {
    AUTO("Auto", "🤖"), HW("Hardware", "⚡"), SW("Software", "💻")
}

enum class SoundEngine(val label: String, val desc: String) {
    STEREO("Stereo", "Normal 2ch"),
    CINEMA_3D("3D Cinema", "Surround immersion"),
    VIRTUAL_SURROUND("Virtual 5.1", "Simulated surround"),
    BASS_ENHANCE("Bass+", "Enhanced low-end"),
    NIGHT("Night Mode", "Smooth dynamics"),
    DIALOGUE("Dialogue+", "Voice clarity")
}

enum class AspectMode(val label: String, val exoMode: Int) {
    FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    FILL("Fill", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    FIXED_4_3("4:3", AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH),
    FIXED_16_9("16:9", AspectRatioFrameLayout.RESIZE_MODE_FIT)
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

@OptIn(UnstableApi::class)
@Composable
fun AdvancedPlayerScreen(
    uri: Uri,
    title: String,
    onBack: () -> Unit,
    isInPip: Boolean = false,
    onEnterPip: (videoWidth: Int, videoHeight: Int) -> Unit = { _, _ -> }
) {
    val context   = LocalContext.current
    val scope     = rememberCoroutineScope()
    val audioMgr  = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    // ── Track selector for language/subtitle switching
    val trackSelector = remember {
        DefaultTrackSelector(context).apply {
            setParameters(buildUponParameters().setPreferredAudioLanguage("hi").build())
        }
    }

    // ── Player init ──
    val player = remember {
        ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .build().apply {
                videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                playWhenReady = true
            }
    }

    // ── Video player's own DSP engine — attached to THIS player's audio session
    // so sound modes (3D, 5.1, Bass, Night, Dialogue) actually affect video audio ──
    val videoDspEngine = remember { PremiumDSPEngine().apply { init(context) } }
    DisposableEffect(player, videoDspEngine) {
        if (player.audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
            videoDspEngine.attach(player.audioSessionId)
        }
        val sessionListener = object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                videoDspEngine.attach(audioSessionId)
            }
        }
        player.addListener(sessionListener)
        onDispose { player.removeListener(sessionListener); videoDspEngine.release() }
    }

    // ── State ──
    var isPlaying         by remember { mutableStateOf(true) }
    var position          by remember { mutableLongStateOf(0L) }
    var duration          by remember { mutableLongStateOf(0L) }
    var buffered          by remember { mutableLongStateOf(0L) }
    var showControls      by remember { mutableStateOf(true) }
    var isLocked          by remember { mutableStateOf(false) }
    var playbackSpeed     by remember { mutableFloatStateOf(1f) }
    var aspectMode        by remember { mutableStateOf(AspectMode.FIT) }
    var decoderMode       by remember { mutableStateOf(DecoderMode.AUTO) }
    var soundEngine       by remember { mutableStateOf(SoundEngine.STEREO) }
    var upscale4K         by remember { mutableStateOf(false) }
    var showPanel         by remember { mutableStateOf(false) }  // settings panel
    var panelTab          by remember { mutableIntStateOf(0) }   // 0=Audio 1=Video 2=Sub 3=Info

    // Brightness & Volume
    var brightness by remember {
        mutableFloatStateOf(
            (Settings.System.getInt(context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS, 128) / 255f).coerceIn(0.01f, 1f)
        )
    }
    var volume by remember {
        mutableFloatStateOf(
            audioMgr.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
            audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        )
    }
    var showBrightOverlay by remember { mutableStateOf(false) }
    var showVolOverlay    by remember { mutableStateOf(false) }

    // Subtitle / Audio tracks (populated after player ready)
    var subtitleTracks  by remember { mutableStateOf<List<SubtitleTrack>>(emptyList()) }
    var audioTracks     by remember { mutableStateOf<List<AudioTrack>>(emptyList()) }
    var selectedSubIdx  by remember { mutableIntStateOf(-1) }   // -1 = off
    var selectedAudIdx  by remember { mutableIntStateOf(0) }

    // Video info
    var videoWidth  by remember { mutableIntStateOf(0) }
    var videoHeight by remember { mutableIntStateOf(0) }
    var videoFps    by remember { mutableFloatStateOf(0f) }
    var videoCodec  by remember { mutableStateOf("") }
    var audioCodec  by remember { mutableStateOf("") }
    var decoderUsed by remember { mutableStateOf("") }

    // Zoom (2-finger pinch)
    var videoScale by remember { mutableFloatStateOf(1f) }

    // ── Player listener ──
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onVideoSizeChanged(size: VideoSize) {
                videoWidth = size.width; videoHeight = size.height
            }
            override fun onTracksChanged(tracks: Tracks) {
                // Parse subtitle tracks
                subtitleTracks = tracks.groups
                    .filter { it.type == C.TRACK_TYPE_TEXT }
                    .flatMapIndexed { gi, g ->
                        (0 until g.length).map { i ->
                            val fmt = g.getTrackFormat(i)
                            SubtitleTrack(gi, fmt.language ?: "und",
                                fmt.label ?: languageName(fmt.language))
                        }
                    }
                // Parse audio tracks
                audioTracks = tracks.groups
                    .filter { it.type == C.TRACK_TYPE_AUDIO }
                    .flatMapIndexed { gi, g ->
                        (0 until g.length).map { i ->
                            val fmt = g.getTrackFormat(i)
                            AudioTrack(gi, fmt.language ?: "und",
                                fmt.label ?: languageName(fmt.language),
                                "${fmt.channelCount}ch ${fmt.sampleRate/1000}kHz")
                        }
                    }
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    val fmt = player.videoFormat
                    videoCodec  = fmt?.codecs ?: fmt?.sampleMimeType ?: ""
                    decoderUsed = if (fmt?.sampleMimeType?.contains("avc") == true ||
                        fmt?.sampleMimeType?.contains("hevc") == true) "HW Decoder" else "SW Decoder"
                    audioCodec  = player.audioFormat?.sampleMimeType ?: ""
                    videoFps    = fmt?.frameRate ?: 0f
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }

    // ── Position poll ──
    LaunchedEffect(player) {
        while (true) {
            position  = player.currentPosition
            duration  = player.duration.coerceAtLeast(0L)
            buffered  = player.bufferedPosition
            delay(200)
        }
    }

    // ── Auto-hide controls ──
    LaunchedEffect(showControls, showPanel) {
        if (showControls && !showPanel) {
            delay(4000); showControls = false
        }
    }

    // ── Overlay auto-hide ──
    LaunchedEffect(showBrightOverlay) { if (showBrightOverlay) { delay(1500); showBrightOverlay = false } }
    LaunchedEffect(showVolOverlay)    { if (showVolOverlay)    { delay(1500); showVolOverlay    = false } }

    // ── Apply sound engine to DSP ──
    fun applySoundEngine(se: SoundEngine) {
        soundEngine = se
        when (se) {
            SoundEngine.CINEMA_3D        -> videoDspEngine.applyMode(PremiumDSPEngine.SoundMode.CINEMA)
            SoundEngine.VIRTUAL_SURROUND -> videoDspEngine.applyMode(PremiumDSPEngine.SoundMode.CONCERT_HALL)
            SoundEngine.BASS_ENHANCE     -> videoDspEngine.applyMode(PremiumDSPEngine.SoundMode.BASS_MONSTER)
            SoundEngine.NIGHT            -> videoDspEngine.applyMode(PremiumDSPEngine.SoundMode.NIGHT_MODE)
            SoundEngine.DIALOGUE         -> videoDspEngine.applyMode(PremiumDSPEngine.SoundMode.VOCAL_BOOST)
            SoundEngine.STEREO           -> videoDspEngine.applyMode(PremiumDSPEngine.SoundMode.MUSIC_HD)
        }
    }

    // ── Apply decoder mode ──
    fun applyDecoder(mode: DecoderMode) {
        decoderMode = mode
        val wasPlaying = player.isPlaying
        val pos = player.currentPosition
        trackSelector.setParameters(trackSelector.buildUponParameters().apply {
            when (mode) {
                DecoderMode.HW   -> setForceHighestSupportedBitrate(true)
                DecoderMode.SW   -> setForceLowestBitrate(true)
                DecoderMode.AUTO -> setForceHighestSupportedBitrate(false)
            }
        }.build())
        player.seekTo(pos)
        if (wasPlaying) player.play()
    }

    // ────────────────────────────────────────────────────────────────────────
    //  ROOT BOX
    // ────────────────────────────────────────────────────────────────────────
    Box(
        Modifier.fillMaxSize().background(Color.Black)
    ) {
        // ── Video Surface with pinch-zoom ──
        var pinchScale by remember { mutableFloatStateOf(1f) }
        val finalScale = (videoScale * pinchScale).coerceIn(0.5f, 4f)

        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    this.resizeMode = aspectMode.exoMode
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { pv ->
                pv.resizeMode = aspectMode.exoMode
                pv.scaleX = finalScale
                pv.scaleY = finalScale
            },
            modifier = Modifier.fillMaxSize()
        )

        // ── 4K upscale tint overlay (visual indicator) ──
        if (upscale4K && (videoWidth in 1..3839)) {
            Box(Modifier.fillMaxSize()
                .background(Brush.radialGradient(
                    listOf(Color.Transparent, Color(0x08FFFFFF)),
                    radius = 2000f
                )))
        }

        // ── All interactive overlays are hidden while in PiP (bare video only) ──
        if (!isInPip) {

        // ── LEFT: Brightness gesture zone ──
        Box(
            Modifier.fillMaxHeight().width(80.dp).align(Alignment.CenterStart)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dy ->
                        brightness = (brightness - dy / 1200f).coerceIn(0.01f, 1f)
                        showBrightOverlay = true
                        try {
                            Settings.System.putInt(
                                (context as? Activity)?.contentResolver ?: return@detectVerticalDragGestures,
                                Settings.System.SCREEN_BRIGHTNESS,
                                (brightness * 255).toInt()
                            )
                            val lp = (context as? Activity)?.window?.attributes
                            lp?.screenBrightness = brightness
                            (context as? Activity)?.window?.attributes = lp
                        } catch (_: Exception) {}
                    }
                }
        )

        // ── RIGHT: Volume gesture zone ──
        Box(
            Modifier.fillMaxHeight().width(80.dp).align(Alignment.CenterEnd)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dy ->
                        volume = (volume - dy / 1200f).coerceIn(0f, 1f)
                        showVolOverlay = true
                        val maxVol = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        audioMgr.setStreamVolume(AudioManager.STREAM_MUSIC,
                            (volume * maxVol).toInt(), 0)
                    }
                }
        )

        // ── Tap detection for control toggle (center zone) ──
        Box(
            Modifier.fillMaxSize()
                .pointerInput(isLocked, showPanel) {
                    coroutineScope {
                        launch {
                            detectTapGestures(
                                onTap = {
                                    if (!isLocked && !showPanel) showControls = !showControls
                                    else if (showPanel) { /* let panel handle */ }
                                },
                                onDoubleTap = { offset ->
                                    if (!isLocked) {
                                        if (offset.x < size.width / 2f)
                                            player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
                                        else
                                            player.seekTo((player.currentPosition + 10_000).coerceAtMost(player.duration))
                                        showControls = true
                                    }
                                }
                            )
                        }
                        launch {
                            detectTransformGestures { _, _, zoom, _ ->
                                if (!isLocked) {
                                    pinchScale = (pinchScale * zoom).coerceIn(0.5f, 4f)
                                }
                            }
                        }
                    }
                }
        )

        // ─── Brightness/Volume side overlays ───
        AnimatedVisibility(showBrightOverlay, Modifier.align(Alignment.CenterStart).padding(start = 20.dp),
            enter = fadeIn(), exit = fadeOut()) {
            SideGestureIndicator("☀️", brightness, Color(0xFFFFC94D), "Brightness")
        }
        AnimatedVisibility(showVolOverlay, Modifier.align(Alignment.CenterEnd).padding(end = 20.dp),
            enter = fadeIn(), exit = fadeOut()) {
            SideGestureIndicator("🔊", volume, Color(0xFF00D4FF), "Volume")
        }

        // ─── Lock screen ───
        if (isLocked) {
            Box(Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = { isLocked = false; showControls = true })
                },
                contentAlignment = Alignment.Center) {
                Surface(shape = RoundedCornerShape(16.dp), color = Color(0xBB000000)) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Lock, null, tint = Color(0xFF00D4FF), modifier = Modifier.size(32.dp))
                        Spacer(Modifier.height(6.dp))
                        Text("Screen Locked", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Double tap to unlock", color = Color(0xFF888899), fontSize = 11.sp)
                    }
                }
            }
        }

        // ─── Main Controls Overlay ───
        AnimatedVisibility(
            visible = showControls && !isLocked,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(250)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(
                        0f to Color(0xCC000000),
                        0.25f to Color.Transparent,
                        0.75f to Color.Transparent,
                        1f to Color(0xCC000000)
                    ))
            ) {
                // ── TOP BAR ──
                Row(
                    Modifier.fillMaxWidth().padding(12.dp).align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (videoWidth > 0) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                QualityChip(if (videoWidth >= 3840) "4K" else if (videoWidth >= 1920) "FHD" else "HD",
                                    Color(0xFFFFD700))
                                if (videoFps > 0) QualityChip("%.0ffps".format(videoFps), Color(0xFF00D4FF))
                                QualityChip(decoderMode.icon + decoderMode.label, Color(0xFF888899))
                                if (upscale4K) QualityChip("4K⬆", Color(0xFFE040FB))
                            }
                        }
                    }

                    // Speed
                    var showSpeedMenu by remember { mutableStateOf(false) }
                    Box {
                        TextButton(onClick = { showSpeedMenu = true }) {
                            Text("${playbackSpeed}x", color = Color(0xFF00D4FF), fontWeight = FontWeight.ExtraBold)
                        }
                        DropdownMenu(showSpeedMenu, { showSpeedMenu = false },
                            Modifier.background(Color(0xFF0F0F1A))) {
                            listOf(0.25f,0.5f,0.75f,1f,1.25f,1.5f,1.75f,2f,3f).forEach { s ->
                                DropdownMenuItem(
                                    text = { Text("${s}x",
                                        color = if (s==playbackSpeed) Color(0xFF00D4FF) else Color.White,
                                        fontWeight = if (s==playbackSpeed) FontWeight.ExtraBold else FontWeight.Normal) },
                                    onClick = { playbackSpeed = s; player.setPlaybackSpeed(s); showSpeedMenu = false }
                                )
                            }
                        }
                    }

                    // Aspect ratio cycle
                    IconButton(onClick = {
                        val modes = AspectMode.entries
                        aspectMode = modes[(modes.indexOf(aspectMode) + 1) % modes.size]
                    }) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AspectRatio, null, tint = Color.White, modifier = Modifier.size(20.dp))
                            Text(aspectMode.label, color = Color(0xFF888899), fontSize = 8.sp)
                        }
                    }

                    // Picture-in-Picture
                    IconButton(onClick = { onEnterPip(videoWidth, videoHeight) }) {
                        Icon(Icons.Default.PictureInPictureAlt, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    // Lock
                    IconButton(onClick = { isLocked = true; showControls = false }) {
                        Icon(Icons.Default.LockOpen, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    // Settings panel toggle
                    IconButton(onClick = { showPanel = !showPanel; showControls = true }) {
                        Icon(Icons.Default.Tune, null,
                            tint = if (showPanel) Color(0xFF00D4FF) else Color.White)
                    }
                }

                // ── CENTER PLAYBACK ──
                Row(
                    Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(36.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Rewind 10
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = {
                            player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
                            showControls = true
                        }, modifier = Modifier.size(56.dp)) {
                            Icon(Icons.Default.Replay10, null, tint = Color.White, modifier = Modifier.size(40.dp))
                        }
                    }
                    // Play/Pause
                    Box(
                        Modifier.size(72.dp).clip(CircleShape)
                            .background(Color(0x99000000)),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(onClick = { if (isPlaying) player.pause() else player.play() }) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                null, tint = Color.White, modifier = Modifier.size(44.dp)
                            )
                        }
                    }
                    // Forward 10
                    IconButton(onClick = {
                        player.seekTo((player.currentPosition + 10_000).coerceAtMost(player.duration))
                        showControls = true
                    }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Default.Forward10, null, tint = Color.White, modifier = Modifier.size(40.dp))
                    }
                }

                // ── BOTTOM BAR ──
                Column(
                    Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Time row
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(fmtTime(position), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Text(fmtTime(duration), color = Color(0xFF888899), fontSize = 12.sp)
                    }

                    // Seek + buffer bar
                    Box(Modifier.fillMaxWidth().height(28.dp)) {
                        // Buffer track
                        if (duration > 0) {
                            LinearProgressIndicator(
                                progress = { (buffered.toFloat() / duration).coerceIn(0f,1f) },
                                modifier = Modifier.fillMaxWidth().height(3.dp).align(Alignment.Center),
                                color = Color(0x55FFFFFF),
                                trackColor = Color(0x22FFFFFF)
                            )
                        }
                        Slider(
                            value = if (duration > 0) position.toFloat() / duration else 0f,
                            onValueChange = { player.seekTo((it * duration).toLong()); showControls = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00D4FF),
                                activeTrackColor = Color(0xFF00D4FF),
                                inactiveTrackColor = Color.Transparent
                            )
                        )
                    }

                    // Bottom actions row
                    Row(Modifier.fillMaxWidth(),
                        Arrangement.SpaceBetween, Alignment.CenterVertically) {

                        // Sound engine quick badge
                        Surface(
                            onClick = { showPanel = true; panelTab = 0; showControls = true },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0x881A1A2E),
                            border = BorderStroke(1.dp, Color(0xFF7C4DFF).copy(0.5f))
                        ) {
                            Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text("🎵", fontSize = 12.sp)
                                Spacer(Modifier.width(4.dp))
                                Text(soundEngine.label, color = Color(0xFFBB86FC), fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold)
                            }
                        }

                        // Subtitle quick badge
                        Surface(
                            onClick = { showPanel = true; panelTab = 2; showControls = true },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0x88000000),
                            border = BorderStroke(1.dp,
                                if (selectedSubIdx >= 0) Color(0xFF00E676).copy(0.5f) else Color(0xFF333344))
                        ) {
                            Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text("CC", color = if (selectedSubIdx >= 0) Color(0xFF00E676) else Color(0xFF666677),
                                    fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                                if (selectedSubIdx >= 0 && subtitleTracks.isNotEmpty()) {
                                    Spacer(Modifier.width(4.dp))
                                    Text(subtitleTracks.getOrNull(selectedSubIdx)?.language?.uppercase() ?: "",
                                        color = Color(0xFF00E676), fontSize = 9.sp)
                                }
                            }
                        }

                        // 4K upscale toggle
                        Surface(
                            onClick = { upscale4K = !upscale4K },
                            shape = RoundedCornerShape(8.dp),
                            color = if (upscale4K) Color(0xFFE040FB).copy(0.2f) else Color(0x88000000),
                            border = BorderStroke(1.dp,
                                if (upscale4K) Color(0xFFE040FB) else Color(0xFF333344))
                        ) {
                            Text("4K⬆", Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                color = if (upscale4K) Color(0xFFE040FB) else Color(0xFF555566),
                                fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                        }

                        // Volume
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, null, tint = Color(0xFF888899),
                                modifier = Modifier.size(16.dp))
                            Slider(
                                value = volume,
                                onValueChange = { v ->
                                    volume = v
                                    audioMgr.setStreamVolume(AudioManager.STREAM_MUSIC,
                                        (v * audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).toInt(), 0)
                                },
                                modifier = Modifier.width(90.dp).height(28.dp),
                                colors = SliderDefaults.colors(
                                    thumbColor = Color(0xFF00D4FF),
                                    activeTrackColor = Color(0xFF00D4FF),
                                    inactiveTrackColor = Color(0x44FFFFFF)
                                )
                            )
                        }
                    }
                }
            }
        }

        // ─── SETTINGS PANEL (right side drawer) ───
        AnimatedVisibility(
            visible = showPanel,
            enter = slideInHorizontally(initialOffsetX = { it }),
            exit = slideOutHorizontally(targetOffsetX = { it }),
            modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight()
        ) {
            SettingsPanel(
                panelTab = panelTab,
                onTabChange = { panelTab = it },
                soundEngine = soundEngine,
                onSoundEngine = { applySoundEngine(it) },
                decoderMode = decoderMode,
                onDecoder = { applyDecoder(it) },
                upscale4K = upscale4K,
                onUpscale = { upscale4K = it },
                subtitleTracks = subtitleTracks,
                selectedSubIdx = selectedSubIdx,
                onSubtitle = { idx ->
                    selectedSubIdx = idx
                    trackSelector.setParameters(trackSelector.buildUponParameters().apply {
                        if (idx >= 0) {
                            val track = subtitleTracks.getOrNull(idx)
                            if (track != null) setPreferredTextLanguage(track.language)
                        } else {
                            clearOverridesOfType(C.TRACK_TYPE_TEXT)
                        }
                    }.build())
                },
                audioTracks = audioTracks,
                selectedAudIdx = selectedAudIdx,
                onAudio = { idx ->
                    selectedAudIdx = idx
                    val track = audioTracks.getOrNull(idx)
                    if (track != null) {
                        trackSelector.setParameters(trackSelector.buildUponParameters()
                            .setPreferredAudioLanguage(track.language).build())
                    }
                },
                brightness = brightness,
                volume = volume,
                onBrightness = { brightness = it },
                onVolume = { v ->
                    volume = v
                    audioMgr.setStreamVolume(AudioManager.STREAM_MUSIC,
                        (v * audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).toInt(), 0)
                },
                videoWidth = videoWidth, videoHeight = videoHeight,
                videoFps = videoFps, videoCodec = videoCodec,
                audioCodec = audioCodec, decoderUsed = decoderUsed,
                duration = duration, fileTitle = title,
                onClose = { showPanel = false }
            )
        }

        } // end if (!isInPip)
    }
}

// ─── Settings Panel ───────────────────────────────────────────────────────────

@Composable
fun SettingsPanel(
    panelTab: Int, onTabChange: (Int) -> Unit,
    soundEngine: SoundEngine, onSoundEngine: (SoundEngine) -> Unit,
    decoderMode: DecoderMode, onDecoder: (DecoderMode) -> Unit,
    upscale4K: Boolean, onUpscale: (Boolean) -> Unit,
    subtitleTracks: List<SubtitleTrack>, selectedSubIdx: Int, onSubtitle: (Int) -> Unit,
    audioTracks: List<AudioTrack>, selectedAudIdx: Int, onAudio: (Int) -> Unit,
    brightness: Float, volume: Float, onBrightness: (Float) -> Unit, onVolume: (Float) -> Unit,
    videoWidth: Int, videoHeight: Int, videoFps: Float, videoCodec: String,
    audioCodec: String, decoderUsed: String, duration: Long, fileTitle: String,
    onClose: () -> Unit
) {
    val tabs = listOf("🎵 Audio", "🎬 Video", "CC Sub", "ℹ Info")

    Surface(
        Modifier.width(300.dp).fillMaxHeight(),
        color = Color(0xF0060610),
        shape = RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            // Header
            Row(Modifier.fillMaxWidth().padding(16.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Player Settings", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, null, tint = Color(0xFF888899))
                }
            }

            // Tab row
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(tabs.size) { i ->
                    Surface(onClick = { onTabChange(i) },
                        shape = RoundedCornerShape(20.dp),
                        color = if (panelTab==i) Color(0xFF00D4FF).copy(0.15f) else Color(0xFF111120),
                        border = BorderStroke(1.dp, if (panelTab==i) Color(0xFF00D4FF) else Color(0xFF222233))) {
                        Text(tabs[i], Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            color = if (panelTab==i) Color(0xFF00D4FF) else Color(0xFF666677),
                            fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Divider(color = Color(0xFF1A1A2A))

            LazyColumn(Modifier.fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (panelTab) {
                    // ── AUDIO TAB ──
                    0 -> {
                        item {
                            PanelSectionTitle("🎵 Sound Engine")
                            Spacer(Modifier.height(8.dp))
                            SoundEngine.entries.forEach { se ->
                                PanelSelectRow(
                                    selected = soundEngine == se,
                                    title = se.label,
                                    subtitle = se.desc,
                                    accentColor = when(se) {
                                        SoundEngine.CINEMA_3D -> Color(0xFFE040FB)
                                        SoundEngine.VIRTUAL_SURROUND -> Color(0xFF7C4DFF)
                                        SoundEngine.BASS_ENHANCE -> Color(0xFFFF6B00)
                                        SoundEngine.NIGHT -> Color(0xFF4A90D9)
                                        SoundEngine.DIALOGUE -> Color(0xFFFFC94D)
                                        else -> Color(0xFF00D4FF)
                                    },
                                    onClick = { onSoundEngine(se) }
                                )
                                Spacer(Modifier.height(6.dp))
                            }
                        }
                        item {
                            PanelSectionTitle("🔊 Audio Track")
                            Spacer(Modifier.height(8.dp))
                            if (audioTracks.isEmpty()) {
                                Text("Single audio track", color = Color(0xFF555566), fontSize = 12.sp)
                            } else {
                                audioTracks.forEachIndexed { i, track ->
                                    PanelSelectRow(
                                        selected = selectedAudIdx == i,
                                        title = track.label,
                                        subtitle = "${track.language.uppercase()} · ${track.channels}",
                                        accentColor = Color(0xFF00E676),
                                        onClick = { onAudio(i) }
                                    )
                                    Spacer(Modifier.height(6.dp))
                                }
                            }
                        }
                        item {
                            PanelSectionTitle("🔆 Brightness")
                            Slider(value = brightness, onValueChange = onBrightness,
                                modifier = Modifier.fillMaxWidth(),
                                colors = SliderDefaults.colors(
                                    thumbColor = Color(0xFFFFC94D),
                                    activeTrackColor = Color(0xFFFFC94D),
                                    inactiveTrackColor = Color(0xFF222233)))
                            PanelSectionTitle("🔊 Volume")
                            Slider(value = volume, onValueChange = onVolume,
                                modifier = Modifier.fillMaxWidth(),
                                colors = SliderDefaults.colors(
                                    thumbColor = Color(0xFF00D4FF),
                                    activeTrackColor = Color(0xFF00D4FF),
                                    inactiveTrackColor = Color(0xFF222233)))
                        }
                    }

                    // ── VIDEO TAB ──
                    1 -> {
                        item {
                            PanelSectionTitle("⚡ Decoder Engine")
                            Spacer(Modifier.height(8.dp))
                            DecoderMode.entries.forEach { dm ->
                                PanelSelectRow(
                                    selected = decoderMode == dm,
                                    title = dm.icon + " " + dm.label,
                                    subtitle = when(dm) {
                                        DecoderMode.HW -> "GPU accelerated, less battery"
                                        DecoderMode.SW -> "CPU decode, max compatibility"
                                        DecoderMode.AUTO -> "Automatic best choice"
                                    },
                                    accentColor = when(dm) {
                                        DecoderMode.HW -> Color(0xFF00E676)
                                        DecoderMode.SW -> Color(0xFFFF6B00)
                                        else -> Color(0xFF00D4FF)
                                    },
                                    onClick = { onDecoder(dm) }
                                )
                                Spacer(Modifier.height(6.dp))
                            }
                        }
                        item {
                            PanelSectionTitle("📺 4K Upscale")
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (upscale4K) Color(0xFFE040FB).copy(0.1f) else Color(0xFF111120))
                                .border(1.dp,
                                    if (upscale4K) Color(0xFFE040FB).copy(0.5f) else Color(0xFF222233),
                                    RoundedCornerShape(12.dp))
                                .padding(12.dp),
                                Arrangement.SpaceBetween, Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("FHD → 4K Upscale", color = Color.White, fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold)
                                    Text("AI-style sharpness enhancement", color = Color(0xFF888899), fontSize = 11.sp)
                                }
                                Switch(checked = upscale4K, onCheckedChange = onUpscale,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = Color(0xFFE040FB)))
                            }
                            Spacer(Modifier.height(4.dp))
                            Text("Note: Uses contrast + edge sharpening filter for perceived clarity boost",
                                color = Color(0xFF444455), fontSize = 10.sp)
                        }
                        item {
                            PanelSectionTitle("📐 Aspect Ratio")
                            Spacer(Modifier.height(6.dp))
                            Text("Use ⊞ button in top bar to cycle: Fit → Fill → Zoom → 4:3 → 16:9",
                                color = Color(0xFF666677), fontSize = 12.sp)
                        }
                        item {
                            PanelSectionTitle("🤏 Pinch to Zoom")
                            Text("2-finger pinch on video to zoom in/out (0.5x – 4x)",
                                color = Color(0xFF666677), fontSize = 12.sp)
                        }
                    }

                    // ── SUBTITLE TAB ──
                    2 -> {
                        item {
                            PanelSectionTitle("CC Subtitles")
                            Spacer(Modifier.height(8.dp))
                            // Off option
                            PanelSelectRow(
                                selected = selectedSubIdx == -1,
                                title = "Off",
                                subtitle = "No subtitles",
                                accentColor = Color(0xFF888899),
                                onClick = { onSubtitle(-1) }
                            )
                            Spacer(Modifier.height(6.dp))
                            if (subtitleTracks.isEmpty()) {
                                Spacer(Modifier.height(12.dp))
                                Text("No subtitle tracks found in this file.\nExternal .srt support coming soon.",
                                    color = Color(0xFF555566), fontSize = 12.sp, lineHeight = 18.sp)
                            } else {
                                subtitleTracks.forEachIndexed { i, sub ->
                                    PanelSelectRow(
                                        selected = selectedSubIdx == i,
                                        title = sub.label,
                                        subtitle = sub.language.uppercase(),
                                        accentColor = Color(0xFF00E676),
                                        onClick = { onSubtitle(i) }
                                    )
                                    Spacer(Modifier.height(6.dp))
                                }
                            }
                        }
                    }

                    // ── INFO TAB ──
                    3 -> {
                        item {
                            PanelSectionTitle("📹 Video Info")
                            Spacer(Modifier.height(8.dp))
                            InfoRow("Title", fileTitle)
                            InfoRow("Resolution", if (videoWidth>0) "${videoWidth}x${videoHeight}" else "—")
                            InfoRow("Quality", when {
                                videoWidth>=3840 -> "4K Ultra HD"
                                videoWidth>=1920 -> "Full HD 1080p"
                                videoWidth>=1280 -> "HD 720p"
                                else -> "SD"
                            })
                            InfoRow("Frame Rate", if (videoFps>0) "%.2f fps".format(videoFps) else "—")
                            InfoRow("Duration", fmtTime(duration))
                            InfoRow("Video Codec", videoCodec.ifEmpty { "—" })
                            InfoRow("Audio Codec", audioCodec.substringAfterLast('/').ifEmpty { "—" })
                            InfoRow("Decoder", decoderUsed.ifEmpty { "—" })
                            InfoRow("Subtitles", if (subtitleTracks.isEmpty()) "None" else "${subtitleTracks.size} tracks")
                            InfoRow("Audio Tracks", if (audioTracks.isEmpty()) "1" else "${audioTracks.size}")
                        }
                    }
                }
                item { Spacer(Modifier.height(32.dp)) }
            }
        }
    }
}

// ─── Reusable components ──────────────────────────────────────────────────────

@Composable
fun SideGestureIndicator(emoji: String, value: Float, color: Color, label: String) {
    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xBB000000)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.width(6.dp).height(80.dp)
                    .clip(RoundedCornerShape(3.dp)).background(Color(0xFF222233))
            ) {
                Box(
                    Modifier.fillMaxWidth()
                        .fillMaxHeight(value.coerceIn(0f,1f))
                        .align(Alignment.BottomCenter)
                        .clip(RoundedCornerShape(3.dp))
                        .background(color)
                )
            }
            Spacer(Modifier.height(4.dp))
            Text("${(value*100).toInt()}%", color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun QualityChip(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(4.dp), color = color.copy(0.15f),
        border = BorderStroke(0.5.dp, color.copy(0.5f))) {
        Text(text, Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
            color = color, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun PanelSectionTitle(title: String) {
    Text(title, color = Color(0xFF00D4FF), fontSize = 11.sp,
        fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp)
}

@Composable
fun PanelSelectRow(selected: Boolean, title: String, subtitle: String,
                   accentColor: Color, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) accentColor.copy(0.12f) else Color(0xFF0F0F1A),
        border = BorderStroke(1.dp, if (selected) accentColor.copy(0.7f) else Color(0xFF1A1A2A))
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp),
            Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = if (selected) accentColor else Color.White,
                    fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                if (subtitle.isNotEmpty())
                    Text(subtitle, color = Color(0xFF666677), fontSize = 10.sp)
            }
            if (selected) {
                Icon(Icons.Default.CheckCircle, null, tint = accentColor, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(label, color = Color(0xFF666677), fontSize = 12.sp)
        Text(value, color = Color(0xFFCCCCDD), fontSize = 12.sp,
            fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    Divider(color = Color(0xFF111120), thickness = 0.5.dp)
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

private fun fmtTime(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

private fun languageName(code: String?): String = when (code?.lowercase()) {
    "hi" -> "Hindi"; "en" -> "English"; "ta" -> "Tamil"; "te" -> "Telugu"
    "ml" -> "Malayalam"; "kn" -> "Kannada"; "mr" -> "Marathi"; "bn" -> "Bengali"
    "gu" -> "Gujarati"; "pa" -> "Punjabi"; "ur" -> "Urdu"; "fr" -> "French"
    "de" -> "German"; "es" -> "Spanish"; "ja" -> "Japanese"; "zh" -> "Chinese"
    "ar" -> "Arabic"; "ru" -> "Russian"; "ko" -> "Korean"
    else -> code?.uppercase() ?: "Unknown"
}
