package com.yourcompany.premiumsounds.audio

import android.content.Context
import android.provider.MediaStore

/**
 * Scans the device's MediaStore for real audio files so the user can build
 * a playlist out of music that actually exists on their phone, instead of
 * the placeholder demo paths that point to files which are never present.
 */
object DeviceMusicScanner {

    fun scan(context: Context): List<Track> {
        val tracks = mutableListOf<Track>()

        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        try {
            context.contentResolver.query(collection, projection, selection, null, sortOrder)
                ?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val uri = android.content.ContentUris.withAppendedId(collection, id)
                        tracks.add(
                            Track(
                                id = id.toString(),
                                title = cursor.getString(titleCol) ?: "Unknown Title",
                                artist = cursor.getString(artistCol) ?: "Unknown Artist",
                                album = cursor.getString(albumCol) ?: "Unknown Album",
                                uri = uri.toString(),
                                durationMs = cursor.getLong(durationCol),
                                format = friendlyMime(cursor.getString(mimeCol))
                            )
                        )
                    }
                }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return tracks
    }

    private fun friendlyMime(mime: String?): String = when (mime) {
        "audio/mpeg" -> "MP3"
        "audio/flac" -> "FLAC"
        "audio/x-flac" -> "FLAC"
        "audio/mp4" -> "AAC"
        "audio/aac" -> "AAC"
        "audio/ogg" -> "OGG"
        "audio/wav" -> "WAV"
        "audio/x-wav" -> "WAV"
        null -> "Unknown"
        else -> mime.removePrefix("audio/").uppercase()
    }
}
