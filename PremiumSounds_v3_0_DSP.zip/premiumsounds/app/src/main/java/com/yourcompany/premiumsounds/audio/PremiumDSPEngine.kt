package com.yourcompany.premiumsounds.audio

import android.media.audiofx.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * PremiumDSPEngine — Multi-layer audio processing chain
 *
 * Signal chain (in order):
 *   Input → [Equalizer 5-band] → [BassBoost] → [PresetReverb] →
 *   [Virtualizer 3D] → [LoudnessEnhancer] → Output
 *
 * Inspired by professional mastering chains. Each SoundMode applies a
 * carefully tuned combination across all effect layers simultaneously.
 */
class PremiumDSPEngine {

    // ── AudioEffect instances ──────────────────────────────────────────────────
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var presetReverb: PresetReverb? = null
    private var environmentalReverb: EnvironmentalReverb? = null

    // ── State ──────────────────────────────────────────────────────────────────
    private val _dspState = MutableStateFlow(DSPState())
    val dspState: StateFlow<DSPState> = _dspState

    data class DSPState(
        val currentMode: SoundMode = SoundMode.MUSIC_HD,
        val isEnabled: Boolean = true,
        val bands: List<BandState> = emptyList(),
        val bassStrength: Int = 500,
        val virtualizerStrength: Int = 500,
        val loudnessBoostMb: Int = 0,
        val reverbPreset: Short = PresetReverb.PRESET_NONE,
        val stereoWidth: Int = 500,          // 0–1000
        val dialogueEnhance: Boolean = false,
        val nightMode: Boolean = false,
        val isHardwareAttached: Boolean = false
    )

    data class BandState(
        val index: Int,
        val centerFreqHz: Int,
        val levelMb: Int,
        val minLevelMb: Int,
        val maxLevelMb: Int
    )

    // ── Sound Modes ───────────────────────────────────────────────────────────
    enum class SoundMode(
        val label: String,
        val emoji: String,
        val description: String,
        // EQ: [sub-bass, bass, mid, presence, air] in milli-Bel
        val eqBands: List<Int>,
        val bassStrength: Int,    // 0–1000
        val virtStrength: Int,    // 0–1000
        val loudnessMb: Int,      // 0–2000
        val reverbPreset: Short,
        val accentHex: Long
    ) {
        FLAT(
            "Flat", "◼", "Pure unprocessed signal",
            listOf(0, 0, 0, 0, 0),
            0, 0, 0, PresetReverb.PRESET_NONE, 0xFF888899L
        ),
        MUSIC_HD(
            "Music HD", "🎵", "Balanced enhancement for all genres",
            listOf(300, 200, 0, 200, 400),
            350, 400, 300, PresetReverb.PRESET_NONE, 0xFF00D4FFL
        ),
        BASS_MONSTER(
            "Bass Monster", "🔊", "Deep sub-bass with punchy kick",
            listOf(900, 700, -100, 0, 100),
            900, 300, 400, PresetReverb.PRESET_NONE, 0xFF7C4DFFL
        ),
        CINEMA(
            "Cinema", "🎬", "Wide surround with clear dialogue",
            listOf(400, 200, 300, 400, 200),
            500, 850, 500, PresetReverb.PRESET_LARGEHALL, 0xFFFF6B6BL
        ),
        GAME(
            "Game", "🎮", "Directional audio with spatial depth",
            listOf(200, 400, 100, 500, 300),
            600, 950, 300, PresetReverb.PRESET_ROOM, 0xFF00E676L
        ),
        PODCAST(
            "Podcast", "🎙️", "Voice clarity and noise floor reduction",
            listOf(-400, -200, 700, 600, 100),
            0, 200, 600, PresetReverb.PRESET_NONE, 0xFFFFC94DL
        ),
        NIGHT_MODE(
            "Night Mode", "🌙", "Compressed dynamics, comfortable volume",
            listOf(100, 100, 200, 100, 0),
            200, 200, 800, PresetReverb.PRESET_NONE, 0xFF4A90D9L
        ),
        CONCERT_HALL(
            "Concert Hall", "🎻", "Live acoustic ambience simulation",
            listOf(200, 100, -100, 300, 500),
            200, 700, 200, PresetReverb.PRESET_CONCERTHALL, 0xFFE040FBL
        ),
        DEEP_SPACE(
            "Deep Space", "🚀", "Maximum 3D spatial immersion",
            listOf(500, 300, 0, 400, 600),
            400, 1000, 400, PresetReverb.PRESET_LARGEROOM, 0xFF00BCD4L
        ),
        VOCAL_BOOST(
            "Vocal Boost", "🎤", "Enhanced clarity for singers and speech",
            listOf(-300, -100, 800, 700, 200),
            100, 300, 500, PresetReverb.PRESET_NONE, 0xFFFF9800L
        ),
        ROCK(
            "Rock", "🎸", "Punchy mids with aggressive highs",
            listOf(600, 400, -200, 500, 700),
            700, 500, 200, PresetReverb.PRESET_NONE, 0xFFFF5252L
        ),
        CLASSICAL(
            "Classical", "🎼", "Natural warmth with airy highs",
            listOf(300, 100, -200, 100, 500),
            100, 350, 100, PresetReverb.PRESET_MEDIUMHALL, 0xFFF8BBD0L
        )
    }

    // ── Attach to audio session ────────────────────────────────────────────────
    fun attach(audioSessionId: Int) {
        release()
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(0); enabled = false
            }
            presetReverb = try {
                PresetReverb(0, audioSessionId).apply { enabled = true }
            } catch (_: Exception) { null }

            _dspState.value = _dspState.value.copy(isHardwareAttached = true)
            applyMode(_dspState.value.currentMode, announce = false)
            refreshBandState()
        } catch (e: Exception) {
            e.printStackTrace()
            _dspState.value = _dspState.value.copy(isHardwareAttached = false)
        }
    }

    // ── Apply full sound mode (main entry point) ───────────────────────────────
    fun applyMode(mode: SoundMode, announce: Boolean = true) {
        val eq = equalizer ?: run {
            if (announce) _dspState.value = _dspState.value.copy(currentMode = mode)
            return
        }
        val bandCount = eq.numberOfBands.toInt()

        // 1. EQ bands
        mode.eqBands.take(bandCount).forEachIndexed { i, level ->
            try { eq.setBandLevel(i.toShort(), level.toShort()) } catch (_: Exception) {}
        }

        // 2. Bass Boost
        try {
            bassBoost?.setStrength(mode.bassStrength.toShort())
            bassBoost?.enabled = mode.bassStrength > 0
        } catch (_: Exception) {}

        // 3. Virtualizer
        try {
            virtualizer?.setStrength(mode.virtStrength.toShort())
            virtualizer?.enabled = mode.virtStrength > 0
        } catch (_: Exception) {}

        // 4. Loudness Enhancer
        try {
            loudnessEnhancer?.setTargetGain(mode.loudnessMb)
            loudnessEnhancer?.enabled = mode.loudnessMb > 0
        } catch (_: Exception) {}

        // 5. Reverb
        try {
            presetReverb?.preset = mode.reverbPreset
            presetReverb?.enabled = mode.reverbPreset != PresetReverb.PRESET_NONE
        } catch (_: Exception) {}

        if (announce) {
            _dspState.value = _dspState.value.copy(
                currentMode = mode,
                bassStrength = mode.bassStrength,
                virtualizerStrength = mode.virtStrength,
                loudnessBoostMb = mode.loudnessMb,
                reverbPreset = mode.reverbPreset
            )
            refreshBandState()
        }
    }

    // ── Manual fine-tune overrides ─────────────────────────────────────────────
    fun setBandLevel(bandIndex: Int, levelMb: Int) {
        try {
            equalizer?.setBandLevel(bandIndex.toShort(), levelMb.toShort())
            refreshBandState()
        } catch (_: Exception) {}
    }

    fun setBassStrength(strength: Int) {
        try {
            bassBoost?.setStrength(strength.toShort())
            bassBoost?.enabled = strength > 0
            _dspState.value = _dspState.value.copy(bassStrength = strength)
        } catch (_: Exception) {}
    }

    fun setVirtualizerStrength(strength: Int) {
        try {
            virtualizer?.setStrength(strength.toShort())
            virtualizer?.enabled = strength > 0
            _dspState.value = _dspState.value.copy(virtualizerStrength = strength)
        } catch (_: Exception) {}
    }

    fun setLoudnessBoost(gainMb: Int) {
        try {
            loudnessEnhancer?.setTargetGain(gainMb)
            loudnessEnhancer?.enabled = gainMb > 0
            _dspState.value = _dspState.value.copy(loudnessBoostMb = gainMb)
        } catch (_: Exception) {}
    }

    // Night mode: strong dynamic compression via loudness + reduced EQ peaks
    fun setNightMode(on: Boolean) {
        if (on) applyMode(SoundMode.NIGHT_MODE)
        _dspState.value = _dspState.value.copy(nightMode = on)
    }

    // Dialogue enhancer: boost 1kHz–4kHz band for voice clarity
    fun setDialogueEnhance(on: Boolean) {
        val eq = equalizer ?: return
        try {
            val bandCount = eq.numberOfBands.toInt()
            // Band 2 = mid (~1kHz), Band 3 = presence (~4kHz)
            if (on) {
                if (bandCount > 2) eq.setBandLevel(2, 800)
                if (bandCount > 3) eq.setBandLevel(3, 600)
            } else {
                applyMode(_dspState.value.currentMode, announce = false)
            }
            _dspState.value = _dspState.value.copy(dialogueEnhance = on)
            refreshBandState()
        } catch (_: Exception) {}
    }

    fun setEnabled(enabled: Boolean) {
        equalizer?.enabled = enabled
        bassBoost?.enabled = enabled
        virtualizer?.enabled = enabled
        loudnessEnhancer?.enabled = enabled && _dspState.value.loudnessBoostMb > 0
        presetReverb?.enabled = enabled && _dspState.value.reverbPreset != PresetReverb.PRESET_NONE
        _dspState.value = _dspState.value.copy(isEnabled = enabled)
    }

    // ── Internal helpers ───────────────────────────────────────────────────────
    private fun refreshBandState() {
        val eq = equalizer ?: return
        val range = try { eq.bandLevelRange } catch (_: Exception) { shortArrayOf(-1500, 1500) }
        val bands = (0 until eq.numberOfBands.toInt()).map { i ->
            BandState(
                index = i,
                centerFreqHz = try { eq.getCenterFreq(i.toShort()) / 1000 } catch (_: Exception) { 0 },
                levelMb = try { eq.getBandLevel(i.toShort()).toInt() } catch (_: Exception) { 0 },
                minLevelMb = range[0].toInt(),
                maxLevelMb = range[1].toInt()
            )
        }
        _dspState.value = _dspState.value.copy(bands = bands)
    }

    fun release() {
        listOf(equalizer, bassBoost, virtualizer, loudnessEnhancer, presetReverb).forEach {
            try { it?.release() } catch (_: Exception) {}
        }
        equalizer = null; bassBoost = null; virtualizer = null
        loudnessEnhancer = null; presetReverb = null
        _dspState.value = _dspState.value.copy(isHardwareAttached = false, bands = emptyList())
    }
}
