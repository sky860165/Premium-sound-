package com.yourcompany.premiumsounds

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.yourcompany.premiumsounds.audio.AudioCapabilityDetector
import com.yourcompany.premiumsounds.audio.DeviceMusicScanner
import com.yourcompany.premiumsounds.audio.PremiumAudioService
import com.yourcompany.premiumsounds.audio.Track
import com.yourcompany.premiumsounds.ui.theme.PremiumSoundsTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.*

@UnstableApi
class MainActivity : ComponentActivity() {

    private var mediaController: MediaController? = null
    private var audioQualityReceiver: BroadcastReceiver? = null

    private val notifPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    private val recordPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) recordPermission.launch(Manifest.permission.RECORD_AUDIO)

        val sessionToken = SessionToken(this, ComponentName(this, PremiumAudioService::class.java))
        val future = MediaController.Builder(this, sessionToken).buildAsync()
        future.addListener({ try { mediaController = future.get() } catch (_: Exception) {} }, MoreExecutors.directExecutor())

        setContent {
            PremiumSoundsTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen(mediaController)
                }
            }
        }
    }

    override fun onDestroy() {
        mediaController?.release()
        audioQualityReceiver?.let { unregisterReceiver(it) }
        super.onDestroy()
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN SCREEN WITH BOTTOM NAV
// ─────────────────────────────────────────────────────────────────────────────
@UnstableApi
@Composable
fun MainScreen(mediaController: MediaController?) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Player", "Equalizer", "Playlist")
    val icons = listOf(Icons.Default.Headphones, Icons.Default.GraphicEq, Icons.Default.QueueMusic)

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0D0D14),
                tonalElevation = 0.dp
            ) {
                tabs.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = selectedTab == i,
                        onClick = { selectedTab = i },
                        icon = { Icon(icons[i], contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00D4FF),
                            selectedTextColor = Color(0xFF00D4FF),
                            unselectedIconColor = Color(0xFF555566),
                            unselectedTextColor = Color(0xFF555566),
                            indicatorColor = Color(0xFF00D4FF).copy(alpha = 0.12f)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF060608)
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            AnimatedContent(targetState = selectedTab, label = "tab_anim",
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(200)) }
            ) { tab ->
                when (tab) {
                    0 -> PlayerTab(mediaController)
                    1 -> EqualizerTab()
                    2 -> PlaylistTab(mediaController)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PLAYER TAB
// ─────────────────────────────────────────────────────────────────────────────
@UnstableApi
@Composable
fun PlayerTab(mediaController: MediaController?) {
    val context = LocalContext.current
    val capabilityDetector = remember { AudioCapabilityDetector(context) }
    val dolbyStatus = remember { capabilityDetector.getDolbySupportStatus() }

    var isPlaying by remember { mutableStateOf(false) }
    var isAtmosActive by remember { mutableStateOf(false) }
    var currentMime by remember { mutableStateOf("audio/raw") }
    var channelCount by remember { mutableIntStateOf(2) }
    var sampleRate by remember { mutableIntStateOf(0) }
    var isHiRes by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(1f) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var currentTrackTitle by remember { mutableStateOf("No Track") }
    var currentTrackArtist by remember { mutableStateOf("Select from Playlist") }

    val service = PremiumAudioService.instance
    val waveform by (service?.visualizerController?.waveform ?: MutableStateFlow(ByteArray(128))).collectAsState()
    val vizActive by (service?.visualizerController?.isActive ?: MutableStateFlow(false)).collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 0.7f,
        animationSpec = infiniteRepeatable(tween(1000, easing = EaseInOut), RepeatMode.Reverse),
        label = "glow_alpha"
    )
    val accentColor by animateColorAsState(
        if (isAtmosActive) Color(0xFF00D4FF) else Color(0xFF7C4DFF), tween(600), label = "accent"
    )

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                intent?.let {
                    isAtmosActive = it.getBooleanExtra("is_atmos", false)
                    currentMime = it.getStringExtra("mime_type") ?: "audio/raw"
                    channelCount = it.getIntExtra("channel_count", 2)
                    sampleRate = it.getIntExtra("sample_rate", 0)
                    isHiRes = it.getBooleanExtra("is_hires", false)
                }
            }
        }
        val filter = IntentFilter(PremiumAudioService.ACTION_AUDIO_QUALITY)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else context.registerReceiver(receiver, filter)
        onDispose { context.unregisterReceiver(receiver) }
    }

    LaunchedEffect(mediaController) {
        while (true) {
            mediaController?.let {
                isPlaying = it.isPlaying
                position = it.currentPosition
                duration = it.duration.takeIf { d -> d > 0 } ?: 0L
                currentTrackTitle = it.mediaMetadata.title?.toString() ?: "No Track"
                currentTrackArtist = it.mediaMetadata.artist?.toString() ?: ""
            }
            delay(300)
        }
    }

    LaunchedEffect(volume) { mediaController?.volume = volume }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060608))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "PREMIUM SOUND",
                style = TextStyle(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00D4FF), Color(0xFF7C4DFF), Color(0xFFFFC94D))
                    ),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 3.sp
                )
            )
            Spacer(Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xFFFFC94D).copy(0.15f),
                border = BorderStroke(1.dp, Color(0xFFFFC94D).copy(0.6f))
            ) {
                Text("PRO", Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    color = Color(0xFFFFC94D), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Text("Immersive Audio Engine", fontSize = 11.sp, color = Color(0xFF555566), letterSpacing = 1.sp)

        Spacer(Modifier.height(24.dp))

        // Visualizer Orb
        Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
            if (isAtmosActive || isPlaying) {
                Canvas(modifier = Modifier.size(240.dp)) {
                    val cx = size.width / 2
                    val cy = size.height / 2
                    val baseR = size.width * 0.42f
                    val paint = androidx.compose.ui.graphics.Paint().apply {
                        color = accentColor.copy(alpha = glowAlpha * 0.3f)
                    }
                    drawCircle(accentColor.copy(alpha = glowAlpha * 0.15f), baseR + 20f, Offset(cx, cy))

                    if (vizActive && waveform.isNotEmpty()) {
                        val count = waveform.size.coerceAtMost(64)
                        val path = Path()
                        for (i in 0 until count) {
                            val angle = (i.toFloat() / count) * 2f * PI.toFloat()
                            val amp = (waveform[i].toInt() and 0xFF) / 255f
                            val r = baseR + amp * 30f
                            val x = cx + r * cos(angle)
                            val y = cy + r * sin(angle)
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        path.close()
                        drawPath(path, accentColor.copy(alpha = 0.5f))
                    }
                }
            }
            Box(
                Modifier.size(200.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFF1A1A2E), Color(0xFF0D0D14)))),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Headphones, null, Modifier.size(64.dp), tint = accentColor)
                    Spacer(Modifier.height(6.dp))
                    Text(mimeLabel(currentMime), fontSize = 10.sp, color = accentColor.copy(0.8f),
                        fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        Text(currentTrackTitle, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(currentTrackArtist, fontSize = 13.sp, color = Color(0xFF888899))

        Spacer(Modifier.height(6.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (dolbyStatus.isAtmosSupported) AudioBadge("ATMOS", accentColor, isAtmosActive)
            if (dolbyStatus.hasDolbyHardware) AudioBadge("SURROUND", Color(0xFF7C4DFF), true)
            if (isHiRes) AudioBadge("HI-RES", Color(0xFFFFC94D), true)
            AudioBadge("${channelCount}CH", Color(0xFF00E676), channelCount > 2)
        }

        Spacer(Modifier.height(24.dp))

        // Seek bar
        Slider(
            value = if (duration > 0) position.toFloat() / duration else 0f,
            onValueChange = { mediaController?.seekTo((it * duration).toLong()) },
            modifier = Modifier.fillMaxWidth(),
            colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor,
                inactiveTrackColor = Color(0xFF2A2A3A))
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), fontSize = 11.sp, color = Color(0xFF666677))
            Text(formatTime(duration), fontSize = 11.sp, color = Color(0xFF666677))
        }

        Spacer(Modifier.height(16.dp))

        // Controls
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { mediaController?.seekToPreviousMediaItem() }) {
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = { mediaController?.seekBack() }) {
                Icon(Icons.Default.Replay10, null, tint = Color(0xFFAAAAAA), modifier = Modifier.size(28.dp))
            }
            Box(
                Modifier.size(68.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(accentColor, accentColor.copy(0.7f)))),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = {
                    if (isPlaying) {
                        mediaController?.pause()
                    } else {
                        val service = PremiumAudioService.instance
                        if (mediaController?.mediaItemCount == 0 && service != null) {
                            val items = service.playlistManager.toMediaItems()
                            mediaController?.setMediaItems(items)
                            mediaController?.prepare()
                        }
                        mediaController?.play()
                    }
                }) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        null, tint = Color.Black, modifier = Modifier.size(36.dp)
                    )
                }
            }
            IconButton(onClick = { mediaController?.seekForward() }) {
                Icon(Icons.Default.Forward10, null, tint = Color(0xFFAAAAAA), modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = { mediaController?.seekToNextMediaItem() }) {
                Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }

        Spacer(Modifier.height(12.dp))

        // Volume
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.VolumeDown, null, tint = Color(0xFF555566), modifier = Modifier.size(18.dp))
            Slider(value = volume, onValueChange = { volume = it },
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor,
                    inactiveTrackColor = Color(0xFF2A2A3A))
            )
            Icon(Icons.Default.VolumeUp, null, tint = Color(0xFF555566), modifier = Modifier.size(18.dp))
        }

        Spacer(Modifier.height(16.dp))

        // Capabilities
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF111118)).padding(16.dp)
        ) {
            Text("DEVICE CAPABILITIES", fontSize = 10.sp, color = Color(0xFF666677),
                letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            CapRow("Dolby Atmos", dolbyStatus.isAtmosSupported)
            CapRow("Dolby Hardware", dolbyStatus.hasDolbyHardware)
            CapRow("Surround Sound", dolbyStatus.supportedFormats.isNotEmpty())
            CapRow("Spatial Visualizer", vizActive)
            if (sampleRate > 0) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Sample Rate", fontSize = 13.sp, color = Color(0xFFCCCCDD))
                    Text("${sampleRate / 1000.0} kHz", fontSize = 12.sp,
                        color = if (isHiRes) Color(0xFFFFC94D) else Color(0xFF888899),
                        fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// EQUALIZER TAB — PremiumDSP Engine
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun EqualizerTab() {
    val context = LocalContext.current

    val service = PremiumAudioService.instance
    val dspEngine = service?.dspEngine
    val dspState by (dspEngine?.dspState ?: MutableStateFlow(
        com.yourcompany.premiumsounds.audio.PremiumDSPEngine.DSPState()
    )).collectAsState()

    var isGlobalMode by remember { mutableStateOf(true) }
    val globalService = com.yourcompany.premiumsounds.audio.GlobalAudioEffectService.instance

    val accentColor = Color(0xFF00D4FF)
    val allModes = com.yourcompany.premiumsounds.audio.PremiumDSPEngine.SoundMode.values().toList()

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF060608))
            .verticalScroll(rememberScrollState())
    ) {

        // ── Header ──────────────────────────────────────────────────────────
        Column(Modifier.padding(horizontal = 20.dp, vertical = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("DSP ENGINE", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                    color = Color.White, letterSpacing = 3.sp)
                Spacer(Modifier.width(8.dp))
                Surface(shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFFF6B6B).copy(0.15f),
                    border = BorderStroke(1.dp, Color(0xFFFF6B6B).copy(0.6f))) {
                    Text("ULTRA", Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        color = Color(0xFFFF6B6B), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            Text(
                if (isGlobalMode) "🌐 Global — all apps enhanced" else "🎵 In-app player only",
                fontSize = 11.sp,
                color = if (isGlobalMode) Color(0xFF00E676) else Color(0xFF555566)
            )
        }

        // ── Global Mode Toggle ───────────────────────────────────────────────
        Surface(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(14.dp),
            color = if (isGlobalMode) Color(0xFF0D2218) else Color(0xFF111118),
            border = BorderStroke(1.dp, if (isGlobalMode) Color(0xFF00E676).copy(0.5f) else Color(0xFF2A2A3A))
        ) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, null,
                            tint = if (isGlobalMode) Color(0xFF00E676) else Color(0xFF555566),
                            modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("GLOBAL MODE", color = if (isGlobalMode) Color(0xFF00E676) else Color(0xFF888899),
                            fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Text("YouTube · Spotify · Chrome · all apps",
                        fontSize = 10.sp, color = Color(0xFF555566),
                        modifier = Modifier.padding(top = 2.dp, start = 22.dp))
                }
                Switch(checked = isGlobalMode, onCheckedChange = { isGlobalMode = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black, checkedTrackColor = Color(0xFF00E676)))
            }
        }

        Spacer(Modifier.height(20.dp))

        // ── Sound Mode Cards (horizontal scroll) ─────────────────────────────
        Text("SOUND MODES", fontSize = 10.sp, color = Color(0xFF555566),
            letterSpacing = 1.5.sp, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(10.dp))

        androidx.compose.foundation.lazy.LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(allModes.size) { i ->
                val mode = allModes[i]
                val isSelected = dspState.currentMode == mode
                val modeColor = Color(mode.accentHex)

                Surface(
                    onClick = {
                        dspEngine?.applyMode(mode)
                        // Also sync global service to same preset-equivalent
                        if (isGlobalMode) {
                            globalService?.applyPreset(
                                when (mode) {
                                    com.yourcompany.premiumsounds.audio.PremiumDSPEngine.SoundMode.BASS_MONSTER -> "Bass Boost"
                                    com.yourcompany.premiumsounds.audio.PremiumDSPEngine.SoundMode.CLASSICAL -> "Classical"
                                    com.yourcompany.premiumsounds.audio.PremiumDSPEngine.SoundMode.VOCAL_BOOST -> "Vocal"
                                    com.yourcompany.premiumsounds.audio.PremiumDSPEngine.SoundMode.ROCK -> "Rock"
                                    com.yourcompany.premiumsounds.audio.PremiumDSPEngine.SoundMode.FLAT -> "Flat"
                                    else -> "Custom"
                                }
                            )
                            globalService?.setBassStrength(mode.bassStrength)
                            globalService?.setVirtualizerStrength(mode.virtStrength)
                            globalService?.setPremiumBoost(mode.loudnessMb)
                        }
                    },
                    shape = RoundedCornerShape(18.dp),
                    color = if (isSelected) modeColor.copy(0.18f) else Color(0xFF0F0F18),
                    border = BorderStroke(
                        if (isSelected) 1.5.dp else 1.dp,
                        if (isSelected) modeColor else Color(0xFF222233)
                    ),
                    modifier = Modifier.width(110.dp)
                ) {
                    Column(
                        Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(mode.emoji, fontSize = 24.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(mode.label, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            color = if (isSelected) modeColor else Color(0xFF888899),
                            maxLines = 1)
                        Spacer(Modifier.height(4.dp))
                        Text(mode.description, fontSize = 9.sp, color = Color(0xFF444455),
                            maxLines = 2, lineHeight = 12.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ── Active mode info strip ────────────────────────────────────────────
        val activeMode = dspState.currentMode
        Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(14.dp),
            color = Color(activeMode.accentHex).copy(0.08f),
            border = BorderStroke(1.dp, Color(activeMode.accentHex).copy(0.3f))
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(activeMode.emoji, fontSize = 28.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(activeMode.label, color = Color(activeMode.accentHex),
                        fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text(activeMode.description, color = Color(0xFF666677), fontSize = 11.sp)
                }
                Switch(
                    checked = dspState.isEnabled,
                    onCheckedChange = { dspEngine?.setEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = Color(activeMode.accentHex))
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // ── DSP meters ────────────────────────────────────────────────────────
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {

            Text("DSP CHAIN", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))

            DSPMeter("EQ Bands", "${dspState.bands.size}-band active",
                dspState.bands.isNotEmpty(), Color(0xFF00D4FF))
            DSPMeter("Bass Engine", "${dspState.bassStrength / 10}% power",
                dspState.bassStrength > 0, Color(0xFF7C4DFF))
            DSPMeter("3D Spatial", "${dspState.virtualizerStrength / 10}% width",
                dspState.virtualizerStrength > 0, Color(0xFF00E676))
            DSPMeter("Loudness", "+${dspState.loudnessBoostMb / 100} dB clean gain",
                dspState.loudnessBoostMb > 0, Color(0xFFFFC94D))
            DSPMeter("Reverb/Space", reverbLabel(dspState.reverbPreset),
                dspState.reverbPreset != 0, Color(0xFFE040FB))
        }

        Spacer(Modifier.height(16.dp))

        // ── Quick toggles ──────────────────────────────────────────────────────
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {

            Text("QUICK ENHANCE", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickToggle(
                    Modifier.weight(1f), "🌙", "Night Mode",
                    dspState.nightMode, Color(0xFF4A90D9)
                ) { dspEngine?.setNightMode(!dspState.nightMode) }

                QuickToggle(
                    Modifier.weight(1f), "🎤", "Dialogue",
                    dspState.dialogueEnhance, Color(0xFFFF9800)
                ) { dspEngine?.setDialogueEnhance(!dspState.dialogueEnhance) }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── Manual fine-tune (only shows when hardware attached) ──────────────
        if (dspState.bands.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {

                Text("FINE TUNE", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))

                // EQ bar visualizer
                Row(Modifier.fillMaxWidth().height(60.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color(0xFF080810)).padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically) {
                    dspState.bands.forEach { band ->
                        val norm = (band.levelMb - band.minLevelMb).toFloat() /
                                (band.maxLevelMb - band.minLevelMb).coerceAtLeast(1).toFloat()
                        val h = (norm * 48f).dp
                        Box(Modifier.width(24.dp), contentAlignment = Alignment.BottomCenter) {
                            Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.BottomCenter) {
                                Box(Modifier.fillMaxWidth(0.7f).height(h.coerceAtLeast(2.dp))
                                    .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                    .background(Brush.verticalGradient(
                                        listOf(Color(activeMode.accentHex), Color(activeMode.accentHex).copy(0.3f)))))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))

                dspState.bands.forEach { band ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${band.centerFreqHz}Hz", fontSize = 11.sp, color = Color(0xFF666677))
                        Text("${band.levelMb / 100}dB", fontSize = 11.sp,
                            color = Color(activeMode.accentHex), fontWeight = FontWeight.Bold)
                    }
                    Slider(value = band.levelMb.toFloat(),
                        onValueChange = { dspEngine?.setBandLevel(band.index, it.toInt()) },
                        valueRange = band.minLevelMb.toFloat()..band.maxLevelMb.toFloat(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(activeMode.accentHex),
                            activeTrackColor = Color(activeMode.accentHex),
                            inactiveTrackColor = Color(0xFF222233)))
                }

                // Bass
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("BASS ENGINE", fontSize = 11.sp, color = Color(0xFF666677))
                    Text("${dspState.bassStrength / 10}%", fontSize = 11.sp,
                        color = Color(0xFF7C4DFF), fontWeight = FontWeight.Bold)
                }
                Slider(value = dspState.bassStrength.toFloat(),
                    onValueChange = { dspEngine?.setBassStrength(it.toInt()) },
                    valueRange = 0f..1000f, modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF7C4DFF),
                        activeTrackColor = Color(0xFF7C4DFF), inactiveTrackColor = Color(0xFF222233)))

                // Spatial
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("3D SPATIAL", fontSize = 11.sp, color = Color(0xFF666677))
                    Text("${dspState.virtualizerStrength / 10}%", fontSize = 11.sp,
                        color = Color(0xFF00E676), fontWeight = FontWeight.Bold)
                }
                Slider(value = dspState.virtualizerStrength.toFloat(),
                    onValueChange = { dspEngine?.setVirtualizerStrength(it.toInt()) },
                    valueRange = 0f..1000f, modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676),
                        activeTrackColor = Color(0xFF00E676), inactiveTrackColor = Color(0xFF222233)))

                // Loudness
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("LOUDNESS BOOST", fontSize = 11.sp, color = Color(0xFF666677))
                    Text("+${dspState.loudnessBoostMb / 100}dB", fontSize = 11.sp,
                        color = Color(0xFFFFC94D), fontWeight = FontWeight.Bold)
                }
                Slider(value = dspState.loudnessBoostMb.toFloat(),
                    onValueChange = { dspEngine?.setLoudnessBoost(it.toInt()) },
                    valueRange = 0f..2000f, modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFFFFC94D),
                        activeTrackColor = Color(0xFFFFC94D), inactiveTrackColor = Color(0xFF222233)))
            }
        } else {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(12.dp)).background(Color(0xFF0F0F18)).padding(20.dp),
                contentAlignment = Alignment.Center) {
                Text(
                    if (isGlobalMode) "▶ Start any app to activate fine-tune"
                    else "▶ Play a track to activate fine-tune",
                    color = Color(0xFF444455), fontSize = 13.sp)
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

// ── Helper composables ─────────────────────────────────────────────────────────
@Composable
fun DSPMeter(label: String, value: String, isActive: Boolean, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape)
            .background(if (isActive) color else Color(0xFF2A2A3A)))
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 12.sp, color = Color(0xFFCCCCDD), modifier = Modifier.width(110.dp))
        Spacer(Modifier.weight(1f))
        Text(value, fontSize = 11.sp,
            color = if (isActive) color else Color(0xFF444455),
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun QuickToggle(modifier: Modifier, emoji: String, label: String,
                isOn: Boolean, color: Color, onToggle: () -> Unit) {
    Surface(onClick = onToggle, modifier = modifier, shape = RoundedCornerShape(14.dp),
        color = if (isOn) color.copy(0.15f) else Color(0xFF0A0A12),
        border = BorderStroke(1.dp, if (isOn) color.copy(0.6f) else Color(0xFF1A1A2A))
    ) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 22.sp)
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                color = if (isOn) color else Color(0xFF555566))
            Text(if (isOn) "ON" else "OFF", fontSize = 9.sp,
                color = if (isOn) color.copy(0.8f) else Color(0xFF333344),
                fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        }
    }
}

private fun reverbLabel(preset: Int) = when (preset) {
    0 -> "Off"
    1 -> "Small Room"
    2 -> "Medium Room"
    3 -> "Large Room"
    4 -> "Medium Hall"
    5 -> "Large Hall"
    6 -> "Plate"
    else -> "Active"
}


// ─────────────────────────────────────────────────────────────────────────────
// PLAYLIST TAB
// ─────────────────────────────────────────────────────────────────────────────
@UnstableApi
@Composable
fun PlaylistTab(mediaController: MediaController?) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val service = PremiumAudioService.instance
    val playlistManager = service?.playlistManager
    val tracks by (playlistManager?.playlist ?: MutableStateFlow(emptyList<Track>())).collectAsState()
    val currentIndex by (playlistManager?.currentIndex ?: MutableStateFlow(0)).collectAsState()

    val accentColor = Color(0xFF00D4FF)

    var isScanning by remember { mutableStateOf(false) }
    var scannedTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    val selectedIds = remember { mutableStateMapOf<String, Boolean>() }
    var showImportDialog by remember { mutableStateOf(false) }

    val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    fun startScan() {
        isScanning = true
        coroutineScope.launch {
            val found = withContext(Dispatchers.IO) { DeviceMusicScanner.scan(context) }
            scannedTracks = found
            selectedIds.clear()
            found.forEach { selectedIds[it.id] = true }
            isScanning = false
            showImportDialog = true
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startScan() }

    fun onImportClicked() {
        val hasPermission = ContextCompat.checkSelfPermission(context, audioPermission) ==
            PackageManager.PERMISSION_GRANTED
        if (hasPermission) startScan() else permissionLauncher.launch(audioPermission)
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF060608))) {
        // Header
        Column(Modifier.padding(20.dp)) {
            Text("PLAYLIST", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                color = Color.White, letterSpacing = 3.sp)
            Text("${tracks.size} tracks", fontSize = 11.sp, color = Color(0xFF555566))
        }

        // Play all / Shuffle / Import row
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    if (playlistManager != null && mediaController != null && tracks.isNotEmpty()) {
                        mediaController.setMediaItems(playlistManager.toMediaItems())
                        mediaController.prepare()
                        mediaController.play()
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.Black)
                Spacer(Modifier.width(4.dp))
                Text("Play All", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = {
                    if (playlistManager != null && mediaController != null) {
                        mediaController.shuffleModeEnabled = !mediaController.shuffleModeEnabled
                    }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF333344))
            ) {
                Icon(Icons.Default.Shuffle, null, tint = Color(0xFF888899))
                Spacer(Modifier.width(4.dp))
                Text("Shuffle", color = Color(0xFF888899))
            }
        }

        Spacer(Modifier.height(10.dp))

        // Import from device
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            OutlinedButton(
                onClick = { onImportClicked() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFFFC94D).copy(0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFFC94D))
            ) {
                if (isScanning) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp,
                        color = Color(0xFFFFC94D))
                    Spacer(Modifier.width(8.dp))
                    Text("Scanning device...")
                } else {
                    Icon(Icons.Default.LibraryMusic, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Import Songs From Device", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        if (tracks.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.QueueMusic, null, tint = Color(0xFF333344), modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Your playlist is empty", color = Color(0xFF888899), fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text("Tap \"Import Songs From Device\" to add real music", color = Color(0xFF555566),
                        fontSize = 12.sp)
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(tracks) { index, track ->
                val isCurrentTrack = index == currentIndex
                Row(
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isCurrentTrack) accentColor.copy(0.1f) else Color(0xFF111118))
                        .border(
                            if (isCurrentTrack) BorderStroke(1.dp, accentColor.copy(0.4f))
                            else BorderStroke(0.dp, Color.Transparent),
                            RoundedCornerShape(14.dp)
                        )
                        .clickable {
                            if (playlistManager != null && mediaController != null) {
                                playlistManager.setCurrentIndex(index)
                                val items = playlistManager.toMediaItems()
                                mediaController.setMediaItems(items, index, 0L)
                                mediaController.prepare()
                                mediaController.play()
                            }
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Track number / playing indicator
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                        .background(if (isCurrentTrack) accentColor.copy(0.2f) else Color(0xFF1A1A2A)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCurrentTrack) {
                            Icon(Icons.Default.VolumeUp, null, tint = accentColor, modifier = Modifier.size(20.dp))
                        } else {
                            Text("${index + 1}", color = Color(0xFF555566), fontSize = 13.sp,
                                fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, color = if (isCurrentTrack) accentColor else Color.White,
                            fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${track.artist} · ${track.format}", color = Color(0xFF666677),
                            fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { playlistManager?.removeTrack(track.id) }) {
                        Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFF444455))
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = Color(0xFF111118),
            title = { Text("Import Songs", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                if (scannedTracks.isEmpty()) {
                    Text("No audio files were found on this device.", color = Color(0xFF888899))
                } else {
                    Column(Modifier.fillMaxWidth().heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                        scannedTracks.forEach { track ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable { selectedIds[track.id] = !(selectedIds[track.id] ?: false) }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = selectedIds[track.id] ?: false,
                                    onCheckedChange = { selectedIds[track.id] = it },
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFFFFC94D))
                                )
                                Spacer(Modifier.width(4.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(track.title, color = Color.White, fontSize = 13.sp,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${track.artist} · ${track.format}", color = Color(0xFF666677),
                                        fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val chosen = scannedTracks.filter { selectedIds[it.id] == true }
                    playlistManager?.addTracks(chosen)
                    showImportDialog = false
                }) { Text("Add Selected", color = Color(0xFFFFC94D), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Cancel", color = Color(0xFF888899))
                }
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// REUSABLE COMPOSABLES
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun AudioBadge(text: String, color: Color, isActive: Boolean) {
    Surface(shape = RoundedCornerShape(20.dp),
        color = if (isActive) color.copy(0.15f) else Color(0xFF1A1A2A),
        border = if (isActive) BorderStroke(1.dp, color.copy(0.6f)) else null
    ) {
        Text(text, Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            color = if (isActive) color else Color(0xFF555566),
            fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
    }
}

@Composable
fun CapRow(label: String, supported: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = Color(0xFFCCCCDD))
        Text(if (supported) "✓ YES" else "✗ NO", fontSize = 12.sp,
            color = if (supported) Color(0xFF00E676) else Color(0xFF555566),
            fontWeight = FontWeight.Bold)
    }
}

private fun mimeLabel(mime: String) = when (mime) {
    "audio/eac3-joc" -> "DOLBY ATMOS"
    "audio/eac3" -> "DOLBY D+"
    "audio/ac3" -> "DOLBY D"
    "audio/mp4a-latm" -> "AAC"
    else -> "PCM"
}

private fun formatTime(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val s = ms / 1000
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}
