package com.yourcompany.premiumsounds.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.Spatializer
import android.os.Build
import androidx.annotation.RequiresApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SpatialAudioController(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _spatialState = MutableStateFlow(SpatialState())
    val spatialState: StateFlow<SpatialState> = _spatialState

    data class SpatialState(
        val isEnabled: Boolean = false,
        val isHeadTrackingActive: Boolean = false,
        val channelCount: Int = 2,
        val immersiveLevel: String = "None",
        val isAtmosActive: Boolean = false,
        val currentFormat: String = "PCM Stereo"
    )

    fun refreshSpatialState(channelCount: Int = 2, mimeType: String = "audio/raw") {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val spatializer = audioManager.spatializer
            val isEnabled = spatializer.isEnabled && spatializer.isAvailable
            val hasHeadTracking = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                spatializer.isHeadTrackerAvailable
            } else false

            val immersiveLevel = when (spatializer.immersiveAudioLevel) {
                Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_MULTICHANNEL -> "Multichannel"
                Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_NONE -> "None"
                else -> "Standard"
            }

            _spatialState.value = SpatialState(
                isEnabled = isEnabled,
                isHeadTrackingActive = isEnabled && hasHeadTracking,
                channelCount = channelCount,
                immersiveLevel = immersiveLevel,
                isAtmosActive = mimeType == "audio/eac3-joc",
                currentFormat = formatLabel(mimeType, channelCount)
            )
        } else {
            _spatialState.value = SpatialState(
                channelCount = channelCount,
                currentFormat = formatLabel(mimeType, channelCount)
            )
        }
    }

    fun canSpatialize(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        return try {
            val spatializer = audioManager.spatializer
            spatializer.canBeSpatialized(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(48000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_5POINT1)
                    .build()
            )
        } catch (e: Exception) { false }
    }

    @RequiresApi(Build.VERSION_CODES.S)
    fun enableHeadTracking(enable: Boolean) {
        // Head tracking is managed by system; this can trigger UI update
        refreshSpatialState(
            channelCount = _spatialState.value.channelCount,
            mimeType = if (_spatialState.value.isAtmosActive) "audio/eac3-joc" else "audio/raw"
        )
    }

    private fun formatLabel(mimeType: String, channelCount: Int): String {
        return when (mimeType) {
            "audio/eac3-joc" -> "Dolby Atmos"
            "audio/eac3"     -> "Dolby Digital Plus (${channelCount}ch)"
            "audio/ac3"      -> "Dolby Digital (${channelCount}ch)"
            "audio/mp4a-latm" -> "AAC (${channelCount}ch)"
            else             -> if (channelCount > 2) "PCM ${channelCount}ch" else "PCM Stereo"
        }
    }
}
