package com.yourcompany.premiumsounds.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF00D4FF),
    secondary = Color(0xFF7C4DFF),
    tertiary = Color(0xFF00E676),
    background = Color(0xFF060608),
    surface = Color(0xFF111118),
    onBackground = Color.White,
    onSurface = Color.White,
    onPrimary = Color.Black
)

@Composable
fun PremiumSoundsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
