package com.yourcompany.premiumsounds.audio

import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

@OptIn(UnstableApi::class)
class PremiumAudioService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private lateinit var capabilityDetector: AudioCapabilityDetector
    private lateinit var spatialAudioController: SpatialAudioController

    val dspEngine = PremiumDSPEngine()
    val equalizerController = EqualizerController()
    val visualizerController = VisualizerController()
    val playlistManager = PlaylistManager()

    companion object {
        const val ACTION_AUDIO_QUALITY = "com.yourcompany.premiumsounds.AUDIO_QUALITY_CHANGED"
        const val HIRES_SAMPLE_RATE_THRESHOLD = 48000
        var instance: PremiumAudioService? = null
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        capabilityDetector = AudioCapabilityDetector(this)
        spatialAudioController = SpatialAudioController(this)
        initializePlayer()
    }

    private fun initializePlayer() {
        val trackSelector = DefaultTrackSelector(this).apply {
            val params = buildUponParameters()
            params.setMaxAudioChannelCount(8)
            setParameters(params.build())
        }

        player = ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(), true
            )
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val format = player.currentTracks.groups
                    .flatMap { g -> (0 until g.length).map { g.getTrackFormat(it) } }
                    .firstOrNull { it.sampleMimeType?.startsWith("audio") == true }
                val mimeType = format?.sampleMimeType ?: "audio/raw"
                val ch = format?.channelCount ?: 2
                val sampleRate = format?.sampleRate ?: 0
                val isHiRes = sampleRate >= HIRES_SAMPLE_RATE_THRESHOLD

                spatialAudioController.refreshSpatialState(ch, mimeType)
                broadcastAudioQuality(
                    isAtmos = mimeType == "audio/eac3-joc",
                    isSurround = ch > 2,
                    channelCount = ch,
                    mimeType = mimeType,
                    sampleRate = sampleRate,
                    isHiRes = isHiRes
                )

                val sessionId = player.audioSessionId
                if (sessionId != 0) {
                    dspEngine.attach(sessionId)
                    equalizerController.attach(sessionId)
                    visualizerController.attach(sessionId)
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                playlistManager.setCurrentIndex(player.currentMediaItemIndex)
            }
        })

        mediaSession = MediaSession.Builder(this, player)
            .setCallback(object : MediaSession.Callback {
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: androidx.media3.session.MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>
                ): ListenableFuture<MutableList<MediaItem>> {
                    val resolved = mediaItems.map {
                        it.buildUpon().setUri(it.requestMetadata.mediaUri).build()
                    }.toMutableList()
                    return Futures.immediateFuture(resolved)
                }
            })
            .build()
    }

    private fun broadcastAudioQuality(
        isAtmos: Boolean, isSurround: Boolean, channelCount: Int,
        mimeType: String, sampleRate: Int, isHiRes: Boolean
    ) {
        sendBroadcast(Intent(ACTION_AUDIO_QUALITY).apply {
            putExtra("is_atmos", isAtmos)
            putExtra("is_surround", isSurround)
            putExtra("channel_count", channelCount)
            putExtra("mime_type", mimeType)
            putExtra("sample_rate", sampleRate)
            putExtra("is_hires", isHiRes)
        })
    }

    override fun onGetSession(controllerInfo: androidx.media3.session.MediaSession.ControllerInfo) = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.playWhenReady) stopSelf()
    }

    override fun onDestroy() {
        instance = null
        dspEngine.release()
        equalizerController.release()
        visualizerController.release()
        mediaSession?.run { player.release(); release(); mediaSession = null }
        super.onDestroy()
    }
}
