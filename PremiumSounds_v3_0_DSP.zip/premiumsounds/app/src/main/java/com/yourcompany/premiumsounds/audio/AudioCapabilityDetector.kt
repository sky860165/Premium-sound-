package com.yourcompany.premiumsounds.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.MediaCodecList
import android.media.Spatializer
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.media3.common.util.UnstableApi

@UnstableApi
class AudioCapabilityDetector(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun getDolbySupportStatus(): DolbySupportStatus {
        val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
        val supportedFormats = mutableSetOf<DolbyFormat>()

        codecList.codecInfos.forEach { codecInfo ->
            if (!codecInfo.isEncoder) {
                codecInfo.supportedTypes.forEach { mimeType ->
                    when (mimeType) {
                        "audio/ac3"      -> supportedFormats.add(DolbyFormat.DOLBY_DIGITAL)
                        "audio/eac3"     -> supportedFormats.add(DolbyFormat.DOLBY_DIGITAL_PLUS)
                        "audio/eac3-joc" -> supportedFormats.add(DolbyFormat.DOLBY_ATMOS)
                    }
                }
            }
        }

        return DolbySupportStatus(
            isAtmosSupported = supportedFormats.contains(DolbyFormat.DOLBY_ATMOS),
            supportedFormats = supportedFormats.toList(),
            hasDolbyHardware = supportedFormats.isNotEmpty()
        )
    }

    @RequiresApi(Build.VERSION_CODES.S)
    fun getSpatialAudioStatus(): SpatialAudioStatus {
        return try {
            val spatializer = audioManager.spatializer
            SpatialAudioStatus(
                isSupported = spatializer.immersiveAudioLevel != Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_NONE,
                isAvailable = spatializer.isAvailable,
                isEnabled = spatializer.isEnabled,
                canSpatialize = spatializer.canBeSpatialized(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(48000)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_5POINT1)
                        .build()
                ),
                hasHeadTracking = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    spatializer.isHeadTrackerAvailable
                } else false,
                immersiveLevel = when (spatializer.immersiveAudioLevel) {
                    Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_MULTICHANNEL -> "Multichannel"
                    Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_NONE         -> "None"
                    else                                                  -> "Standard"
                }
            )
        } catch (e: Exception) {
            SpatialAudioStatus(false, false, false, false, false, "None")
        }
    }

    fun getPreferredAudioMimeTypes(): List<String> {
        val status = getDolbySupportStatus()
        return buildList {
            if (status.isAtmosSupported) add("audio/eac3-joc")
            if (status.supportedFormats.contains(DolbyFormat.DOLBY_DIGITAL_PLUS)) add("audio/eac3")
            if (status.supportedFormats.contains(DolbyFormat.DOLBY_DIGITAL)) add("audio/ac3")
            add("audio/mp4a-latm")
            add("audio/raw")
        }
    }

    data class DolbySupportStatus(
        val isAtmosSupported: Boolean,
        val supportedFormats: List<DolbyFormat>,
        val hasDolbyHardware: Boolean
    )

    data class SpatialAudioStatus(
        val isSupported: Boolean,
        val isAvailable: Boolean,
        val isEnabled: Boolean,
        val canSpatialize: Boolean,
        val hasHeadTracking: Boolean,
        val immersiveLevel: String
    )

    enum class DolbyFormat { DOLBY_DIGITAL, DOLBY_DIGITAL_PLUS, DOLBY_ATMOS }
}
