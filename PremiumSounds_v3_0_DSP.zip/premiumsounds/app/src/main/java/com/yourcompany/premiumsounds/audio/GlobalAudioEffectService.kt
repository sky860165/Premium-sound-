package com.yourcompany.premiumsounds.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.yourcompany.premiumsounds.MainActivity
import com.yourcompany.premiumsounds.R

/**
 * GlobalAudioEffectService
 *
 * Runs as a persistent ForegroundService and attaches Android AudioEffect APIs
 * to audioSessionId = 0 (global output mix). This lets EQ / Bass / Virtualizer
 * work across ALL apps — YouTube, Spotify, local players, calls — as long as
 * the audio is routed through the device's AudioFlinger mixer.
 *
 * Note: Spotify and YouTube "duck" or isolate their sessions on some OEMs
 * (Samsung, Xiaomi MIUI). On those devices effects may not apply to those
 * specific apps, but will still apply to all other media.
 */
class GlobalAudioEffectService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): GlobalAudioEffectService = this@GlobalAudioEffectService
    }

    private val binder = LocalBinder()

    // AudioEffect instances bound to session 0 (global mix)
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    // Mirror of EqualizerController.EqState — kept in sync
    var currentPreset: String = "Flat"
    var bassStrength: Int = 0
    var virtualizerStrength: Int = 0
    var premiumBoostMb: Int = 0
    var isEffectEnabled: Boolean = true

    companion object {
        const val CHANNEL_ID = "global_eq_channel"
        const val NOTIF_ID = 9001
        const val GLOBAL_SESSION = 0

        // Intent actions for controlling from outside (Tile / broadcast)
        const val ACTION_TOGGLE = "com.yourcompany.premiumsounds.GLOBAL_EQ_TOGGLE"
        const val ACTION_PRESET = "com.yourcompany.premiumsounds.GLOBAL_EQ_PRESET"
        const val EXTRA_PRESET = "preset_name"
        const val EXTRA_BAND_INDEX = "band_index"
        const val EXTRA_BAND_LEVEL = "band_level"
        const val ACTION_SET_BAND = "com.yourcompany.premiumsounds.GLOBAL_EQ_SET_BAND"
        const val ACTION_SET_BASS = "com.yourcompany.premiumsounds.GLOBAL_EQ_SET_BASS"
        const val EXTRA_BASS_STRENGTH = "bass_strength"
        const val ACTION_SET_VIRT = "com.yourcompany.premiumsounds.GLOBAL_EQ_SET_VIRT"
        const val EXTRA_VIRT_STRENGTH = "virt_strength"
        const val ACTION_SET_BOOST = "com.yourcompany.premiumsounds.GLOBAL_EQ_SET_BOOST"
        const val EXTRA_BOOST_MB = "boost_mb"

        // Shared instance so UI can reach it without binding
        var instance: GlobalAudioEffectService? = null
            private set
    }

    // ─── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        initEffects()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> setEnabled(!isEffectEnabled)
            ACTION_PRESET -> intent.getStringExtra(EXTRA_PRESET)?.let { applyPreset(it) }
            ACTION_SET_BAND -> {
                val idx = intent.getIntExtra(EXTRA_BAND_INDEX, -1)
                val lvl = intent.getIntExtra(EXTRA_BAND_LEVEL, 0)
                if (idx >= 0) setBandLevel(idx, lvl)
            }
            ACTION_SET_BASS -> setBassStrength(intent.getIntExtra(EXTRA_BASS_STRENGTH, 0))
            ACTION_SET_VIRT -> setVirtualizerStrength(intent.getIntExtra(EXTRA_VIRT_STRENGTH, 0))
            ACTION_SET_BOOST -> setPremiumBoost(intent.getIntExtra(EXTRA_BOOST_MB, 0))
        }
        updateNotification()
        return START_STICKY   // restart if killed
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        instance = null
        releaseEffects()
        super.onDestroy()
    }

    // ─── Effect init ───────────────────────────────────────────────────────────

    private fun initEffects() {
        releaseEffects()
        try {
            equalizer = Equalizer(0, GLOBAL_SESSION).apply { enabled = true }
            bassBoost = BassBoost(0, GLOBAL_SESSION).apply {
                enabled = true
                if (bassStrength > 0) setStrength(bassStrength.toShort())
            }
            virtualizer = Virtualizer(0, GLOBAL_SESSION).apply {
                enabled = true
                if (virtualizerStrength > 0) setStrength(virtualizerStrength.toShort())
            }
            loudnessEnhancer = LoudnessEnhancer(GLOBAL_SESSION).apply {
                setTargetGain(premiumBoostMb)
                enabled = premiumBoostMb > 0
            }
            applyPreset(currentPreset)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun releaseEffects() {
        listOf(equalizer, bassBoost, virtualizer, loudnessEnhancer).forEach {
            try { it?.release() } catch (_: Exception) {}
        }
        equalizer = null; bassBoost = null; virtualizer = null; loudnessEnhancer = null
    }

    // ─── Public control API (same surface as EqualizerController) ──────────────

    fun setEnabled(enabled: Boolean) {
        isEffectEnabled = enabled
        equalizer?.enabled = enabled
        bassBoost?.enabled = enabled
        virtualizer?.enabled = enabled
        loudnessEnhancer?.enabled = enabled && premiumBoostMb > 0
        updateNotification()
    }

    fun applyPreset(presetName: String) {
        val levels = com.yourcompany.premiumsounds.audio.PRESETS[presetName] ?: return
        val eq = equalizer ?: return
        currentPreset = presetName
        val bandCount = eq.numberOfBands.toInt()
        levels.take(bandCount).forEachIndexed { i, level ->
            try { eq.setBandLevel(i.toShort(), level.toShort()) } catch (_: Exception) {}
        }
    }

    fun setBandLevel(bandIndex: Int, levelMb: Int) {
        try {
            equalizer?.setBandLevel(bandIndex.toShort(), levelMb.toShort())
            currentPreset = "Custom"
        } catch (_: Exception) {}
    }

    fun setBassStrength(strength: Int) {
        bassStrength = strength
        try { bassBoost?.setStrength(strength.toShort()) } catch (_: Exception) {}
    }

    fun setVirtualizerStrength(strength: Int) {
        virtualizerStrength = strength
        try { virtualizer?.setStrength(strength.toShort()) } catch (_: Exception) {}
    }

    fun setPremiumBoost(gainMb: Int) {
        premiumBoostMb = gainMb
        try {
            loudnessEnhancer?.setTargetGain(gainMb)
            loudnessEnhancer?.enabled = gainMb > 0
        } catch (_: Exception) {}
    }

    fun getBandInfo(): List<Triple<Int, Int, Int>>? {   // (centerHz, levelMb, index)
        val eq = equalizer ?: return null
        val range = eq.bandLevelRange
        return (0 until eq.numberOfBands.toInt()).map { i ->
            Triple(eq.getCenterFreq(i.toShort()) / 1000, eq.getBandLevel(i.toShort()).toInt(), i)
        }
    }

    // ─── Notification ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Global Equalizer",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps sound effects active for all apps"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val toggleIntent = PendingIntent.getService(
            this, 1,
            Intent(this, GlobalAudioEffectService::class.java).apply { action = ACTION_TOGGLE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggleLabel = if (isEffectEnabled) "Turn Off" else "Turn On"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("PremiumSounds EQ — Active")
            .setContentText("Preset: $currentPreset • ${if (isEffectEnabled) "ON" else "OFF"}")
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_media_pause, toggleLabel, toggleIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification())
    }

    // ─── Presets ───────────────────────────────────────────────────────────────

}

val PRESETS = mapOf(
    "Flat"       to listOf(0, 0, 0, 0, 0),
    "Bass Boost" to listOf(800, 400, 0, 0, 0),
    "Treble"     to listOf(0, 0, 0, 400, 800),
    "Vocal"      to listOf(-200, 0, 600, 400, 0),
    "Rock"       to listOf(500, 300, -100, 300, 500),
    "Pop"        to listOf(-100, 300, 500, 300, -100),
    "Classical"  to listOf(300, 200, -200, 200, 300),
    "Custom"     to listOf(0, 0, 0, 0, 0)
)
