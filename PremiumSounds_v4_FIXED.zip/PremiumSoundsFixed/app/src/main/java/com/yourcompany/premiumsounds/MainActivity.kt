package com.yourcompany.premiumsounds

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.yourcompany.premiumsounds.audio.AudioCapabilityDetector
import com.yourcompany.premiumsounds.audio.DeviceMusicScanner
import com.yourcompany.premiumsounds.audio.PremiumAudioService
import com.yourcompany.premiumsounds.audio.PremiumDSPEngine
import com.yourcompany.premiumsounds.audio.Track
import com.yourcompany.premiumsounds.ui.theme.PremiumSoundsTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.*

@UnstableApi
class MainActivity : ComponentActivity() {

    private var mediaController: MediaController? = null

    private val notifPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    private val recordPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) recordPermission.launch(Manifest.permission.RECORD_AUDIO)

        setContent {
            PremiumSoundsTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen(mediaController)
                }
            }
        }

        val sessionToken = SessionToken(this, ComponentName(this, PremiumAudioService::class.java))
        val future = MediaController.Builder(this, sessionToken).buildAsync()
        future.addListener({
            try {
                mediaController = future.get()
                setContent {
                    PremiumSoundsTheme {
                        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                            MainScreen(mediaController)
                        }
                    }
                }
            } catch (_: Exception) {}
        }, MoreExecutors.directExecutor())
    }

    override fun onDestroy() {
        mediaController?.release()
        super.onDestroy()
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN SCREEN
// ─────────────────────────────────────────────────────────────────────────────
@UnstableApi
@Composable
fun MainScreen(mediaController: MediaController?) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Player", "Equalizer", "Playlist")
    val icons = listOf(Icons.Default.Headphones, Icons.Default.GraphicEq, Icons.Default.QueueMusic)

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D0D14), tonalElevation = 0.dp) {
                tabs.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = selectedTab == i,
                        onClick = { selectedTab = i },
                        icon = { Icon(icons[i], contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00D4FF), selectedTextColor = Color(0xFF00D4FF),
                            unselectedIconColor = Color(0xFF555566), unselectedTextColor = Color(0xFF555566),
                            indicatorColor = Color(0xFF00D4FF).copy(alpha = 0.12f)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF060608)
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            AnimatedContent(targetState = selectedTab, label = "tab_anim",
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(200)) }
            ) { tab ->
                when (tab) {
                    0 -> PlayerTab(mediaController)
                    1 -> EqualizerTab()
                    2 -> PlaylistTab(mediaController)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PLAYER TAB
// ─────────────────────────────────────────────────────────────────────────────
@UnstableApi
@Composable
fun PlayerTab(mediaController: MediaController?) {
    val context = LocalContext.current
    val capabilityDetector = remember { AudioCapabilityDetector(context) }
    val dolbyStatus = remember { capabilityDetector.getDolbySupportStatus() }

    var isPlaying by remember { mutableStateOf(false) }
    var isAtmosActive by remember { mutableStateOf(false) }
    var currentMime by remember { mutableStateOf("audio/raw") }
    var channelCount by remember { mutableIntStateOf(2) }
    var sampleRate by remember { mutableIntStateOf(0) }
    var isHiRes by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(1f) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var currentTrackTitle by remember { mutableStateOf("No Track") }
    var currentTrackArtist by remember { mutableStateOf("Select from Playlist") }

    val service = PremiumAudioService.instance
    val waveform by (service?.visualizerController?.waveform ?: MutableStateFlow(ByteArray(128))).collectAsState()
    val vizActive by (service?.visualizerController?.isActive ?: MutableStateFlow(false)).collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(900, easing = EaseInOut), RepeatMode.Reverse),
        label = "glow_alpha"
    )
    val accentColor by animateColorAsState(
        if (isAtmosActive) Color(0xFF00D4FF) else Color(0xFF7C4DFF), tween(600), label = "accent"
    )

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                intent?.let {
                    isAtmosActive = it.getBooleanExtra("is_atmos", false)
                    currentMime = it.getStringExtra("mime_type") ?: "audio/raw"
                    channelCount = it.getIntExtra("channel_count", 2)
                    sampleRate = it.getIntExtra("sample_rate", 0)
                    isHiRes = it.getBooleanExtra("is_hires", false)
                }
            }
        }
        val filter = IntentFilter(PremiumAudioService.ACTION_AUDIO_QUALITY)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else context.registerReceiver(receiver, filter)
        onDispose { context.unregisterReceiver(receiver) }
    }

    LaunchedEffect(mediaController) {
        while (true) {
            mediaController?.let {
                isPlaying = it.isPlaying
                position = it.currentPosition
                duration = it.duration.takeIf { d -> d > 0 } ?: 0L
                currentTrackTitle = it.mediaMetadata.title?.toString() ?: "No Track"
                currentTrackArtist = it.mediaMetadata.artist?.toString() ?: ""
            }
            delay(300)
        }
    }

    LaunchedEffect(volume) { mediaController?.volume = volume }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060608))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("PREMIUM SOUND", style = TextStyle(
                brush = Brush.linearGradient(listOf(Color(0xFF00D4FF), Color(0xFF7C4DFF), Color(0xFFFFC94D))),
                fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp
            ))
            Spacer(Modifier.width(8.dp))
            Surface(shape = RoundedCornerShape(6.dp),
                color = Color(0xFFFFC94D).copy(0.15f),
                border = BorderStroke(1.dp, Color(0xFFFFC94D).copy(0.6f))
            ) {
                Text("PRO", Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    color = Color(0xFFFFC94D), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Text("Immersive Audio Engine", fontSize = 11.sp, color = Color(0xFF555566), letterSpacing = 1.sp)

        Spacer(Modifier.height(24.dp))

        // Visualizer orb
        Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(240.dp)) {
                val cx = size.width / 2
                val cy = size.height / 2
                val baseR = size.width * 0.42f
                drawCircle(accentColor.copy(alpha = glowAlpha * 0.12f), baseR + 30f, Offset(cx, cy))
                if (isPlaying) {
                    drawCircle(accentColor.copy(alpha = glowAlpha * 0.08f), baseR + 50f, Offset(cx, cy))
                }
                if (vizActive && waveform.isNotEmpty()) {
                    val count = waveform.size.coerceAtMost(64)
                    val path = Path()
                    for (i in 0 until count) {
                        val angle = (i.toFloat() / count) * 2f * PI.toFloat()
                        val amp = (waveform[i].toInt() and 0xFF) / 255f
                        val r = baseR + amp * 40f
                        val x = cx + r * cos(angle)
                        val y = cy + r * sin(angle)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    path.close()
                    drawPath(path, accentColor.copy(alpha = 0.6f))
                }
            }
            Box(Modifier.size(200.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF1A1A2E), Color(0xFF0D0D14)))),
                contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Headphones, null, Modifier.size(64.dp), tint = accentColor)
                    Spacer(Modifier.height(6.dp))
                    Text(mimeLabel(currentMime), fontSize = 10.sp, color = accentColor.copy(0.8f),
                        fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        Text(currentTrackTitle, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(currentTrackArtist, fontSize = 13.sp, color = Color(0xFF888899))

        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (dolbyStatus.isAtmosSupported) AudioBadge("ATMOS", accentColor, isAtmosActive)
            if (dolbyStatus.hasDolbyHardware) AudioBadge("DOLBY", Color(0xFF7C4DFF), true)
            if (isHiRes) AudioBadge("HI-RES", Color(0xFFFFC94D), true)
            AudioBadge("${channelCount}CH", Color(0xFF00E676), channelCount > 2)
        }

        Spacer(Modifier.height(24.dp))

        Slider(
            value = if (duration > 0) position.toFloat() / duration else 0f,
            onValueChange = { mediaController?.seekTo((it * duration).toLong()) },
            modifier = Modifier.fillMaxWidth(),
            colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor,
                inactiveTrackColor = Color(0xFF2A2A3A))
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), fontSize = 11.sp, color = Color(0xFF666677))
            Text(formatTime(duration), fontSize = 11.sp, color = Color(0xFF666677))
        }

        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { mediaController?.seekToPreviousMediaItem() }) {
                Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = { mediaController?.seekBack() }) {
                Icon(Icons.Default.Replay10, null, tint = Color(0xFFAAAAAA), modifier = Modifier.size(28.dp))
            }
            // FIX: Play button now properly loads playlist and plays
            Box(Modifier.size(68.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(accentColor, accentColor.copy(0.7f)))),
                contentAlignment = Alignment.Center) {
                IconButton(onClick = {
                    if (isPlaying) {
                        mediaController?.pause()
                    } else {
                        val svc = PremiumAudioService.instance
                        if (svc != null && mediaController != null) {
                            val items = svc.playlistManager.toMediaItems()
                            if (items.isNotEmpty()) {
                                val idx = svc.playlistManager.currentIndex.value
                                if (mediaController.mediaItemCount == 0) {
                                    // No items loaded yet — load all
                                    mediaController.setMediaItems(items, idx, 0L)
                                    mediaController.prepare()
                                }
                                mediaController.play()
                            }
                        } else {
                            mediaController?.play()
                        }
                    }
                }) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        null, tint = Color.Black, modifier = Modifier.size(36.dp))
                }
            }
            IconButton(onClick = { mediaController?.seekForward() }) {
                Icon(Icons.Default.Forward10, null, tint = Color(0xFFAAAAAA), modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = { mediaController?.seekToNextMediaItem() }) {
                Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.VolumeDown, null, tint = Color(0xFF555566), modifier = Modifier.size(18.dp))
            Slider(value = volume, onValueChange = { volume = it },
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor,
                    inactiveTrackColor = Color(0xFF2A2A3A))
            )
            Icon(Icons.Default.VolumeUp, null, tint = Color(0xFF555566), modifier = Modifier.size(18.dp))
        }

        Spacer(Modifier.height(16.dp))

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF111118)).padding(16.dp)) {
            Text("DEVICE CAPABILITIES", fontSize = 10.sp, color = Color(0xFF666677),
                letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            CapRow("Dolby Atmos", dolbyStatus.isAtmosSupported)
            CapRow("Dolby Hardware", dolbyStatus.hasDolbyHardware)
            CapRow("Surround Sound", dolbyStatus.supportedFormats.isNotEmpty())
            CapRow("Spatial Visualizer", vizActive)
            if (sampleRate > 0) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Sample Rate", fontSize = 13.sp, color = Color(0xFFCCCCDD))
                    Text("${sampleRate / 1000.0} kHz", fontSize = 12.sp,
                        color = if (isHiRes) Color(0xFFFFC94D) else Color(0xFF888899), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// EQUALIZER TAB — Full DSP Control
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun EqualizerTab() {
    val context = LocalContext.current
    val service = PremiumAudioService.instance
    val dspEngine = service?.dspEngine
    val dspState by (dspEngine?.dspState ?: MutableStateFlow(PremiumDSPEngine.DSPState())).collectAsState()

    var isGlobalMode by remember { mutableStateOf(true) }
    val globalService = com.yourcompany.premiumsounds.audio.GlobalAudioEffectService.instance
    val allModes = PremiumDSPEngine.SoundMode.values().toList()

    // Custom preset save dialog
    var showSaveDialog by remember { mutableStateOf(false) }
    var presetNameInput by remember { mutableStateOf("") }
    var showCustomPresets by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF060608)).verticalScroll(rememberScrollState())) {

        // Header
        Column(Modifier.padding(horizontal = 20.dp, vertical = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("DSP ENGINE", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                    color = Color.White, letterSpacing = 3.sp)
                Spacer(Modifier.width(8.dp))
                Surface(shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFFF6B6B).copy(0.15f),
                    border = BorderStroke(1.dp, Color(0xFFFF6B6B).copy(0.6f))) {
                    Text("ULTRA", Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        color = Color(0xFFFF6B6B), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            Text(
                if (dspState.isHardwareAttached) "🟢 DSP Active — Hardware Attached"
                else if (isGlobalMode) "🌐 Global Mode — Play any track to activate"
                else "▶ Play a track to activate DSP",
                fontSize = 11.sp,
                color = if (dspState.isHardwareAttached) Color(0xFF00E676) else Color(0xFF888855)
            )
        }

        // Global Mode Toggle
        Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(14.dp),
            color = if (isGlobalMode) Color(0xFF0D2218) else Color(0xFF111118),
            border = BorderStroke(1.dp, if (isGlobalMode) Color(0xFF00E676).copy(0.5f) else Color(0xFF2A2A3A))
        ) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, null,
                            tint = if (isGlobalMode) Color(0xFF00E676) else Color(0xFF555566),
                            modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("GLOBAL MODE", color = if (isGlobalMode) Color(0xFF00E676) else Color(0xFF888899),
                            fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Text("YouTube · Spotify · Chrome · all apps",
                        fontSize = 10.sp, color = Color(0xFF555566), modifier = Modifier.padding(top = 2.dp, start = 22.dp))
                }
                Switch(checked = isGlobalMode, onCheckedChange = { isGlobalMode = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = Color(0xFF00E676)))
            }
        }

        Spacer(Modifier.height(20.dp))

        // Sound Mode Cards
        Text("SOUND MODES", fontSize = 10.sp, color = Color(0xFF555566),
            letterSpacing = 1.5.sp, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(10.dp))

        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(allModes.size) { i ->
                val mode = allModes[i]
                val isSelected = dspState.currentMode == mode
                val modeColor = Color(mode.accentHex)
                Surface(onClick = {
                    dspEngine?.applyMode(mode)
                    if (isGlobalMode) {
                        globalService?.applyPreset(when (mode) {
                            PremiumDSPEngine.SoundMode.BASS_MONSTER, PremiumDSPEngine.SoundMode.HIP_HOP -> "Bass Boost"
                            PremiumDSPEngine.SoundMode.CLASSICAL -> "Classical"
                            PremiumDSPEngine.SoundMode.VOCAL_BOOST, PremiumDSPEngine.SoundMode.PODCAST -> "Vocal"
                            PremiumDSPEngine.SoundMode.ROCK -> "Rock"
                            PremiumDSPEngine.SoundMode.FLAT -> "Flat"
                            else -> "Custom"
                        })
                        globalService?.setBassStrength(mode.bassStrength)
                        globalService?.setVirtualizerStrength(mode.virtStrength)
                        globalService?.setPremiumBoost(mode.loudnessMb)
                    }
                },
                    shape = RoundedCornerShape(18.dp),
                    color = if (isSelected) modeColor.copy(0.18f) else Color(0xFF0F0F18),
                    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp,
                        if (isSelected) modeColor else Color(0xFF222233)),
                    modifier = Modifier.width(110.dp)
                ) {
                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(mode.emoji, fontSize = 24.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(mode.label, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            color = if (isSelected) modeColor else Color(0xFF888899),
                            maxLines = 1, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(4.dp))
                        Text(mode.description, fontSize = 9.sp, color = Color(0xFF444455),
                            maxLines = 2, lineHeight = 12.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // Active mode strip
        val activeMode = dspState.currentMode
        Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(14.dp),
            color = Color(activeMode.accentHex).copy(0.08f),
            border = BorderStroke(1.dp, Color(activeMode.accentHex).copy(0.3f))
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(activeMode.emoji, fontSize = 28.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(activeMode.label, color = Color(activeMode.accentHex),
                        fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text(activeMode.description, color = Color(0xFF666677), fontSize = 11.sp)
                }
                Switch(checked = dspState.isEnabled,
                    onCheckedChange = { dspEngine?.setEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black, checkedTrackColor = Color(activeMode.accentHex)))
            }
        }

        Spacer(Modifier.height(20.dp))

        // DSP Chain status
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {
            Text("DSP CHAIN", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))
            DSPMeter("EQ Bands", "${dspState.bands.size}-band active", dspState.bands.isNotEmpty(), Color(0xFF00D4FF))
            DSPMeter("Bass Engine", "${dspState.bassStrength / 10}% power", dspState.bassStrength > 0, Color(0xFF7C4DFF))
            DSPMeter("3D Spatial", "${dspState.virtualizerStrength / 10}% width", dspState.virtualizerStrength > 0, Color(0xFF00E676))
            DSPMeter("Loudness", "+${dspState.loudnessBoostMb / 100} dB gain", dspState.loudnessBoostMb > 0, Color(0xFFFFC94D))
            DSPMeter("Reverb/Space", reverbLabel(dspState.reverbPreset), dspState.reverbPreset != 0, Color(0xFFE040FB))
        }

        Spacer(Modifier.height(16.dp))

        // Quick toggles
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {
            Text("QUICK ENHANCE", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickToggle(Modifier.weight(1f), "🌙", "Night Mode",
                    dspState.nightMode, Color(0xFF4A90D9)) { dspEngine?.setNightMode(!dspState.nightMode) }
                QuickToggle(Modifier.weight(1f), "🎤", "Dialogue",
                    dspState.dialogueEnhance, Color(0xFFFF9800)) { dspEngine?.setDialogueEnhance(!dspState.dialogueEnhance) }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Fine Tune — EQ Sliders (shows when hardware attached)
        if (dspState.bands.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("FINE TUNE EQ", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
                    // Save custom preset button
                    TextButton(onClick = { showSaveDialog = true }) {
                        Icon(Icons.Default.Save, null, tint = Color(0xFFFFC94D), modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Save", color = Color(0xFFFFC94D), fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))

                // EQ bar visualizer
                Row(Modifier.fillMaxWidth().height(60.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color(0xFF080810)).padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    dspState.bands.forEach { band ->
                        val norm = (band.levelMb - band.minLevelMb).toFloat() /
                                (band.maxLevelMb - band.minLevelMb).coerceAtLeast(1).toFloat()
                        val h = (norm * 48f).dp
                        Box(Modifier.width(24.dp), contentAlignment = Alignment.BottomCenter) {
                            Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.BottomCenter) {
                                Box(Modifier.fillMaxWidth(0.7f).height(h.coerceAtLeast(2.dp))
                                    .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                    .background(Brush.verticalGradient(
                                        listOf(Color(activeMode.accentHex), Color(activeMode.accentHex).copy(0.3f)))))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))

                // EQ band sliders
                dspState.bands.forEach { band ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${band.centerFreqHz}Hz", fontSize = 11.sp, color = Color(0xFF666677))
                        Text("${band.levelMb / 100}dB", fontSize = 11.sp,
                            color = Color(activeMode.accentHex), fontWeight = FontWeight.Bold)
                    }
                    Slider(value = band.levelMb.toFloat(),
                        onValueChange = { dspEngine?.setBandLevel(band.index, it.toInt()) },
                        valueRange = band.minLevelMb.toFloat()..band.maxLevelMb.toFloat(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(thumbColor = Color(activeMode.accentHex),
                            activeTrackColor = Color(activeMode.accentHex), inactiveTrackColor = Color(0xFF222233)))
                }

                // Bass slider
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("BASS ENGINE", fontSize = 11.sp, color = Color(0xFF666677))
                    Text("${dspState.bassStrength / 10}%", fontSize = 11.sp, color = Color(0xFF7C4DFF), fontWeight = FontWeight.Bold)
                }
                Slider(value = dspState.bassStrength.toFloat(),
                    onValueChange = { dspEngine?.setBassStrength(it.toInt()) },
                    valueRange = 0f..1000f, modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF7C4DFF),
                        activeTrackColor = Color(0xFF7C4DFF), inactiveTrackColor = Color(0xFF222233)))

                // Virtualizer slider
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("3D SPATIAL", fontSize = 11.sp, color = Color(0xFF666677))
                    Text("${dspState.virtualizerStrength / 10}%", fontSize = 11.sp, color = Color(0xFF00E676), fontWeight = FontWeight.Bold)
                }
                Slider(value = dspState.virtualizerStrength.toFloat(),
                    onValueChange = { dspEngine?.setVirtualizerStrength(it.toInt()) },
                    valueRange = 0f..1000f, modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676),
                        activeTrackColor = Color(0xFF00E676), inactiveTrackColor = Color(0xFF222233)))

                // Loudness slider
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("LOUDNESS BOOST", fontSize = 11.sp, color = Color(0xFF666677))
                    Text("+${dspState.loudnessBoostMb / 100}dB", fontSize = 11.sp, color = Color(0xFFFFC94D), fontWeight = FontWeight.Bold)
                }
                Slider(value = dspState.loudnessBoostMb.toFloat(),
                    onValueChange = { dspEngine?.setLoudnessBoost(it.toInt()) },
                    valueRange = 0f..2000f, modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFFFFC94D),
                        activeTrackColor = Color(0xFFFFC94D), inactiveTrackColor = Color(0xFF222233)))

                // Reverb slider (NEW)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("REVERB/SPACE", fontSize = 11.sp, color = Color(0xFF666677))
                    Text(reverbLabel(dspState.reverbPreset), fontSize = 11.sp, color = Color(0xFFE040FB), fontWeight = FontWeight.Bold)
                }
                Slider(value = dspState.reverbPreset.toFloat(),
                    onValueChange = { dspEngine?.setReverbPreset(it.toInt()) },
                    valueRange = 0f..6f, steps = 5, modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFFE040FB),
                        activeTrackColor = Color(0xFFE040FB), inactiveTrackColor = Color(0xFF222233)))
            }

            // Custom presets section
            if (dspState.savedCustomPresets.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F0F18)).padding(16.dp)) {
                    Text("MY PRESETS", fontSize = 10.sp, color = Color(0xFF555566), letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(10.dp))
                    dspState.savedCustomPresets.forEach { name ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("🎛️ $name", color = Color(0xFFCCCCDD), fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Row {
                                TextButton(onClick = { dspEngine?.loadCustomPreset(name) }) {
                                    Text("Load", color = Color(0xFF00D4FF), fontSize = 11.sp)
                                }
                                TextButton(onClick = { dspEngine?.deleteCustomPreset(name) }) {
                                    Text("Del", color = Color(0xFFFF5252), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

        } else {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(12.dp)).background(Color(0xFF0F0F18)).padding(20.dp),
                contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.MusicNote, null, tint = Color(0xFF333344), modifier = Modifier.size(32.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (isGlobalMode) "▶ Play any audio to activate Fine-Tune"
                        else "▶ Play a track to activate Fine-Tune",
                        color = Color(0xFF444455), fontSize = 13.sp, textAlign = TextAlign.Center)
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }

    // Save preset dialog
    if (showSaveDialog) {
        AlertDialog(onDismissRequest = { showSaveDialog = false },
            containerColor = Color(0xFF111118),
            title = { Text("Save Custom Preset", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Enter a name for this preset:", color = Color(0xFF888899), fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = presetNameInput, onValueChange = { presetNameInput = it },
                        placeholder = { Text("My Preset", color = Color(0xFF444455)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFFC94D), unfocusedBorderColor = Color(0xFF333344),
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (presetNameInput.isNotBlank()) {
                        dspEngine?.saveCustomPreset(presetNameInput.trim())
                        presetNameInput = ""
                        showSaveDialog = false
                    }
                }) { Text("Save", color = Color(0xFFFFC94D), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false; presetNameInput = "" }) {
                    Text("Cancel", color = Color(0xFF888899))
                }
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PLAYLIST TAB
// ─────────────────────────────────────────────────────────────────────────────
@UnstableApi
@Composable
fun PlaylistTab(mediaController: MediaController?) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val service = PremiumAudioService.instance
    val playlistManager = service?.playlistManager
    val tracks by (playlistManager?.playlist ?: MutableStateFlow(emptyList<Track>())).collectAsState()
    val currentIndex by (playlistManager?.currentIndex ?: MutableStateFlow(0)).collectAsState()
    val accentColor = Color(0xFF00D4FF)

    var isScanning by remember { mutableStateOf(false) }
    var scannedTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    val selectedIds = remember { mutableStateMapOf<String, Boolean>() }
    var showImportDialog by remember { mutableStateOf(false) }

    val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    fun startScan() {
        isScanning = true
        coroutineScope.launch {
            val found = withContext(Dispatchers.IO) { DeviceMusicScanner.scan(context) }
            scannedTracks = found
            selectedIds.clear()
            found.forEach { selectedIds[it.id] = true }
            isScanning = false
            showImportDialog = true
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startScan() }

    fun onImportClicked() {
        val hasPermission = ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) startScan() else permissionLauncher.launch(audioPermission)
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF060608))) {
        Column(Modifier.padding(20.dp)) {
            Text("PLAYLIST", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, letterSpacing = 3.sp)
            Text("${tracks.size} tracks", fontSize = 11.sp, color = Color(0xFF555566))
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    if (playlistManager != null && mediaController != null && tracks.isNotEmpty()) {
                        mediaController.setMediaItems(playlistManager.toMediaItems())
                        mediaController.prepare()
                        mediaController.play()
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.Black)
                Spacer(Modifier.width(4.dp))
                Text("Play All", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { if (mediaController != null) mediaController.shuffleModeEnabled = !mediaController.shuffleModeEnabled },
                modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF333344))
            ) {
                Icon(Icons.Default.Shuffle, null, tint = Color(0xFF888899))
                Spacer(Modifier.width(4.dp))
                Text("Shuffle", color = Color(0xFF888899))
            }
        }

        Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            OutlinedButton(onClick = { onImportClicked() }, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFFFC94D).copy(0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFFC94D))
            ) {
                if (isScanning) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color(0xFFFFC94D))
                    Spacer(Modifier.width(8.dp))
                    Text("Scanning device...")
                } else {
                    Icon(Icons.Default.LibraryMusic, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Import Songs From Device", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        if (tracks.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.QueueMusic, null, tint = Color(0xFF333344), modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Your playlist is empty", color = Color(0xFF888899), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text("Tap \"Import Songs From Device\" to add music", color = Color(0xFF555566), fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(tracks) { index, track ->
                val isCurrentTrack = index == currentIndex
                Row(
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isCurrentTrack) accentColor.copy(0.1f) else Color(0xFF111118))
                        .border(if (isCurrentTrack) BorderStroke(1.dp, accentColor.copy(0.4f))
                            else BorderStroke(0.dp, Color.Transparent), RoundedCornerShape(14.dp))
                        .clickable {
                            if (playlistManager != null && mediaController != null) {
                                playlistManager.setCurrentIndex(index)
                                val items = playlistManager.toMediaItems()
                                mediaController.setMediaItems(items, index, 0L)
                                mediaController.prepare()
                                mediaController.play()
                            }
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                        .background(if (isCurrentTrack) accentColor.copy(0.2f) else Color(0xFF1A1A2A)),
                        contentAlignment = Alignment.Center) {
                        if (isCurrentTrack) {
                            Icon(Icons.Default.VolumeUp, null, tint = accentColor, modifier = Modifier.size(20.dp))
                        } else {
                            Text("${index + 1}", color = Color(0xFF555566), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, color = if (isCurrentTrack) accentColor else Color.White,
                            fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${track.artist} · ${track.format}", color = Color(0xFF666677),
                            fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { playlistManager?.removeTrack(track.id) }) {
                        Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFF444455))
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    if (showImportDialog) {
        AlertDialog(onDismissRequest = { showImportDialog = false },
            containerColor = Color(0xFF111118),
            title = { Text("Import Songs", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                if (scannedTracks.isEmpty()) {
                    Text("No audio files found on this device.", color = Color(0xFF888899))
                } else {
                    Column(Modifier.fillMaxWidth().heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                        Text("${scannedTracks.size} tracks found", color = Color(0xFF888899),
                            fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                        scannedTracks.forEach { track ->
                            Row(Modifier.fillMaxWidth()
                                .clickable { selectedIds[track.id] = !(selectedIds[track.id] ?: false) }
                                .padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = selectedIds[track.id] ?: false,
                                    onCheckedChange = { selectedIds[track.id] = it },
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFFFFC94D)))
                                Spacer(Modifier.width(4.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(track.title, color = Color.White, fontSize = 13.sp,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${track.artist} · ${track.format}", color = Color(0xFF666677),
                                        fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val chosen = scannedTracks.filter { selectedIds[it.id] == true }
                    playlistManager?.addTracks(chosen)
                    showImportDialog = false
                }) { Text("Add Selected (${selectedIds.values.count { it }})", color = Color(0xFFFFC94D), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) { Text("Cancel", color = Color(0xFF888899)) }
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// REUSABLE COMPOSABLES
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun DSPMeter(label: String, value: String, isActive: Boolean, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (isActive) color else Color(0xFF2A2A3A)))
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 12.sp, color = Color(0xFFCCCCDD), modifier = Modifier.width(110.dp))
        Spacer(Modifier.weight(1f))
        Text(value, fontSize = 11.sp, color = if (isActive) color else Color(0xFF444455),
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun QuickToggle(modifier: Modifier, emoji: String, label: String, isOn: Boolean, color: Color, onToggle: () -> Unit) {
    Surface(onClick = onToggle, modifier = modifier, shape = RoundedCornerShape(14.dp),
        color = if (isOn) color.copy(0.15f) else Color(0xFF0A0A12),
        border = BorderStroke(1.dp, if (isOn) color.copy(0.6f) else Color(0xFF1A1A2A))
    ) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 22.sp)
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isOn) color else Color(0xFF555566))
            Text(if (isOn) "ON" else "OFF", fontSize = 9.sp,
                color = if (isOn) color.copy(0.8f) else Color(0xFF333344),
                fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun AudioBadge(text: String, color: Color, isActive: Boolean) {
    Surface(shape = RoundedCornerShape(20.dp),
        color = if (isActive) color.copy(0.15f) else Color(0xFF1A1A2A),
        border = if (isActive) BorderStroke(1.dp, color.copy(0.6f)) else null
    ) {
        Text(text, Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            color = if (isActive) color else Color(0xFF555566),
            fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
    }
}

@Composable
fun CapRow(label: String, supported: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = Color(0xFFCCCCDD))
        Text(if (supported) "✓ YES" else "✗ NO", fontSize = 12.sp,
            color = if (supported) Color(0xFF00E676) else Color(0xFF555566), fontWeight = FontWeight.Bold)
    }
}

private fun reverbLabel(preset: Int) = when (preset) {
    0 -> "Off"; 1 -> "Small Room"; 2 -> "Medium Room"
    3 -> "Large Room"; 4 -> "Medium Hall"; 5 -> "Large Hall"; 6 -> "Plate"
    else -> "Active"
}

private fun mimeLabel(mime: String) = when (mime) {
    "audio/eac3-joc" -> "DOLBY ATMOS"; "audio/eac3" -> "DOLBY D+"
    "audio/ac3" -> "DOLBY D"; "audio/mp4a-latm" -> "AAC"; else -> "PCM"
}

private fun formatTime(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val s = ms / 1000
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}
