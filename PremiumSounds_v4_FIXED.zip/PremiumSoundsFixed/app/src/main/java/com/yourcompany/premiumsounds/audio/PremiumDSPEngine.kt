package com.yourcompany.premiumsounds.audio

import android.media.audiofx.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * PremiumDSPEngine v4 — Maximum-power audio processing chain
 *
 * FIXES:
 * - refreshBandState() now called correctly in ALL applyMode paths
 * - DSP values maximized for real audible effect
 * - Custom preset save/load support added
 * - Each mode has truly unique EQ curves (no more same values)
 *
 * Signal chain: Input → EQ(5-band) → BassBoost → PresetReverb → Virtualizer → LoudnessEnhancer → Output
 */
class PremiumDSPEngine {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var presetReverb: PresetReverb? = null

    private val _dspState = MutableStateFlow(DSPState())
    val dspState: StateFlow<DSPState> = _dspState

    // FIX: Custom presets storage
    private val customPresets = mutableMapOf<String, CustomPreset>()

    data class CustomPreset(
        val name: String,
        val bands: List<Int>,       // EQ levels in mB
        val bassStrength: Int,
        val virtStrength: Int,
        val loudnessMb: Int,
        val reverbPreset: Int
    )

    data class DSPState(
        val currentMode: SoundMode = SoundMode.MUSIC_HD,
        val isEnabled: Boolean = true,
        val bands: List<BandState> = emptyList(),
        val bassStrength: Int = 500,
        val virtualizerStrength: Int = 500,
        val loudnessBoostMb: Int = 0,
        val reverbPreset: Int = 0,
        val dialogueEnhance: Boolean = false,
        val nightMode: Boolean = false,
        val isHardwareAttached: Boolean = false,
        val savedCustomPresets: List<String> = emptyList()   // names of saved presets
    )

    data class BandState(
        val index: Int,
        val centerFreqHz: Int,
        val levelMb: Int,
        val minLevelMb: Int,
        val maxLevelMb: Int
    )

    // ── Sound Modes — FIXED: each mode has truly distinct values ──────────────
    enum class SoundMode(
        val label: String,
        val emoji: String,
        val description: String,
        // EQ: [sub-bass ~60Hz, bass ~230Hz, mid ~910Hz, presence ~3.6kHz, air ~14kHz] in mB
        val eqBands: List<Int>,
        val bassStrength: Int,   // 0–1000 (FIXED: maximized per mode)
        val virtStrength: Int,   // 0–1000
        val loudnessMb: Int,     // 0–2000 mB
        val reverbPreset: Int,
        val accentHex: Long
    ) {
        FLAT(
            "Flat", "◼", "Pure unprocessed signal",
            listOf(0, 0, 0, 0, 0),
            0, 0, 0, 0, 0xFF888899L
        ),
        MUSIC_HD(
            "Music HD", "🎵", "Balanced richness for all genres",
            listOf(400, 300, 50, 300, 500),     // FIX: proper values, not 50%/50%
            450, 500, 400, 0, 0xFF00D4FFL
        ),
        BASS_MONSTER(
            "Bass Monster", "🔊", "Maximum sub-bass punch",
            listOf(1200, 900, -200, 0, 100),    // FIX: real bass boost, -200 mid cuts mud
            1000, 200, 500, 0, 0xFF7C4DFFL      // FIX: bass=1000 (max!) not 900
        ),
        CINEMA(
            "Cinema", "🎬", "Wide surround with loud dialogue",
            listOf(600, 300, 400, 500, 200),
            500, 900, 600, 5, 0xFFFF6B6BL       // FIX: reverb=5 (Large Hall), virt=900
        ),
        GAME(
            "Game", "🎮", "Positional audio with spatial depth",
            listOf(300, 500, 150, 600, 400),
            600, 1000, 400, 1, 0xFF00E676L      // FIX: virt=1000 (max!) for 3D
        ),
        PODCAST(
            "Podcast", "🎙️", "Voice clarity + noise floor reduction",
            listOf(-600, -400, 900, 700, 100),  // FIX: cut bass hard, boost voice band
            0, 200, 800, 0, 0xFFFFC94DL
        ),
        NIGHT_MODE(
            "Night Mode", "🌙", "Smooth dynamics, comfortable at low vol",
            listOf(200, 150, 300, 150, -100),
            200, 150, 1200, 0, 0xFF4A90D9L      // FIX: loudness=1200 compensates low vol
        ),
        CONCERT_HALL(
            "Concert Hall", "🎻", "Live acoustic hall simulation",
            listOf(300, 100, -200, 400, 700),
            150, 750, 200, 5, 0xFFE040FBL       // FIX: Large Hall reverb + wide spatial
        ),
        DEEP_SPACE(
            "Deep Space", "🚀", "Max 3D immersion",
            listOf(600, 400, 0, 500, 800),
            400, 1000, 500, 3, 0xFF00BCD4L      // FIX: virt=1000, loudness=500
        ),
        VOCAL_BOOST(
            "Vocal Boost", "🎤", "Enhanced singer and speech clarity",
            listOf(-500, -200, 1000, 900, 300), // FIX: massive mid boost, cut sub-bass
            100, 350, 600, 0, 0xFFFF9800L
        ),
        ROCK(
            "Rock", "🎸", "Punchy mids, aggressive highs",
            listOf(800, 600, -300, 600, 900),   // FIX: more aggressive, -300 cuts mud
            800, 550, 300, 0, 0xFFFF5252L
        ),
        CLASSICAL(
            "Classical", "🎼", "Natural warmth, airy highs",
            listOf(400, 100, -400, 200, 700),   // FIX: clear separation, -400 mid for space
            100, 400, 150, 4, 0xFFF8BBD0L
        ),
        HIP_HOP(
            "Hip Hop", "🎤", "Heavy bass + crisp hi-hats",
            listOf(1000, 700, -100, 100, 600),
            900, 400, 400, 0, 0xFFFF6B00L
        ),
        EDM(
            "EDM", "⚡", "Club sound — bass drop + air",
            listOf(900, 500, -200, 200, 900),
            950, 800, 500, 2, 0xFF00E5FFL
        ),
        LOFI(
            "Lo-Fi", "☕", "Warm vintage feel",
            listOf(500, 400, -300, -400, -600), // Cut highs for that cassette warmth
            300, 100, 100, 1, 0xFFD4A04DL
        )
    }

    // ── Attach to audio session ────────────────────────────────────────────────
    fun attach(audioSessionId: Int) {
        release()
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(0); enabled = false
            }
            presetReverb = try {
                PresetReverb(0, audioSessionId).apply { enabled = false }
            } catch (_: Exception) { null }

            _dspState.value = _dspState.value.copy(isHardwareAttached = true)
            // FIX: Always apply current mode on attach so EQ bands populate immediately
            applyMode(_dspState.value.currentMode, announce = true)
        } catch (e: Exception) {
            e.printStackTrace()
            _dspState.value = _dspState.value.copy(isHardwareAttached = false)
        }
    }

    // ── Apply full sound mode ──────────────────────────────────────────────────
    fun applyMode(mode: SoundMode, announce: Boolean = true) {
        val eq = equalizer ?: run {
            // FIX: Always update state even if hardware not attached
            _dspState.value = _dspState.value.copy(
                currentMode = mode,
                bassStrength = mode.bassStrength,
                virtualizerStrength = mode.virtStrength,
                loudnessBoostMb = mode.loudnessMb,
                reverbPreset = mode.reverbPreset
            )
            return
        }
        val bandCount = eq.numberOfBands.toInt()

        // 1. EQ
        mode.eqBands.take(bandCount).forEachIndexed { i, level ->
            try { eq.setBandLevel(i.toShort(), level.toShort()) } catch (_: Exception) {}
        }
        // 2. Bass Boost
        try {
            bassBoost?.setStrength(mode.bassStrength.toShort())
            bassBoost?.enabled = mode.bassStrength > 0
        } catch (_: Exception) {}
        // 3. Virtualizer
        try {
            virtualizer?.setStrength(mode.virtStrength.toShort())
            virtualizer?.enabled = mode.virtStrength > 0
        } catch (_: Exception) {}
        // 4. Loudness
        try {
            loudnessEnhancer?.setTargetGain(mode.loudnessMb)
            loudnessEnhancer?.enabled = mode.loudnessMb > 0
        } catch (_: Exception) {}
        // 5. Reverb
        try {
            presetReverb?.preset = mode.reverbPreset.toShort()
            presetReverb?.enabled = mode.reverbPreset != 0
        } catch (_: Exception) {}

        // FIX: Always update state + bands regardless of announce flag
        _dspState.value = _dspState.value.copy(
            currentMode = mode,
            bassStrength = mode.bassStrength,
            virtualizerStrength = mode.virtStrength,
            loudnessBoostMb = mode.loudnessMb,
            reverbPreset = mode.reverbPreset,
            nightMode = mode == SoundMode.NIGHT_MODE
        )
        refreshBandState()   // FIX: was missing in non-announce path
    }

    // ── Manual fine-tune ───────────────────────────────────────────────────────
    fun setBandLevel(bandIndex: Int, levelMb: Int) {
        try {
            equalizer?.setBandLevel(bandIndex.toShort(), levelMb.toShort())
            refreshBandState()
        } catch (_: Exception) {}
    }

    fun setBassStrength(strength: Int) {
        try {
            val clamped = strength.coerceIn(0, 1000)
            bassBoost?.setStrength(clamped.toShort())
            bassBoost?.enabled = clamped > 0
            _dspState.value = _dspState.value.copy(bassStrength = clamped)
        } catch (_: Exception) {}
    }

    fun setVirtualizerStrength(strength: Int) {
        try {
            val clamped = strength.coerceIn(0, 1000)
            virtualizer?.setStrength(clamped.toShort())
            virtualizer?.enabled = clamped > 0
            _dspState.value = _dspState.value.copy(virtualizerStrength = clamped)
        } catch (_: Exception) {}
    }

    fun setLoudnessBoost(gainMb: Int) {
        try {
            val clamped = gainMb.coerceIn(0, 2000)
            loudnessEnhancer?.setTargetGain(clamped)
            loudnessEnhancer?.enabled = clamped > 0
            _dspState.value = _dspState.value.copy(loudnessBoostMb = clamped)
        } catch (_: Exception) {}
    }

    fun setReverbPreset(preset: Int) {
        try {
            presetReverb?.preset = preset.toShort()
            presetReverb?.enabled = preset != 0
            _dspState.value = _dspState.value.copy(reverbPreset = preset)
        } catch (_: Exception) {}
    }

    fun setNightMode(on: Boolean) {
        if (on) applyMode(SoundMode.NIGHT_MODE)
        else applyMode(SoundMode.MUSIC_HD)
        _dspState.value = _dspState.value.copy(nightMode = on)
    }

    fun setDialogueEnhance(on: Boolean) {
        val eq = equalizer ?: return
        try {
            val bandCount = eq.numberOfBands.toInt()
            if (on) {
                if (bandCount > 2) eq.setBandLevel(2, 1000)   // FIX: 1000mB not 800
                if (bandCount > 3) eq.setBandLevel(3, 800)
            } else {
                applyMode(_dspState.value.currentMode)
            }
            _dspState.value = _dspState.value.copy(dialogueEnhance = on)
            refreshBandState()
        } catch (_: Exception) {}
    }

    fun setEnabled(enabled: Boolean) {
        equalizer?.enabled = enabled
        bassBoost?.enabled = enabled && _dspState.value.bassStrength > 0
        virtualizer?.enabled = enabled && _dspState.value.virtualizerStrength > 0
        loudnessEnhancer?.enabled = enabled && _dspState.value.loudnessBoostMb > 0
        presetReverb?.enabled = enabled && _dspState.value.reverbPreset != 0
        _dspState.value = _dspState.value.copy(isEnabled = enabled)
    }

    // ── Custom Preset Save/Load ────────────────────────────────────────────────
    fun saveCustomPreset(name: String) {
        val state = _dspState.value
        val bandLevels = state.bands.map { it.levelMb }
        customPresets[name] = CustomPreset(
            name = name,
            bands = bandLevels,
            bassStrength = state.bassStrength,
            virtStrength = state.virtualizerStrength,
            loudnessMb = state.loudnessBoostMb,
            reverbPreset = state.reverbPreset
        )
        _dspState.value = state.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun loadCustomPreset(name: String) {
        val preset = customPresets[name] ?: return
        val eq = equalizer ?: return
        val bandCount = eq.numberOfBands.toInt()
        preset.bands.take(bandCount).forEachIndexed { i, lvl ->
            try { eq.setBandLevel(i.toShort(), lvl.toShort()) } catch (_: Exception) {}
        }
        setBassStrength(preset.bassStrength)
        setVirtualizerStrength(preset.virtStrength)
        setLoudnessBoost(preset.loudnessMb)
        setReverbPreset(preset.reverbPreset)
        refreshBandState()
    }

    fun deleteCustomPreset(name: String) {
        customPresets.remove(name)
        _dspState.value = _dspState.value.copy(savedCustomPresets = customPresets.keys.toList())
    }

    fun getCustomPresets(): Map<String, CustomPreset> = customPresets.toMap()

    // ── Internal helpers ───────────────────────────────────────────────────────
    private fun refreshBandState() {
        val eq = equalizer ?: return
        val range = try { eq.bandLevelRange } catch (_: Exception) { shortArrayOf(-1500, 1500) }
        val bands = (0 until eq.numberOfBands.toInt()).map { i ->
            BandState(
                index = i,
                centerFreqHz = try { eq.getCenterFreq(i.toShort()) / 1000 } catch (_: Exception) { 0 },
                levelMb = try { eq.getBandLevel(i.toShort()).toInt() } catch (_: Exception) { 0 },
                minLevelMb = range[0].toInt(),
                maxLevelMb = range[1].toInt()
            )
        }
        _dspState.value = _dspState.value.copy(bands = bands)
    }

    fun release() {
        listOf(equalizer, bassBoost, virtualizer, loudnessEnhancer, presetReverb).forEach {
            try { it?.release() } catch (_: Exception) {}
        }
        equalizer = null; bassBoost = null; virtualizer = null
        loudnessEnhancer = null; presetReverb = null
        _dspState.value = _dspState.value.copy(isHardwareAttached = false, bands = emptyList())
    }
}
